import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { useStore } from './store';
import { itemDef } from '../game/items/Items';
import type { Game } from '../game/core/Game';

/**
 * Small live render of the player's voxel figure for the inventory screen. The figure idles (breathing,
 * slight sway), turns to follow the mouse and shows the armour currently worn. It owns a tiny WebGL
 * renderer of its own so it can live inside the React overlay without touching the game scene.
 */
interface PreviewRig { renderer: THREE.WebGLRenderer; scene: THREE.Scene; camera: THREE.PerspectiveCamera; parts: FigureParts }

// One shared WebGL context for every inventory open: browsers cap the number of live contexts and
// evict the oldest one when the cap is hit, which could be the game's own canvas.
let rig: PreviewRig | null | undefined;
function getRig(width: number, height: number): PreviewRig | null {
  if (rig === undefined) {
    try {
      const canvas = document.createElement('canvas');
      canvas.className = 'player-figure';
      const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: true, powerPreference: 'low-power' });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(26, 1, 0.1, 20);
      camera.position.set(0, 0.95, 6.6);
      camera.lookAt(0, 0.75, 0);
      scene.add(new THREE.AmbientLight(0xffffff, 0.75));
      const key = new THREE.DirectionalLight(0xffffff, 1.4); key.position.set(1.5, 3, 2.5); scene.add(key);
      const fill = new THREE.DirectionalLight(0x8fb4ff, 0.6); fill.position.set(-2, 1, -2); scene.add(fill);
      const parts = buildFigure();
      scene.add(parts.root);
      rig = { renderer, scene, camera, parts };
    } catch {
      rig = null;
    }
  }
  if (rig) {
    rig.renderer.setSize(width, height, false);
    rig.camera.aspect = width / height;
    rig.camera.updateProjectionMatrix();
  }
  return rig;
}

export function PlayerPreview({ game, width = 96, height = 170 }: { game: Game; width?: number; height?: number }) {
  const host = useRef<HTMLDivElement>(null);
  const invVersion = useStore((s) => s.inv);
  const mouse = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const el = host.current;
    const r = getRig(width, height);
    if (!el || !r) return;
    el.appendChild(r.renderer.domElement);
    let raf = 0; let t = 0; let last = performance.now();
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
      const p = r.parts; const k = Math.min(1, dt * 6);
      // idle: breathing + subtle arm sway; head and body turn toward the pointer
      p.root.rotation.y += ((mouse.current.x * 0.6) - p.root.rotation.y) * k;
      p.head.rotation.x += ((-mouse.current.y * 0.35) - p.head.rotation.x) * k;
      p.head.rotation.y += ((mouse.current.x * 0.35) - p.head.rotation.y) * k;
      p.body.position.y = 18 / 16 + Math.sin(t * 1.6) * 0.008;
      p.arms[0].rotation.x = Math.sin(t * 1.6) * 0.04; p.arms[1].rotation.x = -Math.sin(t * 1.6) * 0.04;
      p.arms[0].rotation.z = 0.05 + Math.sin(t * 1.1) * 0.02; p.arms[1].rotation.z = -0.05 - Math.sin(t * 1.1) * 0.02;
      r.renderer.render(r.scene, r.camera);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      if (r.renderer.domElement.parentNode === el) el.removeChild(r.renderer.domElement);
    };
  }, [width, height]);

  // armour overlays follow the inventory
  useEffect(() => {
    const r = rig;
    if (!r) return;
    const armor = game.player.inventory.armor;
    for (let i = 0; i < 4; i++) {
      const s = armor.get(i);
      const def = s ? itemDef(s.id) : undefined;
      const col = def?.icon && 'colors' in def.icon && def.icon.colors ? def.icon.colors.A : null;
      for (const m of r.parts.armor[i]) {
        m.visible = !!col;
        if (col) (m.material as THREE.MeshLambertMaterial).color.set(col);
      }
    }
  }, [game, invVersion]);

  return (
    <div ref={host} className="player-figure-host" style={{ width, height }}
      onMouseMove={(e) => { const b = e.currentTarget.getBoundingClientRect(); mouse.current = { x: ((e.clientX - b.left) / b.width - 0.5) * 2, y: ((e.clientY - b.top) / b.height - 0.5) * 2 }; }}
      onMouseLeave={() => { mouse.current = { x: 0, y: 0 }; }} />
  );
}

interface FigureParts { root: THREE.Group; head: THREE.Group; body: THREE.Mesh; arms: THREE.Mesh[]; legs: THREE.Mesh[]; armor: THREE.Mesh[][] }

/** Steve-free original figure: rounded-off skin tones, tunic and trousers in the game's palette. */
function buildFigure(): FigureParts {
  const root = new THREE.Group();
  const SKIN = 0xd8a878, TUNIC = 0x3f6f9f, TROUSER = 0x3b3b5a, HAIR = 0x5a3a22;
  const mat = (c: number) => new THREE.MeshLambertMaterial({ color: c });
  const box = (w: number, h: number, d: number, c: number, x: number, y: number, z: number, pivotTop = false) => {
    const g = new THREE.BoxGeometry(w / 16, h / 16, d / 16);
    if (pivotTop) g.translate(0, -h / 32, 0);
    const m = new THREE.Mesh(g, mat(c)); m.position.set(x / 16, y / 16, z / 16); return m;
  };
  const legs = [box(3.9, 12, 4, TROUSER, -2, 12, 0, true), box(3.9, 12, 4, TROUSER, 2, 12, 0, true)];
  const body = box(8, 12, 4, TUNIC, 0, 18, 0);
  const arms = [box(4, 12, 4, TUNIC, -6, 24, 0, true), box(4, 12, 4, TUNIC, 6, 24, 0, true)];
  // hands: the arm geometry is pivoted at its top, so the hand sits at the bottom 3 px
  for (const a of arms) { const hand = box(4.02, 3, 4.02, SKIN, 0, 0, 0); hand.position.y = -(12 - 1.5) / 16; a.add(hand); }
  const head = new THREE.Group(); head.position.set(0, 24 / 16, 0);
  head.add(box(8, 8, 8, SKIN, 0, 4, 0));
  head.add(box(8.4, 3, 8.4, HAIR, 0, 6.6, 0)); // hair cap
  head.add(box(8.4, 1.5, 0.4, HAIR, 0, 5.4, 4.2)); // fringe
  head.add(box(2, 1, 0.3, 0x202020, -2, 3.5, 4.1), box(2, 1, 0.3, 0x202020, 2, 3.5, 4.1)); // eyes
  head.add(box(1, 1, 0.3, 0xffffff, -2.5, 3.5, 4.15), box(1, 1, 0.3, 0xffffff, 1.5, 3.5, 4.15)); // eye highlights
  head.add(box(2, 0.8, 0.3, 0xb07850, 0, 1.6, 4.1)); // mouth
  root.add(...legs, body, ...arms, head);
  // armour overlays (slightly larger boxes), hidden unless worn: helmet, chestplate, leggings, boots
  const ov = (w: number, h: number, d: number, x: number, y: number, z: number, parent: THREE.Object3D, pivotTop = false) => { const m = box(w, h, d, 0xffffff, x, y, z, pivotTop); m.visible = false; parent.add(m); return m; };
  // open-faced helmet: cap, back plate and cheek plates so the face stays visible
  const helmet = [ov(9, 3.6, 9, 0, 6.8, 0, head), ov(9, 6, 1, 0, 2.6, -4.1, head), ov(1, 6, 9, -4.1, 2.6, 0, head), ov(1, 6, 9, 4.1, 2.6, 0, head)];
  const chest = [ov(9, 12.6, 5, 0, 18, 0, root), ov(5, 12.4, 5, 0, 0, 0, arms[0], true), ov(5, 12.4, 5, 0, 0, 0, arms[1], true)];
  const legsA = [ov(4.8, 12.2, 4.8, 0, 0, 0, legs[0], true), ov(4.8, 12.2, 4.8, 0, 0, 0, legs[1], true), ov(8.6, 4, 4.6, 0, 13, 0, root)];
  const boots = [ov(5, 5, 5, 0, 0, 0, legs[0]), ov(5, 5, 5, 0, 0, 0, legs[1])];
  for (const m of boots) m.position.y = -9.5 / 16; // bottom of the (top-pivoted) leg
  root.position.y = -0.05;
  return { root, head, body, arms, legs, armor: [helmet, chest, legsA, boots] };
}
