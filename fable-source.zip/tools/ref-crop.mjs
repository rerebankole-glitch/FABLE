// ASCII view of a rectangular crop of a reference image (fractions of width/height), high detail.
import { createCanvas, loadImage } from '@napi-rs/canvas';

const [path, fx0, fy0, fx1, fy1, colsArg] = process.argv.slice(2);
const img = await loadImage(path);
const W = img.width, H = img.height;
const x0 = Math.round(parseFloat(fx0) * W), x1 = Math.round(parseFloat(fx1) * W);
const y0 = Math.round(parseFloat(fy0) * H), y1 = Math.round(parseFloat(fy1) * H);
const cw = x1 - x0, ch = y1 - y0;
const COLS = Number(colsArg || 100);
const ROWS = Math.max(4, Math.round((COLS * ch) / cw / 2));
const c = createCanvas(COLS, ROWS);
const ctx = c.getContext('2d');
ctx.imageSmoothingEnabled = true;
ctx.drawImage(img, x0, y0, cw, ch, 0, 0, COLS, ROWS);
const d = ctx.getImageData(0, 0, COLS, ROWS).data;
console.log(`${path.split('/').pop()} crop x[${(100 * x0 / W).toFixed(0)}..${(100 * x1 / W).toFixed(0)}%] y[${(100 * y0 / H).toFixed(0)}..${(100 * y1 / H).toFixed(0)}%]`);
for (let y = 0; y < ROWS; y++) {
  let line = '';
  for (let x = 0; x < COLS; x++) {
    const i = (y * COLS + x) * 4;
    const r = d[i], g = d[i + 1], b = d[i + 2];
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
    const sat = mx === 0 ? 0 : (mx - mn) / mx;
    const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    let ch2;
    if (r > 110 && r > g + 20 && g > b + 5 && sat > 0.2 && lum > 0.28) ch2 = 'S';        // skin
    else if (g > r + 10 && g > b + 10) ch2 = 'g';                                        // foliage
    else if (b > r + 18 && b > g + 2) ch2 = 'b';                                         // sky/water
    else if (sat > 0.25 && lum < 0.55) ch2 = 'w';                                        // wood/dark warm
    else if (lum > 0.85) ch2 = '.';
    else if (lum > 0.62) ch2 = ':';
    else if (lum > 0.4) ch2 = '+';
    else if (lum > 0.2) ch2 = '*';
    else ch2 = '#';
    line += ch2;
  }
  console.log(line);
}
