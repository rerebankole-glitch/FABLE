// Masks a reference screenshot by colour family and reports, for each family, the bounding box in
// screen fractions plus the principal axis (angle + length) — i.e. "where is the arm, where is the
// tool, how big and at what angle are they".
import { createCanvas, loadImage } from '@napi-rs/canvas';

const path = process.argv[2];
const img = await loadImage(path);
const W = img.width, H = img.height;
const c = createCanvas(W, H);
const ctx = c.getContext('2d');
ctx.drawImage(img, 0, 0);
const d = ctx.getImageData(0, 0, W, H).data;

const fam = (name, test) => ({ name, test, pts: [] });
const fams = [
  fam('skin', (r, g, b) => { const mx = Math.max(r, g, b), mn = Math.min(r, g, b); return r > 110 && r > g + 20 && g > b + 5 && (mx - mn) / mx > 0.2 && (0.299 * r + 0.587 * g + 0.114 * b) > 70; }),
  fam('gray', (r, g, b) => { const mx = Math.max(r, g, b), mn = Math.min(r, g, b); return (mx - mn) / Math.max(1, mx) < 0.16 && (0.299 * r + 0.587 * g + 0.114 * b) > 55; }),
  fam('wood', (r, g, b) => { const mx = Math.max(r, g, b), mn = Math.min(r, g, b); return r > 60 && r > g + 8 && g > b - 4 && (mx - mn) / mx > 0.25 && (0.299 * r + 0.587 * g + 0.114 * b) < 140; }),
  fam('green', (r, g, b) => g > r + 8 && g > b + 8),
  fam('sky', (r, g, b) => b > r + 18 && b > g + 2),
];

for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  const i = (y * W + x) * 4;
  const r = d[i], g = d[i + 1], b = d[i + 2];
  for (const f of fams) if (f.test(r, g, b)) { f.pts.push(x, y); break; }
}

console.log(`${path.split('/').pop()}  ${W}x${H}`);
for (const f of fams) {
  const n = f.pts.length / 2;
  if (!n) { console.log(`  ${f.name.padEnd(6)} none`); continue; }
  let sx = 0, sy = 0, x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
  for (let i = 0; i < f.pts.length; i += 2) {
    const x = f.pts[i], y = f.pts[i + 1];
    sx += x; sy += y;
    if (x < x0) x0 = x; if (x > x1) x1 = x;
    if (y < y0) y0 = y; if (y > y1) y1 = y;
  }
  const cx = sx / n, cy = sy / n;
  let xx = 0, xy = 0, yy = 0;
  for (let i = 0; i < f.pts.length; i += 2) {
    const dx = f.pts[i] - cx, dy = f.pts[i + 1] - cy;
    xx += dx * dx; xy += dx * dy; yy += dy * dy;
  }
  xx /= n; xy /= n; yy /= n;
  const ang = 0.5 * Math.atan2(2 * xy, xx - yy) * 180 / Math.PI; // major axis, deg, + = down-right
  const l1 = Math.sqrt(((xx + yy) / 2) + Math.sqrt(((xx - yy) / 2) ** 2 + xy * xy));
  const l2 = Math.sqrt(Math.max(0, ((xx + yy) / 2) - Math.sqrt(((xx - yy) / 2) ** 2 + xy * xy)));
  const pct = (v, m) => (100 * v / m).toFixed(1) + '%';
  console.log(`  ${f.name.padEnd(6)} n=${pct(n, W * H).padStart(5)}  bbox x[${pct(x0, W)}..${pct(x1, W)}] y[${pct(y0, H)}..${pct(y1, H)}]  centre (${pct(cx, W)},${pct(cy, H)})  axis ${ang.toFixed(1)}deg  major ${pct(2 * l1, H)} screenH  minor ${pct(2 * l2, H)} screenH`);
}
