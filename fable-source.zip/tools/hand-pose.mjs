// Renders the first-person viewmodel ("hold in hands") exactly as the game builds it — same
// HandFit constants, same item model module, same Java chain — into a pose-proof PNG, and prints
// the measured screen-space layout so the composition can be checked without a browser.
//
//   node tools/hand-pose.mjs [outfile.png]
//
// The transform stack reproduced here is the resting pose (swing/equip at rest):
//   chain = T(0.56,-0.52,-0.72) * S(0.4) * [pose: T(place) * R * S(size)]
//   hand  = T(pos * fovK) * R(q) * S(fovK * s)      (Game.updateHand)
//   projected with the world camera (fov 75, 16:9) — fovK cancels it back to the fixed 70 hand pass.
import { build } from 'esbuild';
import { createCanvas } from '@napi-rs/canvas';
import { writeFileSync } from 'node:fs';
import * as THREE from 'three';

// --- DOM shim so Icons.ts / ItemModel.ts can run unchanged in node ---
globalThis.document = {
  createElement(tag) {
    if (tag !== 'canvas') throw new Error('unexpected element ' + tag);
    return createCanvas(1, 1);
  },
};

// HandFit has to be bundled too (it is TypeScript)
await build({
  entryPoints: ['src/game/core/HandFit.ts'],
  bundle: true, platform: 'node', format: 'esm', outfile: '/tmp/hand-fit.mjs', logLevel: 'error',
});

await build({
  entryPoints: ['tools/hand-pose-entry.ts'],
  bundle: true, platform: 'node', format: 'esm', outfile: '/tmp/hand-pose-entry.mjs', logLevel: 'error',
});
const { extrudedIcon } = await import('/tmp/hand-pose-entry.mjs');
const F = await import('/tmp/hand-fit.mjs');

const W = 640, H = 360;
const FOV = 75, ASPECT = W / H;
const fovK = Math.tan((35 * Math.PI) / 180) / Math.tan((FOV * Math.PI) / 360);

const D = Math.PI / 180;
const AXIS_Z = new THREE.Vector3(0, 0, 1);
const ITEM_BASE = { x: 0.56, y: -0.52, z: -0.71999997 };

function chainMatrix(pose) {
  const sp = pose.sp ?? 1;                  // 1 = rest, 0.25 = peak of the swing
  const sq = Math.sqrt(Math.max(0, Math.min(1, sp)));
  const mv = new THREE.Matrix4();
  mv.identity();
  mv.multiply(new THREE.Matrix4().makeTranslation(ITEM_BASE.x, ITEM_BASE.y, ITEM_BASE.z));
  mv.multiply(new THREE.Matrix4().makeScale(0.4, 0.4, 0.4));
  if (sp < 1 && pose.style) {
    // the pose branch re-pivots the swing onto the grip (Game.pivotSwing)
    const amp = (pose.chop ? 0.55 : 1) * F.HELD_SWING;
    const g = pose.kind === 'flat' ? F.HELD_GRIP_LOCAL : { x: 0, y: 0 };
    const t = new THREE.Matrix4().makeTranslation(g.x, g.y, 0);
    const swing = new THREE.Matrix4()
      .multiply(new THREE.Matrix4().makeRotationY(Math.sin(sp * sp * Math.PI) * pose.style.ry * D * amp))
      .multiply(new THREE.Matrix4().makeRotationZ(Math.sin(sq * Math.PI) * pose.style.rz * D * amp))
      .multiply(new THREE.Matrix4().makeRotationX(Math.sin(sq * Math.PI) * pose.style.rx * D * amp));
    mv.multiply(t.clone().multiply(swing).multiply(t.clone().invert()));
  }
  if (pose.kind === 'flat') {
    mv.multiply(new THREE.Matrix4().makeTranslation(F.HELD_PLATE.x, F.HELD_PLATE.y, F.HELD_PLATE.z));
    mv.multiply(new THREE.Matrix4().makeRotationAxis(AXIS_Z, F.HELD_TILT));
    mv.multiply(new THREE.Matrix4().makeScale(F.HELD_PLATE.size, F.HELD_PLATE.size, F.HELD_PLATE.size));
  } else {
    mv.multiply(new THREE.Matrix4().makeTranslation(F.HELD_BLOCK.x, F.HELD_BLOCK.y, F.HELD_BLOCK.z));
    mv.multiply(new THREE.Matrix4().makeRotationY(F.HELD_BLOCK_YAW));
    mv.multiply(new THREE.Matrix4().makeRotationX(F.HELD_BLOCK_PITCH));
    mv.multiply(new THREE.Matrix4().makeScale(F.HELD_BLOCK.size, F.HELD_BLOCK.size, F.HELD_BLOCK.size));
  }
  const pos = new THREE.Vector3(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  mv.decompose(pos, q, s);
  // updateHand: position *= fovK, scale = fovK * s.x, rotation unchanged
  return new THREE.Matrix4().compose(pos.clone().multiplyScalar(fovK), q, new THREE.Vector3().setScalar(fovK * s.x));
}

/** The arm as the game builds it: a 4x12x4 model-px box (shoulder y=0, fist y=12) + fist cube. */
function armBoxes(pose) {
  const s = pose.kind === 'flat' ? F.HELD_ARM_S : F.HELD_BLOCK_ARM_S;
  const phi = pose.kind === 'flat' ? F.HELD_ARM_PHI : F.HELD_ARM_PHI_BLOCK;
  const grip = pose.kind === 'flat' ? { x: F.HELD_GRIP_LOCAL.x, y: F.HELD_GRIP_LOCAL.y, z: F.HELD_ARM_Z } : F.HELD_BLOCK_GRIP;
  const c = Math.cos(phi), sn = Math.sin(phi);
  const fx = (-6 * c - 12 * sn) * s, fy = (-6 * sn + 12 * c) * s;
  const m = new THREE.Matrix4()
    .makeTranslation(grip.x - fx, grip.y - fy, grip.z)
    .multiply(new THREE.Matrix4().makeScale(s, s, s))
    .multiply(new THREE.Matrix4().makeRotationZ(phi));
  if (pose.kind !== 'flat') {
    // cancel the block pose's yaw + pitch so the forearm still leaves towards the bottom-right
    m.premultiply(new THREE.Matrix4().makeRotationY(F.HELD_BLOCK_YAW));
    m.premultiply(new THREE.Matrix4().makeRotationX(F.HELD_BLOCK_PITCH));
  }
  const box = (cx, cy, cz, sx, sy, sz, col) => ({
    centre: [cx, cy, cz], size: [sx, sy, sz], colour: col, matrix: m,
  });
  const SKIN = [0.85, 0.66, 0.47], SLEEVE = [0.25, 0.44, 0.62], FISTC = [0.88, 0.7, 0.5];
  return [
    box(-6, 3, 0, 4, 6, 4, SLEEVE),   // sleeve half
    box(-6, 9, 0, 4, 6, 4, SKIN),     // bare forearm
    box(-6, 11, 0, 4.2, 4.2, 4.2, FISTC), // fist / knuckles
  ];
}

// ---------------------------------------------------------------- rasteriser
function render(pose, file) {
  const cv = createCanvas(W, H);
  const ctx = cv.getContext('2d');
  // backdrop: sky / ground like an in-game frame, so the silhouette reads
  const sky = ctx.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0, '#79a6ff'); sky.addColorStop(0.62, '#a8c8ff'); sky.addColorStop(0.62, '#5f9c46'); sky.addColorStop(1, '#3d6f30');
  ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);

  const cam = new THREE.PerspectiveCamera(FOV, ASPECT, 0.05, 600);
  cam.updateMatrixWorld(); cam.updateProjectionMatrix();
  const M = chainMatrix(pose);
  const zbuf = new Float32Array(W * H).fill(-Infinity);
  const idbuf = new Int8Array(W * H).fill(-1);
  const img = ctx.getImageData(0, 0, W, H);
  const px = img.data;

  const toScreen = (v) => {
    const p = v.clone().applyMatrix4(M).project(cam);
    return { x: ((p.x + 1) / 2) * W, y: ((1 - p.y) / 2) * H, z: p.z, w: v.clone().applyMatrix4(M).z };
  };

  const tris = [];
  const pushTri = (a, b, c, col) => tris.push([a, b, c, col]);
  const pushQuad = (p0, p1, p2, p3, col) => { pushTri(p0, p1, p2, col); pushTri(p0, p2, p3, col); };

  // the item model
  const mats = [];
  const mesh = pose.kind === 'flat' ? extrudedIcon(pose.id, mats) : null;
  if (mesh) {
    const g = mesh.geometry;
    const pos = g.attributes.position.array, col = g.attributes.color.array, idx = g.index.array;
    for (let i = 0; i < idx.length; i += 3) {
      const t = [];
      for (let k = 0; k < 3; k++) {
        const j = idx[i + k];
        t.push(new THREE.Vector3(pos[j * 3], pos[j * 3 + 1], pos[j * 3 + 2]));
      }
      pushTri(t[0], t[1], t[2], [col[idx[i] * 3], col[idx[i] * 3 + 1], col[idx[i] * 3 + 2]]);
      tris[tris.length - 1][4] = 1; // the item
    }
  }
  // held block: a cube with six shaded faces
  if (pose.kind === 'block') {
    const h = 0.5, c = [[h, h, h], [-h, h, h], [-h, -h, h], [h, -h, h], [h, h, -h], [-h, h, -h], [-h, -h, -h], [h, -h, -h]]
      .map(([x, y, z]) => new THREE.Vector3(x, y, z));
    const faces = [[0, 1, 2, 3, [0.55, 0.4, 0.25]], [4, 5, 6, 7, [0.4, 0.3, 0.18]], [0, 1, 5, 4, [0.7, 0.55, 0.35]],
      [3, 2, 6, 7, [0.35, 0.25, 0.15]], [1, 2, 6, 5, [0.62, 0.48, 0.3]], [0, 3, 7, 4, [0.5, 0.38, 0.22]]];
    for (const [a, b, cc, d, col] of faces) { pushQuad(c[a], c[b], c[cc], c[d], col); tris[tris.length - 1][4] = 1; tris[tris.length - 2][4] = 1; }
  }
  // the arm
  let armId = 2;
  for (const b of armBoxes(pose)) {
    const [cx, cy, cz] = b.centre, [sx, sy, sz] = b.size;
    const v = new THREE.Vector3();
    const corner = (dx, dy, dz) => {
      v.set(cx + dx * sx / 2, cy + dy * sy / 2, cz + dz * sz / 2);
      return v.clone().applyMatrix4(b.matrix);
    };
    const P = [corner(-1, -1, 1), corner(1, -1, 1), corner(1, 1, 1), corner(-1, 1, 1),
      corner(-1, -1, -1), corner(1, -1, -1), corner(1, 1, -1), corner(-1, 1, -1)];
    const shade = (f) => b.colour.map((x) => x * f);
    pushQuad(P[0], P[1], P[2], P[3], shade(1.0));
    pushQuad(P[5], P[4], P[7], P[6], shade(0.85));
    pushQuad(P[4], P[0], P[3], P[7], shade(0.78));
    pushQuad(P[1], P[5], P[6], P[2], shade(0.78));
    pushQuad(P[3], P[2], P[6], P[7], shade(1.12));
    pushQuad(P[4], P[5], P[1], P[0], shade(0.55));
    for (let i = tris.length - 12; i < tris.length; i++) tris[i][4] = armId;
    armId++;
  }

  // z-buffered scanline fill
  let bbox = { x0: W, y0: H, x1: 0, y1: -1 };
  for (const t of tris) {
    const s = t.slice(0, 3).map(toScreen);
    const col = t[3];
    if (s.some((p) => p.w > -0.05)) continue;
    const minX = Math.max(0, Math.floor(Math.min(s[0].x, s[1].x, s[2].x)));
    const maxX = Math.min(W - 1, Math.ceil(Math.max(s[0].x, s[1].x, s[2].x)));
    const minY = Math.max(0, Math.floor(Math.min(s[0].y, s[1].y, s[2].y)));
    const maxY = Math.min(H - 1, Math.ceil(Math.max(s[0].y, s[1].y, s[2].y)));
    const area = (s[1].x - s[0].x) * (s[2].y - s[0].y) - (s[2].x - s[0].x) * (s[1].y - s[0].y);
    if (Math.abs(area) < 1e-9) continue;
    bbox = { x0: Math.min(bbox.x0, minX), y0: Math.min(bbox.y0, minY), x1: Math.max(bbox.x1, maxX), y1: Math.max(bbox.y1, maxY) };
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      const pxc = x + 0.5, pyc = y + 0.5;
      const w0 = ((s[1].x - pxc) * (s[2].y - pyc) - (s[2].x - pxc) * (s[1].y - pyc)) / area;
      const w1 = ((s[2].x - pxc) * (s[0].y - pyc) - (s[0].x - pxc) * (s[2].y - pyc)) / area;
      const w2 = 1 - w0 - w1;
      if (w0 < 0 || w1 < 0 || w2 < 0) continue;
      const z = w0 * s[0].z + w1 * s[1].z + w2 * s[2].z;
      const o = y * W + x;
      if (z <= zbuf[o]) continue;
      zbuf[o] = z; idbuf[o] = t[4] ?? 0;
      px[o * 4] = Math.min(255, col[0] * 255);
      px[o * 4 + 1] = Math.min(255, col[1] * 255);
      px[o * 4 + 2] = Math.min(255, col[2] * 255);
      px[o * 4 + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  // crosshair + frame
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.fillRect(W / 2 - 9, H / 2 - 1, 18, 2); ctx.fillRect(W / 2 - 1, H / 2 - 9, 2, 18);
  ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2; ctx.strokeRect(1, 1, W - 2, H - 2);
  writeFileSync(file, cv.toBuffer('image/png'));
  const pct = (v, m) => (100 * v / m).toFixed(1) + '%';
  console.log(`\n--- ${pose.label} --- bbox x[${pct(bbox.x0, W)}..${pct(bbox.x1, W)}] y[${pct(bbox.y0, H)}..${pct(bbox.y1, H)}]  -> ${file}`);
  const CH = [' ', 'O', 'S', 'A', 'F']; // O = item, S = sleeve, A = forearm, F = fist
  const ROWS = 30, COLS = 96;
  for (let r = 0; r < ROWS; r++) {
    let line = '';
    for (let c = 0; c < COLS; c++) {
      const x = Math.floor((c + 0.5) * W / COLS), y = Math.floor((r + 0.5) * H / ROWS);
      const id = idbuf[y * W + x];
      line += id < 0 ? '.' : CH[id];
    }
    console.log(line);
  }
  // how much of each part is on screen
  for (let id = 1; id <= 4; id++) {
    let n = 0;
    for (let i = 0; i < idbuf.length; i++) if (idbuf[i] === id) n++;
    if (n) console.log(`  ${CH[id]} ${['item', 'sleeve', 'forearm', 'fist'][id - 1].padEnd(8)} ${(100 * n / (W * H)).toFixed(2)}% of the frame`);
  }
  return bbox;
}

const out = process.argv[2] || '/tmp/held-pose.png';
const STYLE = { ry: -10, rz: -12, rx: -106, px: 0, py: -0.2, pz: 0 }; // TOOL_SWING.pickaxe
render({ kind: 'flat', id: 'iron_pickaxe', label: 'iron pickaxe (tool)' }, out.replace('.png', '-pickaxe.png'));
render({ kind: 'flat', id: 'iron_pickaxe', label: 'pickaxe, mid-swing (sp 0.25)', sp: 0.25, style: STYLE }, out.replace('.png', '-swing.png'));
render({ kind: 'flat', id: 'iron_sword', label: 'iron sword' }, out.replace('.png', '-sword.png'));
render({ kind: 'block', label: 'held block (cube)' }, out.replace('.png', '-block.png'));
render({ kind: 'flat', id: 'cooked_beef', label: 'food (not mirrored)' }, out.replace('.png', '-food.png'));
