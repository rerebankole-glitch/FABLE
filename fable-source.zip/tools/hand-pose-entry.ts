export { extrudedIcon } from '../src/game/core/ItemModel';
