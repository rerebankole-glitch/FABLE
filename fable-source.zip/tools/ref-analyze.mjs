// Coarse visual analysis of the reference screenshots: prints an ASCII map + colour clusters so the
// composition (arm angle, tool bbox) can be measured without an image viewer.
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { readdirSync } from 'node:fs';

const dir = '/home/user/FABLE';
const files = process.argv.slice(2).length ? process.argv.slice(2)
  : readdirSync(dir).filter((f) => /\.(jpeg|jpg|png|gif)$/i.test(f)).sort();

const COLS = Number(process.env.COLS || 78);

function classify(r, g, b) {
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
  const sat = mx === 0 ? 0 : (mx - mn) / mx;
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  // skin / tan
  if (r > 120 && r > g + 18 && g > b + 8 && sat > 0.18 && lum > 0.28 && lum < 0.85) return 'S';
  // wood brown (darker, low-ish sat)
  if (r > 70 && r > g && g >= b && sat > 0.2 && lum < 0.55) return 'w';
  // green (grass/leaves)
  if (g > r + 12 && g > b + 12) return 'g';
  // blue sky / water
  if (b > r + 20 && b > g + 5) return 'b';
  if (sat < 0.14) {
    if (lum > 0.85) return '.';
    if (lum > 0.6) return ':';
    if (lum > 0.35) return '+';
    if (lum > 0.14) return '*';
    return '#';
  }
  if (lum > 0.6) return '-';
  return 'o';
}

for (const f of files) {
  const path = f.includes('/') ? f : `${dir}/${f}`;
  let img;
  try { img = await loadImage(path); } catch (e) { console.log(`${f}: cannot decode (${e.message})`); continue; }
  const W = img.width, H = img.height;
  const rows = Math.max(6, Math.round((COLS * H) / W / 2));
  const c = createCanvas(COLS, rows);
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0, COLS, rows);
  const d = ctx.getImageData(0, 0, COLS, rows).data;
  console.log(`\n=== ${f.replace(dir + '/', '')}  ${W}x${H}  (aspect ${(W / H).toFixed(3)}) ===`);
  const lines = [];
  for (let y = 0; y < rows; y++) {
    let line = '';
    for (let x = 0; x < COLS; x++) {
      const i = (y * COLS + x) * 4;
      line += classify(d[i], d[i + 1], d[i + 2]);
    }
    lines.push(line);
  }
  console.log(lines.join('\n'));
}
