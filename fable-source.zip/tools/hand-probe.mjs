// Measures where the first-person viewmodel actually lands on screen.
//
// It reproduces the shipped transform stack exactly:
//   buildItemChain(sp=1 rest, equip 0)  ->  updateHand's fovK compensation  ->  hand group
//   (item plate at z 0.5 + arm group)   ->  perspective projection (hand pass, fov 70 @ 16:9)
// and prints screen fractions (0,0 = top-left, 1,1 = bottom-right) for the plate corners, the
// fist anchor and the arm's shoulder/hand ends, plus the on-screen arm angle and the plate's
// perspective shear. Numbers here are the ground truth for "does the hand hold the item".
import * as THREE from 'three';

const D = Math.PI / 180;

// ---- shipped constants (src/game/core/Game.ts) ----
export const CFG = {
  HELD_POS: { x: 0.65, y: -0.517 },
  HELD_PZ: -1.5,
  HELD_THETA: 7 * D,
  HELD_SCALE: 1.0,
  HELD_FIST: { x: 0.08, y: 0.06 },
  HELD_ARM_S: 0.075,
  HELD_ARM_PHI: 0.3,
  ITEM_BASE: [0.56, -0.52, -0.71999997],
  SCALE: 0.4,
  FOV: 75,
  ASPECT: 16 / 9,
  HAND_FOV: 70,
  ARM: { x0: -8, x1: -4, y0: 0, y1: 12, z0: -2, z1: 2 }, // model px (regular / non-slim arm)
};

/** Rebuild the shipped buildItemChain for the resting pose (sp = 1, equip 0, no eat/bow). */
export function plateMatrix(cfg = CFG, { sp = 1, equip = 0, fovCompensate = true } = {}) {
  const mv = new THREE.Matrix4();
  mv.identity();
  mv.multiply(new THREE.Matrix4().makeTranslation(cfg.ITEM_BASE[0], cfg.ITEM_BASE[1], cfg.ITEM_BASE[2]));
  const eq = equip * equip * (3 - 2 * equip);
  mv.multiply(new THREE.Matrix4().makeTranslation(0, eq * -0.6, 0));
  mv.multiply(new THREE.Matrix4().makeRotationY(Math.PI / 4));
  mv.multiply(new THREE.Matrix4().makeScale(cfg.SCALE, cfg.SCALE, cfg.SCALE));
  // flat branch
  mv.multiply(new THREE.Matrix4().makeTranslation(cfg.HELD_POS.x, cfg.HELD_POS.y, cfg.HELD_PZ));
  mv.multiply(new THREE.Matrix4().makeRotationZ(cfg.HELD_THETA));
  mv.multiply(new THREE.Matrix4().makeScale(cfg.HELD_SCALE, cfg.HELD_SCALE, cfg.HELD_SCALE));
  const pos = new THREE.Vector3(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  mv.decompose(pos, q, s);
  // updateHand: position *= fovK, scale = fovK * s.x, rotation unchanged
  const fovK = Math.tan(D * 35) / Math.tan((fovCompensate ? cfg.FOV : cfg.HAND_FOV) * D / 2);
  const hand = new THREE.Matrix4().compose(pos.clone().multiplyScalar(fovK), q, new THREE.Vector3().setScalar(fovK * s.x));
  return { hand, fovK };
}

/** Shipped arm group placement (buildHandContent, held-item branch). */
export function armGroupMatrix(cfg = CFG) {
  const g = new THREE.Matrix4();
  const c = Math.cos(cfg.HELD_ARM_PHI), sn = Math.sin(cfg.HELD_ARM_PHI);
  const fx = (-6 * c - 12 * sn) * cfg.HELD_ARM_S, fy = (-6 * sn + 12 * c) * cfg.HELD_ARM_S;
  g.makeRotationZ(cfg.HELD_ARM_PHI);
  g.premultiply(new THREE.Matrix4().makeScale(cfg.HELD_ARM_S, cfg.HELD_ARM_S, cfg.HELD_ARM_S));
  g.premultiply(new THREE.Matrix4().makeTranslation(cfg.HELD_FIST.x - fx, cfg.HELD_FIST.y - fy, 0.5));
  return g;
}

export function project(cam, v) {
  const p = v.clone().project(cam); // NDC
  return { x: (p.x + 1) / 2, y: (1 - p.y) / 2, z: p.z };
}

export function makeCamera(cfg = CFG) {
  return new THREE.PerspectiveCamera(cfg.FOV, cfg.ASPECT, 0.05, 600);
}

export function report(cfg = CFG, label = 'shipped') {
  const cam = makeCamera(cfg);
  cam.updateMatrixWorld(); cam.updateProjectionMatrix();
  const { hand, fovK } = plateMatrix(cfg);
  const arm = armGroupMatrix(cfg);
  const M = (local) => new THREE.Vector3(local[0], local[1], local[2]).applyMatrix4(hand);
  const A = (local) => new THREE.Vector3(local[0], local[1], local[2]).applyMatrix4(arm).applyMatrix4(hand);

  const corners = {
    'plate BL': project(cam, M([0, 0, 0.5])),
    'plate BR': project(cam, M([1, 0, 0.5])),
    'plate TL': project(cam, M([0, 1, 0.5])),
    'plate TR': project(cam, M([1, 1, 0.5])),
  };
  const fist = project(cam, M([cfg.HELD_FIST.x, cfg.HELD_FIST.y, 0.5]));
  const A0 = cfg.ARM;
  const shoulder = project(cam, A([(A0.x0 + A0.x1) / 2, A0.y0, 0]));
  const handEnd = project(cam, A([(A0.x0 + A0.x1) / 2, A0.y1, 0]));
  const armOutL = project(cam, A([A0.x0, A0.y0, A0.z0]));
  const armOutR = project(cam, A([A0.x1, A0.y0, A0.z0]));
  const p = (o) => `(${(o.x * 100).toFixed(1)}%, ${(o.y * 100).toFixed(1)}%)`;
  const w = Math.abs(corners['plate TR'].x - corners['plate TL'].x);
  const hTop = Math.abs(corners['plate TL'].y - corners['plate BL'].y);
  const hBot = Math.abs(corners['plate TR'].y - corners['plate BR'].y);
  const armAng = Math.atan2((handEnd.y - shoulder.y) * (1 / cfg.ASPECT), handEnd.x - shoulder.x) * 180 / Math.PI;
  const armW = Math.hypot((armOutR.x - armOutL.x), (armOutR.y - armOutL.y) / cfg.ASPECT);
  console.log(`--- ${label} --- fovK ${fovK.toFixed(4)}`);
  for (const [k, v] of Object.entries(corners)) console.log(`  ${k.padEnd(9)} ${p(v)}`);
  console.log(`  fist      ${p(fist)}`);
  console.log(`  arm hand  ${p(handEnd)}   arm shoulder ${p(shoulder)}`);
  console.log(`  plate right-edge height ${(hBot * 100).toFixed(1)}% screenH, left-edge ${(hTop * 100).toFixed(1)}% screenH  (shear ${(100 * (hTop - hBot) / hTop).toFixed(1)}%)`);
  console.log(`  plate width ${(w * 100).toFixed(1)}% screenW`);
  console.log(`  arm axis on screen: ${armAng.toFixed(1)} deg (0 = horizontal right, + = down-right)`);
  console.log(`  arm width ${(armW * 100).toFixed(1)}% screenW (${(armW * 100 * cfg.ASPECT).toFixed(1)}% screenH across)`);
  // depth spread across the plate: how much the plate recedes (perspective shear driver)
  const zl = M([0, 0, 0.5]).z, zr = M([1, 0, 0.5]).z;
  console.log(`  plate depth: left z ${zl.toFixed(3)} -> right z ${zr.toFixed(3)} (camera-space)`);
  return { corners, fist, shoulder, handEnd, armAng, armW, hTop, hBot, zl, zr };
}

if (import.meta.url === `file://${process.argv[1]}`) report();
