// Dumps the real item icons (src/game/items/Icons.ts) as ASCII + PNG using a node canvas, so the
// first-person extrusion can be measured against the actual art (where the handle is, where the
// head is) without a browser.
import { build } from 'esbuild';
import { createCanvas } from '@napi-rs/canvas';
import { writeFileSync } from 'node:fs';

// --- minimal DOM so Icons.ts can run unchanged ---
const canvases = [];
globalThis.document = {
  createElement(tag) {
    if (tag !== 'canvas') throw new Error('unexpected element ' + tag);
    const c = createCanvas(1, 1);
    const orig = c.getContext.bind(c);
    c.getContext = (t, o) => orig(t, o);
    canvases.push(c);
    return c;
  },
};
globalThis.HTMLCanvasElement = createCanvas(1, 1).constructor;
globalThis.Image = createCanvas(1, 1).constructor;

await build({
  entryPoints: ['src/game/items/Icons.ts'],
  bundle: true, platform: 'node', format: 'esm', outfile: '/tmp/icons-bundle.mjs', logLevel: 'error',
});
const { itemPixels, ICON_PX } = await import('/tmp/icons-bundle.mjs');

const ids = process.argv.slice(2);
const N = ICON_PX;
for (const id of ids) {
  const img = itemPixels(id);
  const d = img.data;
  console.log(`\n=== ${id} (${N}x${N}) ===`);
  let minX = N, maxX = -1, minY = N, maxY = -1, n = 0;
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    if (d[(y * N + x) * 4 + 3] > 40) { n++; if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
  }
  console.log(`  opaque ${n} px (${(100 * n / (N * N)).toFixed(1)}%), bbox icon-x ${minX}..${maxX}, icon-y ${minY}..${maxY}`);
  for (let y = 0; y < N; y++) {
    let line = '';
    for (let x = 0; x < N; x++) {
      const i = (y * N + x) * 4;
      const a = d[i + 3];
      if (a <= 40) { line += ' '; continue; }
      const lum = (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]) / 255;
      line += lum > 0.72 ? '@' : lum > 0.55 ? '#' : lum > 0.38 ? '+' : lum > 0.22 ? '.' : ':';
    }
    console.log('  ' + line);
  }
}

// sprite sheet of everything requested, for the user to eyeball
if (ids.length) {
  const cols = Math.min(8, ids.length), rows = Math.ceil(ids.length / cols);
  const S = 48;
  const sheet = createCanvas(cols * S, rows * S);
  const ctx = sheet.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ids.forEach((id, k) => {
    const img = itemPixels(id);
    const tmp = createCanvas(N, N);
    tmp.getContext('2d').putImageData(new (Object.getPrototypeOf(img).constructor)(img.data, N, N), 0, 0);
    ctx.drawImage(tmp, (k % cols) * S, Math.floor(k / cols) * S, S, S);
  });
  writeFileSync('/tmp/icons-sheet.png', sheet.toBuffer('image/png'));
  console.log('\nsheet -> /tmp/icons-sheet.png');
}
