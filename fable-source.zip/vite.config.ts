import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { viteSingleFile } from 'vite-plugin-singlefile';
import path from 'path';

export default defineConfig({
  plugins: [react(), tailwindcss(), viteSingleFile()],
  resolve: { alias: { '@': path.resolve(__dirname, './src') } },
  // classic (IIFE) worker: module workers from blob: URLs are refused when the single-file build is opened via file://
  worker: { format: 'iife' },
  build: { target: 'es2022', assetsInlineLimit: 100000000, chunkSizeWarningLimit: 100000000, cssCodeSplit: false },
  server: { host: '0.0.0.0', port: 5173, allowedHosts: true },
  preview: { host: '0.0.0.0', port: 4173, allowedHosts: true },
});
