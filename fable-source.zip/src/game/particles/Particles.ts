import * as THREE from 'three';
import { getAtlas } from '../blocks/TextureAtlas';
import { BLOCKS } from '../blocks/Blocks';
import { ATLAS_COLS, ATLAS_ROWS } from '../blocks/Tiles';
import { T } from '../blocks/Tiles';

interface Particle {
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  life: number; maxLife: number;
  size: number;
  u: number; v: number; // uv offset within tile (0..0.75)
  uvSize: number;       // fraction of the tile sampled
  tile: number;
  r: number; g: number; b: number;
  gravity: number;
  collide: boolean;
  fade: boolean;
  drag: number;
}

const MAX = 2000;

/**
 * Billboard particle system rendered as a single THREE.Points object with a custom shader.
 * `points` must be added to the scene by the owner; `getBlock` is used for collisions.
 */
export class ParticleSystem {
  points: THREE.Points;
  /** 0 = none, 1 = reduced, 2 = all */
  quality = 2;
  getBlock: (x: number, y: number, z: number) => number = () => 0;
  private particles: Particle[] = [];
  private pos: Float32Array;
  private uvs: Float32Array;
  private cols: Float32Array;
  private sizes: Float32Array;
  private geo: THREE.BufferGeometry;
  private mat: THREE.ShaderMaterial;
  /** Number of live particles. */
  get count(): number { return this.particles.length; }

  constructor() {
    this.pos = new Float32Array(MAX * 3);
    this.uvs = new Float32Array(MAX * 3);
    this.cols = new Float32Array(MAX * 3);
    this.sizes = new Float32Array(MAX);
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aUv', new THREE.BufferAttribute(this.uvs, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aCol', new THREE.BufferAttribute(this.cols, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aSize', new THREE.BufferAttribute(this.sizes, 1).setUsage(THREE.DynamicDrawUsage));
    this.geo.setDrawRange(0, 0);
    this.geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.mat = new THREE.ShaderMaterial({
      uniforms: { uAtlas: { value: getAtlas().texture }, uScale: { value: 600 } },
      vertexShader: /* glsl */ `
        attribute vec3 aUv;
        attribute vec3 aCol;
        attribute float aSize;
        uniform float uScale;
        varying vec3 vUv;
        varying vec3 vCol;
        void main() {
          vUv = aUv;
          vCol = aCol;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = aSize * uScale / max(0.5, -mv.z);
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: /* glsl */ `
        uniform sampler2D uAtlas;
        varying vec3 vUv;
        varying vec3 vCol;
        void main() {
          vec2 uv = vUv.xy + gl_PointCoord * vUv.z;
          vec4 t = texture2D(uAtlas, uv);
          if (t.a < 0.4) discard;
          // atlas sample is linear (encode it); vCol is an authored display-space colour
          gl_FragColor = vec4(pow(t.rgb, vec3(1.0 / 2.2)) * vCol, 1.0);
        }
      `,
      transparent: false,
      depthWrite: true,
    });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 4;
  }

  private add(p: Particle): void {
    if (this.quality === 0) return;
    if (this.quality === 1 && Math.random() < 0.5) return;
    if (this.particles.length >= MAX) this.particles.shift();
    this.particles.push(p);
  }

  private static tileFor(color: [number, number, number] | undefined): { tile: number; r: number; g: number; b: number } {
    // Particles use the plain white tile tinted with the average block colour: this keeps them readable at any size.
    if (!color) return { tile: T.white, r: 1, g: 1, b: 1 };
    return { tile: T.white, r: color[0], g: color[1], b: color[2] };
  }

  /** Burst when a block is destroyed. */
  blockBreak(x: number, y: number, z: number, color?: [number, number, number]): void {
    const t = ParticleSystem.tileFor(color);
    for (let i = 0; i < 20; i++) {
      const shade = 0.75 + Math.random() * 0.35;
      this.add({
        x: x + 0.1 + Math.random() * 0.8, y: y + 0.1 + Math.random() * 0.8, z: z + 0.1 + Math.random() * 0.8,
        vx: (Math.random() - 0.5) * 3.5, vy: Math.random() * 4 + 1, vz: (Math.random() - 0.5) * 3.5,
        life: 0, maxLife: 0.6 + Math.random() * 0.6, size: 0.09 + Math.random() * 0.07,
        u: 0.25, v: 0.25, uvSize: 0.5, tile: t.tile, r: t.r * shade, g: t.g * shade, b: t.b * shade, gravity: 14, collide: true, fade: false, drag: 1.5,
      });
    }
  }

  /** Small chips flying off the face being mined. */
  blockHit(x: number, y: number, z: number, nx: number, ny: number, nz: number, color?: [number, number, number]): void {
    const t = ParticleSystem.tileFor(color);
    const n = this.quality === 2 ? 2 : 1;
    for (let i = 0; i < n; i++) {
      const px = x + 0.5 + nx * 0.55 + (nx ? 0 : (Math.random() - 0.5) * 0.8);
      const py = y + 0.5 + ny * 0.55 + (ny ? 0 : (Math.random() - 0.5) * 0.8);
      const pz = z + 0.5 + nz * 0.55 + (nz ? 0 : (Math.random() - 0.5) * 0.8);
      const shade = 0.75 + Math.random() * 0.35;
      this.add({
        x: px, y: py, z: pz, vx: nx * 1.5 + (Math.random() - 0.5), vy: ny * 1.5 + Math.random() * 1.5, vz: nz * 1.5 + (Math.random() - 0.5),
        life: 0, maxLife: 0.4 + Math.random() * 0.3, size: 0.07, u: 0.25, v: 0.25, uvSize: 0.5, tile: t.tile, r: t.r * shade, g: t.g * shade, b: t.b * shade,
        gravity: 14, collide: true, fade: false, drag: 1.5,
      });
    }
  }

  smoke(x: number, y: number, z: number, count = 1, dark = false): void {
    for (let i = 0; i < count; i++) {
      const s = (dark ? 0.2 : 0.55) + Math.random() * 0.15;
      this.add({
        x: x + (Math.random() - 0.5) * 0.4, y, z: z + (Math.random() - 0.5) * 0.4,
        vx: (Math.random() - 0.5) * 0.3, vy: 0.6 + Math.random() * 0.6, vz: (Math.random() - 0.5) * 0.3,
        life: 0, maxLife: 1 + Math.random(), size: 0.12 + Math.random() * 0.08, u: 0.25, v: 0.25, uvSize: 0.5, tile: T.white, r: s, g: s, b: s,
        gravity: -0.4, collide: false, fade: true, drag: 0.5,
      });
    }
  }

  flame(x: number, y: number, z: number, count = 1): void {
    for (let i = 0; i < count; i++) {
      this.add({
        x: x + (Math.random() - 0.5) * 0.5, y, z: z + (Math.random() - 0.5) * 0.5,
        vx: 0, vy: 0.4 + Math.random() * 0.5, vz: 0,
        life: 0, maxLife: 0.5 + Math.random() * 0.4, size: 0.08, u: 0.25, v: 0.25, uvSize: 0.5, tile: T.white, r: 1, g: 0.6 + Math.random() * 0.3, b: 0.1,
        gravity: 0, collide: false, fade: true, drag: 0,
      });
    }
  }

  splash(x: number, y: number, z: number, count = 8): void {
    for (let i = 0; i < count; i++) {
      this.add({
        x: x + (Math.random() - 0.5) * 0.6, y, z: z + (Math.random() - 0.5) * 0.6,
        vx: (Math.random() - 0.5) * 2.5, vy: 2 + Math.random() * 3, vz: (Math.random() - 0.5) * 2.5,
        life: 0, maxLife: 0.5 + Math.random() * 0.4, size: 0.07, u: 0.25, v: 0.25, uvSize: 0.5, tile: T.white, r: 0.5, g: 0.65, b: 1,
        gravity: 14, collide: false, fade: true, drag: 1,
      });
    }
  }

  /** Damage particles (red) or critical hit sparks (yellow). */
  hit(x: number, y: number, z: number, crit = false): void {
    const n = crit ? 12 : 5;
    for (let i = 0; i < n; i++) {
      this.add({
        x: x + (Math.random() - 0.5) * 0.6, y: y + Math.random() * 1.2, z: z + (Math.random() - 0.5) * 0.6,
        vx: (Math.random() - 0.5) * 3, vy: Math.random() * 3, vz: (Math.random() - 0.5) * 3,
        life: 0, maxLife: 0.4 + Math.random() * 0.3, size: 0.08, u: 0.25, v: 0.25, uvSize: 0.5, tile: T.white,
        r: crit ? 1 : 0.9, g: crit ? 0.9 : 0.15, b: crit ? 0.3 : 0.15, gravity: crit ? 4 : 10, collide: false, fade: true, drag: 1.5,
      });
    }
  }

  /** Floating coloured sparkles (portals, enchanting, healing...). */
  magic(x: number, y: number, z: number, count = 6, color: [number, number, number] = [0.8, 0.5, 1]): void {
    for (let i = 0; i < count; i++) {
      this.add({
        x: x + (Math.random() - 0.5) * 1.2, y: y + (Math.random() - 0.2) * 1.5, z: z + (Math.random() - 0.5) * 1.2,
        vx: (Math.random() - 0.5) * 0.6, vy: 0.3 + Math.random() * 0.8, vz: (Math.random() - 0.5) * 0.6,
        life: 0, maxLife: 0.8 + Math.random() * 0.7, size: 0.05 + Math.random() * 0.05, u: 0.25, v: 0.25, uvSize: 0.5, tile: T.white,
        r: color[0], g: color[1], b: color[2], gravity: -0.2, collide: false, fade: true, drag: 0.4,
      });
    }
  }

  explosion(x: number, y: number, z: number, radius = 3): void {
    for (let i = 0; i < 60; i++) {
      const dx = Math.random() - 0.5, dy = Math.random() - 0.5, dz = Math.random() - 0.5;
      const l = Math.hypot(dx, dy, dz) || 1;
      const sp = Math.random() * radius * 3;
      const grey = 0.3 + Math.random() * 0.5;
      this.add({
        x, y, z, vx: dx / l * sp, vy: dy / l * sp + 2, vz: dz / l * sp,
        life: 0, maxLife: 0.8 + Math.random() * 0.8, size: 0.2 + Math.random() * 0.3, u: 0.25, v: 0.25, uvSize: 0.5, tile: T.white, r: grey, g: grey, b: grey,
        gravity: 2, collide: false, fade: true, drag: 2,
      });
    }
    for (let i = 0; i < 20; i++) {
      this.add({
        x, y, z, vx: (Math.random() - 0.5) * radius * 4, vy: Math.random() * radius * 3, vz: (Math.random() - 0.5) * radius * 4,
        life: 0, maxLife: 0.4 + Math.random() * 0.4, size: 0.15, u: 0.25, v: 0.25, uvSize: 0.5, tile: T.white, r: 1, g: 0.7, b: 0.2,
        gravity: 6, collide: false, fade: true, drag: 1.5,
      });
    }
  }

  drip(x: number, y: number, z: number, lava: boolean): void {
    this.add({
      x, y, z, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 2, size: 0.06, u: 0.25, v: 0.25, uvSize: 0.5, tile: T.white,
      r: lava ? 1 : 0.4, g: lava ? 0.5 : 0.6, b: lava ? 0.1 : 1, gravity: 12, collide: true, fade: false, drag: 0,
    });
  }

  /**
   * Point sprites are sized in device pixels: `size` is the particle's world-space diameter, so the pixel size is
   * size * (viewportHeight / (2 * tan(fov/2))) / depth. Call this whenever the viewport, pixel ratio or FOV changes.
   */
  setView(heightPx: number, fovDeg: number): void {
    const f = heightPx / (2 * Math.tan((fovDeg * Math.PI) / 360));
    this.mat.uniforms.uScale.value = f;
  }

  update(dt: number): void {
    const ps = this.particles;
    let w = 0;
    const solid = (x: number, y: number, z: number) => { const id = this.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)); return id !== 0 && !!BLOCKS[id]?.solid; };
    for (let i = 0; i < ps.length; i++) {
      const p = ps[i];
      p.life += dt;
      if (p.life >= p.maxLife) continue;
      p.vy -= p.gravity * dt;
      const d = Math.max(0, 1 - dt * p.drag);
      p.vx *= d; p.vz *= d;
      const nx = p.x + p.vx * dt, ny = p.y + p.vy * dt, nz = p.z + p.vz * dt;
      if (p.collide) {
        if (solid(p.x, ny, p.z)) { if (p.vy < 0) { p.vy = 0; p.vx *= 0.6; p.vz *= 0.6; } else p.vy = 0; }
        else p.y = ny;
        if (!solid(nx, p.y, p.z)) p.x = nx; else p.vx = 0;
        if (!solid(p.x, p.y, nz)) p.z = nz; else p.vz = 0;
      } else { p.x = nx; p.y = ny; p.z = nz; }
      ps[w] = p;
      const t = p.life / p.maxLife;
      const size = p.fade ? p.size * (1 - t * 0.7) : p.size;
      const o3 = w * 3;
      this.pos[o3] = p.x; this.pos[o3 + 1] = p.y; this.pos[o3 + 2] = p.z;
      const col = p.tile % ATLAS_COLS, row = Math.floor(p.tile / ATLAS_COLS);
      this.uvs[o3] = (col + p.u) / ATLAS_COLS; this.uvs[o3 + 1] = (row + p.v) / ATLAS_ROWS; this.uvs[o3 + 2] = p.uvSize / ATLAS_COLS;
      const fade = p.fade ? 1 - t * 0.6 : 1;
      this.cols[o3] = p.r * fade; this.cols[o3 + 1] = p.g * fade; this.cols[o3 + 2] = p.b * fade;
      this.sizes[w] = size;
      w++;
    }
    ps.length = w;
    this.geo.setDrawRange(0, w);
    if (w > 0 || this.geo.drawRange.count > 0) {
      (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
      (this.geo.attributes.aUv as THREE.BufferAttribute).needsUpdate = true;
      (this.geo.attributes.aCol as THREE.BufferAttribute).needsUpdate = true;
      (this.geo.attributes.aSize as THREE.BufferAttribute).needsUpdate = true;
    }
    this.points.visible = w > 0;
  }

  clear(): void {
    this.particles.length = 0;
    this.geo.setDrawRange(0, 0);
  }

  dispose(): void {
    this.geo.dispose();
    this.mat.dispose();
  }
}
