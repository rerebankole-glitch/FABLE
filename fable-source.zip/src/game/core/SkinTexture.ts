import * as THREE from 'three';

/**
 * Player skin textures: upload decoding, classic-64x32 conversion, the baked 64x64 canvas cache and
 * the vanilla voxel figure built from a skin. A "skin" is always normalized to a 64x64 canvas here;
 * anything else square is nearest-neighbour sampled down, and classic 2:1 layouts (64x32, 128x64, …)
 * are expanded to the modern layout (the right half of the figure mirrored over to the left side).
 */
export const SKIN_W = 64;

const canvasCache = new Map<string, HTMLCanvasElement>();
const busy = new Map<string, Promise<void>>();

export interface SkinInfo {
  url: string;
  name: string;
  /** slim (3px) arms were detected on this skin */
  slim: boolean;
  /** the baked, normalized 64x64 canvas */
  canvas: HTMLCanvasElement;
}

export type SkinLoadResult = { ok: true; skin: SkinInfo } | { ok: false; error: string }

function loadImageEl(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('decode failed'));
    img.src = src;
  });
}

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error('read failed'));
    fr.readAsDataURL(file);
  });
}

function newCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return [c, c.getContext('2d')!];
}

function drawNearest(ctx: CanvasRenderingContext2D, img: CanvasImageSource, dw: number, dh: number): void {
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, dw, dh);
  ctx.drawImage(img, 0, 0, dw, dh);
}

/** Nearest-sample any square skin down/up to 64x64. */
export function bakeSquare(img: CanvasImageSource): HTMLCanvasElement {
  const [c, g] = newCanvas(SKIN_W, SKIN_W);
  drawNearest(g, img, SKIN_W, SKIN_W);
  return c;
}

/**
 * Expand a classic 2:1 skin (only the right half of the figure is painted) into the modern 64x64
 * layout: rows 0-31 (head, body, right arm, right leg + their top faces) copy straight; the left arm
 * and left leg are built by mirroring the right side's faces, and overlay regions stay transparent.
 */
export function convertClassic(img: CanvasImageSource): HTMLCanvasElement {
  // normalize the 2:1 source into the top half of a 64x64 working canvas (1:1 pixels)
  const [src, sg] = newCanvas(SKIN_W, SKIN_W);
  sg.imageSmoothingEnabled = false;
  sg.drawImage(img, 0, 0, SKIN_W, SKIN_W / 2);
  const [c, g] = newCanvas(SKIN_W, SKIN_W);
  g.imageSmoothingEnabled = false;
  g.drawImage(src, 0, 0, SKIN_W, SKIN_W / 2, 0, 0, SKIN_W, SKIN_W / 2); // rows 0-31 stay 1:1
  const srcPx = sg.getImageData(0, 0, SKIN_W, SKIN_W).data;
  // mirror helper: copies a face rect, flips it horizontally at the pixel level and paints it at
  // the destination slot (pixel-level, so it works on every canvas implementation)
  const mirror = (sx: number, sy: number, dx: number, dy: number, w: number, h: number) => {
    const out = g.createImageData(w, h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const s = ((sy + y) * SKIN_W + (sx + x)) * 4;
        const o = (y * w + (w - 1 - x)) * 4;
        out.data[o] = srcPx[s]; out.data[o + 1] = srcPx[s + 1]; out.data[o + 2] = srcPx[s + 2]; out.data[o + 3] = srcPx[s + 3];
      }
    }
    g.putImageData(out, dx, dy);
  };
  // ---- left arm: destination net (32,48) 16 wide x 16 tall (rows 48-63). Face slots for a
  // 4-deep/4-wide arm: left=32-35, front=36-39, right=40-43, back=44-47 (same row band per face).
  // Right arm source net: (40,16): left=40-43, front=44-47, right=48-51, back=52-55, rows 16-31.
  const H = 12; // side face height rows
  // side faces: right arm rows 20..31 -> left arm rows 52..63
  mirror(48, 20, 32, 52, 4, H); // src right face  -> dst left face
  mirror(44, 20, 36, 52, 4, H); // src front face  -> dst front face
  mirror(40, 20, 40, 52, 4, H); // src left face   -> dst right face
  mirror(52, 20, 44, 52, 4, H); // src back face   -> dst back face
  // top face (src rows 16..19 at cols 44..47 -> dst rows 48..51 cols 36..39) and bottom face
  mirror(44, 16, 36, 48, 4, 4);
  mirror(44, 28, 36, 60, 4, 4);
  // ---- left leg: destination net (16,48): left=16-19, front=20-23, right=24-27, back=28-31 rows 48-63.
  // Right leg source net: (0,16): left=0-3, front=4-7, right=8-11, back=12-15.
  mirror(8, 20, 16, 52, 4, H);  // src right -> dst left
  mirror(4, 20, 20, 52, 4, H);  // src front -> dst front
  mirror(0, 20, 24, 52, 4, H);  // src left  -> dst right
  mirror(12, 20, 28, 52, 4, H); // src back  -> dst back
  mirror(4, 16, 20, 48, 4, 4);  // top
  mirror(4, 28, 20, 60, 4, 4);  // bottom
  return c;
}

/** The right-arm base net spans atlas columns 40-56. Wide arms fill all 16 columns; slim (3px)
 *  arms stop after 14, leaving the last two columns transparent. */
export function guessSlim(c: HTMLCanvasElement): boolean {
  const g = c.getContext('2d', { willReadFrequently: true });
  if (!g) return false;
  const d = g.getImageData(0, 0, SKIN_W, SKIN_W).data;
  const ink = (x: number) => { let n = 0; for (let y = 20; y < 32; y++) if (d[(y * SKIN_W + x) * 4 + 3] > 100) n++; return n; };
  // column 55 (and 54) belong to the arm's back face on wide skins only
  const wideBack = ink(55) + ink(54);
  // sanity: the face/sleeve columns must actually exist (avoid guessing on empty/edge skins)
  let face = 0; for (let x = 44; x < 48; x++) face += ink(x);
  return face > 12 && wideBack < 4;
}

/** Ensure the baked canvas for `url` exists (idempotent; safe to call repeatedly). */
export function prepareSkinCanvas(url: string): Promise<void> {
  if (!url || canvasCache.has(url)) return Promise.resolve();
  let p = busy.get(url);
  if (!p) {
    p = (async () => {
      try {
        const img = await loadImageEl(url);
        if (!img.width || !img.height) return;
        const c = img.width === img.height ? bakeSquare(img) : img.width === img.height * 2 ? convertClassic(img) : null;
        if (c) canvasCache.set(url, c);
      } catch { /* unreadable / CORS-blocked: leave missing */ }
      finally { busy.delete(url); }
    })();
    busy.set(url, p);
  }
  return p;
}

/** Synchronous access to an already-baked skin canvas (prepares in the background if missing). */
export function getSkinCanvas(url: string): HTMLCanvasElement | null {
  if (!url) return null;
  const hit = canvasCache.get(url);
  if (hit) return hit;
  void prepareSkinCanvas(url);
  return null;
}

/** Decode + normalize an uploaded skin file. The returned canvas is cached under its data URL so
 *  figure previews and the in-game arm can pick it up synchronously afterwards. */
export async function loadSkinFile(file: File): Promise<SkinLoadResult> {
  let url: string;
  try {
    url = await readFileAsDataURL(file);
  } catch {
    return { ok: false, error: 'Could not read that file.' };
  }
  const mime = (url.match(/^data:([^;]+)/) || [])[1] || '';
  if (!/^image\/(png|jpeg)$/.test(mime)) return { ok: false, error: 'Please choose a PNG or JPEG image.' };
  try {
    const img = await loadImageEl(url);
    if (!img.width || !img.height) return { ok: false, error: 'Could not decode that image.' };
    if (img.width !== img.height && img.width !== img.height * 2) {
      return { ok: false, error: 'Skin images should be square (e.g. 64x64) or classic 2:1 (64x32).' };
    }
    const canvas = img.width === img.height ? bakeSquare(img) : convertClassic(img);
    canvasCache.set(url, canvas);
    return { ok: true, skin: { url, name: file.name, slim: guessSlim(canvas), canvas } };
  } catch {
    return { ok: false, error: 'Could not decode that image.' };
  }
}

/** The default Minecraft skin (Steve) embedded as a data URL so the first-person arm always has
 *  the genuine vanilla texture without any network fetch. */
const STEVE_SKIN_URL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAFDUlEQVR42u2a20sUURzH97G0LKMotPuWbVpslj1olJXdjCgyisowsSjzgrB0gSKyC5UF1ZNQWEEQSBQ9dHsIe+zJ/+nXfM/sb/rN4ZwZ96LOrnPgyxzP/M7Z+X7OZc96JpEISfWrFhK0YcU8knlozeJKunE4HahEqSc2nF6zSEkCgGCyb+82enyqybtCZQWAzdfVVFgBJJNJn1BWFgC49/VpwGVlD0CaxQiA5HSYEwBM5sMAdKTqygcAG9+8coHKY/XXAZhUNgDYuBSPjJL/GkzVVhAEU5tqK5XZ7cnFtHWtq/TahdSw2l0HUisr1UKIWJQBAMehDuqiDdzndsP2EZECAG1ZXaWMwOCODdXqysLf++uXUGv9MhUHIByDOijjdiSAoH3ErANQD73C7TXXuGOsFj1d4YH4OTJAEy8y9Hd0mCaeZ5z8dfp88zw1bVyiYhCLOg1ZeAqC0ybaDttHRGME1DhDeVWV26u17lRAPr2+mj7dvULfHw2q65fhQRrLXKDfIxkau3ZMCTGIRR3URR5toU38HbaPiMwUcKfBAkoun09PzrbQ2KWD1JJaqswjdeweoR93rirzyCMBCmIQizqoizZkm2H7iOgAcHrMHbbV9KijkUYv7qOn55sdc4fo250e+vUg4329/Xk6QB/6DtOws+dHDGJRB3XRBve+XARt+4hIrAF4UAzbnrY0ve07QW8uHfB+0LzqanMM7qVb+3f69LJrD90/1axiEIs6qIs21BTIToewfcSsA+Bfb2x67OoR1aPPzu2i60fSNHRwCw221Suz0O3jO+jh6V1KyCMGse9721XdN5ePutdsewxS30cwuMjtC860T5JUKpXyKbSByUn7psi5l+juDlZYGh9324GcPKbkycaN3jUSAGxb46IAYPNZzW0AzgiQ5tVnzLUpUDCAbakMQXXrOtX1UMtHn+Q9/X5L4wgl7t37r85OSrx+TYl379SCia9KXjxRpiTjIZTBFOvrV1f8ty2eY/T7XJ81FQAwmA8ASH1ob68r5PnBsxA88/xAMh6SpqW4HRnLBrkOA9Xv5wPAZjAUgOkB+SHxgBgR0qSMh0zmZRsmwDJm1gFg2PMDIC8/nAHIMls8x8GgzOsG5WiaqREgYzDvpTwjLDy8NM15LpexDEA3LepjU8Z64my+8PtDCmUyRr+fFwA2J0eAFYA0AxgSgMmYBMZTwFQnO9RNAEaHOj2DXF5UADmvAToA2ftyxZYA5BqgmZZApDkdAK4mAKo8GzPlr8G8AehzMAyA/i1girUA0HtYB2CaIkUBEHQ/cBHSvwF0AKZFS5M0ZwMQtEaEAmhtbSUoDADH9ff3++QZ4o0I957e+zYAMt6wHkhzpjkuAcgpwNcpA7AZDLsvpwiuOkBvxygA6Bsvb0HlaeKIF2EbADZpGiGzBsA0gnwQHGOhW2snRpbpPexbAB2Z1oicAMQpTnGKU5ziFKc4xSlOcYpTnOIUpzgVmgo+XC324WfJAdDO/+ceADkCpuMFiFKbApEHkOv7BfzfXt+5gpT8V7rpfYJcDz+jAsB233r6yyBsJ0mlBCDofuBJkel4vOwBFPv8fyYAFPJ+wbSf/88UANNRVy4Awo6+Ig2gkCmgA5DHWjoA+X7AlM//owLANkX0w0359od++pvX8fdMAcj3/QJ9iJsAFPQCxHSnQt8vMJ3v2wCYpkhkAOR7vG7q4aCXoMoSgG8hFAuc/grMdAD4B/kHl9da7Ne9AAAAAElFTkSuQmCC';

const steveReady = new Set<string>();
/** Ensure Steve's texture is baked and cached (idempotent). */
export function ensureSteveSkin(): Promise<HTMLCanvasElement | null> {
  const url = STEVE_SKIN_URL;
  if (steveReady.has(url)) return Promise.resolve(getSteveSkinCanvas());
  return prepareSkinCanvas(url).then(() => { steveReady.add(url); return getSteveSkinCanvas(); });
}
/** Synchronous access to the baked Steve skin canvas (null until it has been prepared once). */
export function getSteveSkinCanvas(): HTMLCanvasElement | null { return getSkinCanvas(STEVE_SKIN_URL); }

/**
 * The first-person right arm built straight from a skin canvas like Java's held-arm model: the
 * vanilla right-arm net (base at 40,16 + sleeve overlay at 40,32) on a single box per limb, so the
 * on-screen arm shows the skin's real sleeve/hand art. `px` scales one skin pixel into world units;
 * the arm occupies 0..12*px along +y (shoulder at the origin, hand at the tip). Materials are
 * supplied by the caller (the first-person view tints everything with its own lighting).
 */
export function buildSkinArmMeshes(canvas: HTMLCanvasElement, slim: boolean, px: number, makeMat: (overlay: boolean) => THREE.Material): { arm: THREE.Mesh; sleeve: THREE.Mesh } {
  const aw = slim ? 3 : 4;
  const box = (u: number, v: number, gw: number, fw: number, mat: THREE.Material) => {
    const geo = new THREE.BoxGeometry(gw * px, 12 * px, 4 * px);
    setBoxUVs(geo, u, v, fw, 12, 4);
    geo.translate(0, 6 * px, 0); // shoulder at the group origin, arm running +y to the fingertips
    // In the net, the sleeve/upper-arm art (top rows of the side strip, e.g. 20-23 for the right arm)
    // sits against the box's +y (top) end; the first-person arm's shoulder is its -y (origin) end, so
    // flip the side faces vertically to put the sleeve at the shoulder and the hand art at the fist
    // (the 3D figure keeps the unflipped boxes because its arms hang with the shoulder at +y).
    const uvAttr = geo.attributes.uv as THREE.BufferAttribute;
    const uvs = uvAttr.array as Float32Array;
    for (const f of [0, 1, 4, 5]) { // +x, -x, +z, -z side faces of a BoxGeometry
      const o = f * 8;
      const t0 = uvs[o + 1], t1 = uvs[o + 3];
      uvs[o + 1] = uvs[o + 5]; uvs[o + 3] = uvs[o + 7];
      uvs[o + 5] = t0; uvs[o + 7] = t1;
    }
    uvAttr.needsUpdate = true;
    return new THREE.Mesh(geo, mat);
  };
  return { arm: box(40, 16, aw, aw, makeMat(false)), sleeve: box(40, 32, slim ? 3.5 : 4.5, aw, makeMat(true)) };
}

// ------------------------------------------------------------------ per-face UV mapping

function faceUV(u: number, v: number, w: number, h: number, d: number, x1: number, y1: number, x2: number, y2: number) {
  return [
    new THREE.Vector2(x1 / SKIN_W, 1 - y2 / SKIN_W),
    new THREE.Vector2(x2 / SKIN_W, 1 - y2 / SKIN_W),
    new THREE.Vector2(x2 / SKIN_W, 1 - y1 / SKIN_W),
    new THREE.Vector2(x1 / SKIN_W, 1 - y1 / SKIN_W),
  ];
}

/** Assign the atlas rect for a cube net (u,v = top-left, size w x h x d) onto a BoxGeometry's UVs.
 *  Net layout (vanilla): [left][front][right][back] across, [top][bottom] above. */
export function setBoxUVs(box: THREE.BoxGeometry, u: number, v: number, w: number, h: number, d: number): void {
  const top = faceUV(u, v, w, h, d, u + d, v, u + w + d, v + d);
  const bottom = faceUV(u, v, w, h, d, u + w + d, v, u + w * 2 + d, v + d);
  const left = faceUV(u, v, w, h, d, u, v + d, u + d, v + d + h);
  const front = faceUV(u, v, w, h, d, u + d, v + d, u + w + d, v + d + h);
  const right = faceUV(u, v, w, h, d, u + w + d, v + d, u + w + d * 2, v + d + h);
  const back = faceUV(u, v, w, h, d, u + w + d * 2, v + d, u + w * 2 + d * 2, v + d + h);
  const uv = box.attributes.uv as THREE.BufferAttribute;
  const out: number[] = [];
  // three.js BoxGeometry face order: +x, -x, +y, -y, +z, -z (4 verts each)
  for (const face of [right, left, top, bottom, front, back]) {
    const arr = face === top ? [3, 2, 0, 1] : face === bottom ? [0, 1, 3, 2] : [3, 2, 0, 1];
    for (const i of arr) out.push(face[i].x, face[i].y);
  }
  uv.set(new Float32Array(out));
  uv.needsUpdate = true;
}

/** A cube: geometry of gw x gh x gd, textured from the atlas net at (u,v) with face size fw x fh x fd. */
export function skinBox(gw: number, gh: number, gd: number, u: number, v: number, fw: number, fh: number, fd: number, mat: THREE.Material): THREE.Mesh {
  const geo = new THREE.BoxGeometry(gw, gh, gd);
  setBoxUVs(geo, u, v, fw, fh, fd);
  return new THREE.Mesh(geo, mat);
}

// ------------------------------------------------------------------ figure

export interface SkinFigureParts {
  root: THREE.Group;
  head: THREE.Group;
  body: THREE.Mesh;
  arms: THREE.Mesh[];
  legs: THREE.Mesh[];
  materials: (THREE.Material | THREE.Texture)[];
}

/**
 * Build the vanilla player figure (head/hat + body/jacket + arms/sleeves + legs) from a skin texture.
 * Geometry is in skin pixels (1 px = 1/16 block, i.e. the figure is 32 px tall with the hat);
 * group origin sits at the feet; limb meshes are pivoted at their top (shoulder / hip).
 */
export function buildSkinFigure(canvas: HTMLCanvasElement, slim: boolean): SkinFigureParts {
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  const inner = new THREE.MeshLambertMaterial({ map: tex });
  const outer = new THREE.MeshLambertMaterial({ map: tex, transparent: true, alphaTest: 0.05, side: THREE.DoubleSide, depthWrite: false });
  const materials = [tex, inner, outer];
  const aw = slim ? 3 : 4;

  const root = new THREE.Group();
  // head + hat (top of the 64x64: base at (0,0), overlay at (32,0))
  const head = new THREE.Group();
  head.position.set(0, 24 / 16, 0);
  const headBox = skinBox(8, 8, 8, 0, 0, 8, 8, 8, inner); headBox.position.y = 4 / 16; head.add(headBox);
  const hat = skinBox(9, 9, 9, 32, 0, 8, 8, 8, outer); hat.position.y = 4 / 16; head.add(hat);
  root.add(head);
  // body (16,16) + jacket (16,32)
  const body = skinBox(8, 12, 4, 16, 16, 8, 12, 4, inner); body.position.set(0, 18 / 16, 0); root.add(body);
  const jacket = skinBox(8.5, 12.5, 4.5, 16, 32, 8, 12, 4, outer); jacket.position.set(0, 18.25 / 16, 0); root.add(jacket);
  // right arm at atlas (40,16), overlay (40,32); pivot at the shoulder (top of the arm box)
  const armGeo = (u: number, v: number, gw: number, fw: number, mat: THREE.Material) => {
    const g = new THREE.BoxGeometry(gw, 12, 4);
    setBoxUVs(g, u, v, fw, 12, 4);
    g.translate(0, -6, 0); // box now spans -12..0 in y: 0 = shoulder
    const m = new THREE.Mesh(g, mat);
    m.position.set(0, 24 / 16, 0);
    return m;
  };
  const rightArm = armGeo(40, 16, aw, aw, inner); rightArm.position.x = -(4 + aw / 2) / 16;
  const rightSleeve = armGeo(40, 32, slim ? 3.5 : 4.5, aw, outer); rightSleeve.position.x = -(4 + aw / 2) / 16;
  const leftArm = armGeo(32, 48, aw, aw, inner); leftArm.position.x = (4 + aw / 2) / 16;
  const leftSleeve = armGeo(48, 48, slim ? 3.5 : 4.5, aw, outer); leftSleeve.position.x = (4 + aw / 2) / 16;
  root.add(rightArm, rightSleeve, leftArm, leftSleeve);
  // legs: right base (0,16) + overlay (0,32); left base (16,48) + overlay (0,48); pivot at the hip
  const legGeo = (u: number, v: number, gw: number, mat: THREE.Material) => {
    const g = new THREE.BoxGeometry(gw, 12, 4);
    setBoxUVs(g, u, v, 4, 12, 4);
    g.translate(0, -6, 0); // spans -12..0 in y: 0 = hip
    const m = new THREE.Mesh(g, mat);
    m.position.set(0, 12 / 16, 0);
    return m;
  };
  const rightLeg = legGeo(0, 16, 4, inner); rightLeg.position.x = -2 / 16;
  const rightLegOv = legGeo(0, 32, 4.5, outer); rightLegOv.position.x = -2 / 16;
  const leftLeg = legGeo(16, 48, 4, inner); leftLeg.position.x = 2 / 16;
  const leftLegOv = legGeo(0, 48, 4.5, outer); leftLegOv.position.x = 2 / 16;
  root.add(rightLeg, rightLegOv, leftLeg, leftLegOv);
  return { root, head, body, arms: [rightArm, leftArm], legs: [rightLeg, leftLeg], materials };
}
