/**
 * Resource packs: standard Minecraft resource-pack zips (assets/minecraft/textures/...) overlay
 * their block & item textures onto FABLE's procedurally painted ones. The pack zip is parsed with
 * fflate, mapped onto FABLE's tile/item names (with fallback candidates and tinted grayscale
 * sources), blitted into the live texture atlas and the item-icon caches, and persisted in
 * IndexedDB so it survives reloads. Vanilla-format packs made for Minecraft (e.g. Faithful) work.
 */
import { unzipSync } from 'fflate';
import { getAtlas } from '../blocks/TextureAtlas';
import { TILE_NAMES } from '../blocks/Tiles';
import { BIOMES, leafTint } from '../world/Biomes';
import { setPackIconLookup, invalidateIcons } from '../items/Icons';
import { settings } from './Settings';
import { store } from '../../ui/store';

// ---------------------------------------------------------------- mapping tables
/** FABLE tile name -> candidate paths under assets/minecraft/textures/block/ (first found wins). */
export const TILE_MAP: Record<string, string[]> = {
  stone: ['stone'], deep_stone: ['deepslate'], dirt: ['dirt'],
  grass_top: ['grass_block_top'], grass_side: ['grass_block_side'], snow_grass_side: ['grass_block_snow'],
  snow: ['snow'], sand: ['sand'], red_sand: ['red_sand'], gravel: ['gravel'], clay: ['clay'], mud: ['mud'],
  ice: ['ice'], packed_ice: ['packed_ice'], water: ['water_still'], lava: ['lava_still'], bedrock: ['bedrock'],
  sandstone_top: ['sandstone_top'], sandstone_side: ['sandstone_side'], terracotta: ['terracotta'],
  oak_log: ['oak_log'], oak_log_top: ['oak_log_top'], oak_planks: ['oak_planks'], oak_leaves: ['oak_leaves'],
  birch_log: ['birch_log'], birch_log_top: ['birch_log_top'], birch_planks: ['birch_planks'], birch_leaves: ['birch_leaves'],
  spruce_log: ['spruce_log'], spruce_log_top: ['spruce_log_top'], spruce_planks: ['spruce_planks'], spruce_leaves: ['spruce_leaves'],
  dark_log: ['dark_oak_log'], dark_log_top: ['dark_oak_log_top'], dark_planks: ['dark_oak_planks'], dark_leaves: ['dark_oak_leaves'],
  stripped_log: ['stripped_oak_log'], stripped_log_top: ['stripped_oak_log_top'],
  oak_sapling: ['oak_sapling'], birch_sapling: ['birch_sapling'], spruce_sapling: ['spruce_sapling'],
  coal_ore: ['coal_ore'], copper_ore: ['copper_ore'], iron_ore: ['iron_ore'], gold_ore: ['gold_ore'],
  ember_ore: ['nether_gold_ore', 'redstone_ore'], crystal_ore: ['diamond_ore'],
  cobblestone: ['cobblestone'], mossy_cobblestone: ['mossy_cobblestone'], stone_bricks: ['stone_bricks'], bricks: ['bricks'],
  glass: ['glass'], wool: ['white_wool'], voidstone: ['obsidian'], lumen: ['glowstone'], hellstone: ['netherrack'],
  crafting_table_top: ['crafting_table_top'], crafting_table_side: ['crafting_table_side'],
  furnace_side: ['furnace_side'], furnace_front: ['furnace_front'], furnace_front_lit: ['furnace_front_on'],
  torch: ['torch'], lantern: ['lantern'], ladder: ['ladder'], door_top: ['oak_door_top'], door_bottom: ['oak_door_bottom'],
  tall_grass: ['short_grass', 'grass'], fern: ['fern', 'large_fern_bottom'],
  flower_red: ['poppy'], flower_yellow: ['dandelion'], flower_blue: ['cornflower'],
  mushroom_brown: ['brown_mushroom'], mushroom_red: ['red_mushroom'], dead_bush: ['dead_bush'],
  cactus_side: ['cactus_side'], cactus_top: ['cactus_top'], reeds: ['sugar_cane'], farmland: ['farmland'],
  wheat_0: ['wheat_stage1'], wheat_1: ['wheat_stage3'], wheat_2: ['wheat_stage5'], wheat_3: ['wheat_stage7'],
  carrot_0: ['carrots_stage0'], carrot_1: ['carrots_stage2'], carrot_2: ['carrots_stage3'],
  potato_0: ['potatoes_stage0'], potato_1: ['potatoes_stage2'], potato_2: ['potatoes_stage3'],
  pumpkin_side: ['pumpkin_side'], pumpkin_top: ['pumpkin_top'], melon_side: ['melon_side'], melon_top: ['melon_top'],
};

/** Grayscale (tint-in-Minecraft) sources get multiplied by FABLE's plains biome colours at draw time. */
export const TILE_TINTS: Record<string, [number, number, number]> = {
  grass_top: [0x91 / 255, 0xbd / 255, 0x59 / 255],
  oak_leaves: [0x59 / 255, 0xae / 255, 0x30 / 255], spruce_leaves: [0x68 / 255, 0xa4 / 255, 0x64 / 255],
  dark_leaves: [0x3f / 255, 0x6e / 255, 0x24 / 255],
};

/** FABLE item id -> candidate paths under assets/minecraft/textures/item/. */
export const ITEM_MAP: Record<string, string[]> = {
  wood_pickaxe: ['wooden_pickaxe'], wood_axe: ['wooden_axe'], wood_shovel: ['wooden_shovel'], wood_hoe: ['wooden_hoe'], wood_sword: ['wooden_sword'],
  stone_pickaxe: ['stone_pickaxe'], stone_axe: ['stone_axe'], stone_shovel: ['stone_shovel'], stone_hoe: ['stone_hoe'], stone_sword: ['stone_sword'],
  copper_pickaxe: ['copper_pickaxe', 'iron_pickaxe'], copper_axe: ['copper_axe', 'iron_axe'], copper_shovel: ['copper_shovel', 'iron_shovel'], copper_hoe: ['copper_hoe', 'iron_hoe'], copper_sword: ['copper_sword', 'iron_sword'],
  iron_pickaxe: ['iron_pickaxe'], iron_axe: ['iron_axe'], iron_shovel: ['iron_shovel'], iron_hoe: ['iron_hoe'], iron_sword: ['iron_sword'],
  gold_pickaxe: ['golden_pickaxe'], gold_axe: ['golden_axe'], gold_shovel: ['golden_shovel'], gold_hoe: ['golden_hoe'], gold_sword: ['golden_sword'],
  crystal_pickaxe: ['diamond_pickaxe', 'netherite_pickaxe'], crystal_axe: ['diamond_axe', 'netherite_axe'], crystal_shovel: ['diamond_shovel', 'netherite_shovel'], crystal_hoe: ['diamond_hoe', 'netherite_hoe'], crystal_sword: ['diamond_sword', 'netherite_sword'],
  leather_helmet: ['leather_helmet'], leather_chestplate: ['leather_chestplate'], leather_leggings: ['leather_leggings'], leather_boots: ['leather_boots'],
  iron_helmet: ['iron_helmet'], iron_chestplate: ['iron_chestplate'], iron_leggings: ['iron_leggings'], iron_boots: ['iron_boots'],
  gold_helmet: ['golden_helmet'], gold_chestplate: ['golden_chestplate'], gold_leggings: ['golden_leggings'], gold_boots: ['golden_boots'],
  crystal_helmet: ['diamond_helmet'], crystal_chestplate: ['diamond_chestplate'], crystal_leggings: ['diamond_leggings'], crystal_boots: ['diamond_boots'],
  stick: ['stick'], coal: ['coal'], charcoal: ['charcoal'], iron_ingot: ['iron_ingot'], gold_ingot: ['gold_ingot'], copper_ingot: ['copper_ingot', 'iron_ingot'],
  raw_copper: ['raw_copper'], raw_gold: ['raw_gold'], raw_iron: ['raw_iron'],
  sky_crystal: ['diamond', 'emerald'], ember_dust: ['blaze_powder', 'redstone'], void_essence: ['ender_pearl', 'ender_eye'],
  shadow_wing: ['phantom_membrane', 'feather'], lumen_shard: ['glowstone_dust', 'glowstone'], spider_silk: ['string', 'spider_eye'],
  leather: ['leather'], feather: ['feather'], string: ['string'], bone: ['bone'], arrow: ['arrow'], bow: ['bow'],
  apple: ['apple'], honey_apple: ['golden_apple', 'apple'], bread: ['bread'], melon_slice: ['melon_slice'],
  wheat: ['wheat'], wheat_seeds: ['wheat_seeds'], carrot: ['carrot'], potato: ['potato'], baked_potato: ['baked_potato'],
  raw_beef: ['beef'], cooked_beef: ['cooked_beef'], raw_porkchop: ['porkchop'], cooked_porkchop: ['cooked_porkchop'],
  raw_mutton: ['mutton'], cooked_mutton: ['cooked_mutton'], raw_chicken: ['chicken'], cooked_chicken: ['cooked_chicken'],
  egg: ['egg'], berry: ['sweet_berries', 'apple'], mushroom_stew: ['mushroom_stew'],
  clay_ball: ['clay_ball'], brick: ['brick'], snowball: ['snowball'], flint: ['flint'],
  fire_striker: ['flint_and_steel'], oak_door: ['oak_door'], shield: ['shield'],
};

// ---------------------------------------------------------------- live pack state
const packTiles = new Map<number, HTMLCanvasElement>();
const packItems = new Map<string, HTMLCanvasElement>();

/** Icon override hook consumed by items/Icons.ts (avoids a circular import). */
setPackIconLookup((id) => packItems.get(id));

const DB = 'fable-packs', STORE = 'files';
function idb(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch { resolve(null); }
  });
}
async function idbPut(bytes: ArrayBuffer): Promise<void> {
  const db = await idb();
  if (!db) return;
  await new Promise<void>((resolve) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(bytes, 'resource-pack');
    tx.oncomplete = () => resolve();
    tx.onerror = () => resolve();
  });
}
async function idbGet(): Promise<ArrayBuffer | null> {
  const db = await idb();
  if (!db) return null;
  return new Promise((resolve) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).get('resource-pack');
    req.onsuccess = () => resolve((req.result as ArrayBuffer) ?? null);
    req.onerror = () => resolve(null);
  });
}
async function idbClear(): Promise<void> {
  const db = await idb();
  if (!db) return;
  await new Promise<void>((resolve) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete('resource-pack');
    tx.oncomplete = () => resolve();
    tx.onerror = () => resolve();
  });
}

// ---------------------------------------------------------------- image helpers
async function png16(bytes: Uint8Array, tint?: [number, number, number]): Promise<HTMLCanvasElement | null> {
  try {
    const blob = new Blob([bytes.slice() as unknown as BlobPart], { type: 'image/png' });
    const bmp = await createImageBitmap(blob);
    // Minecraft animated textures are vertical strips: use frame 0. Larger (HD) textures are
    // nearest-neighbour downsampled to FABLE's 16x16 tile size.
    const sx = bmp.height > 16 ? 16 : 0;
    const cv = document.createElement('canvas');
    cv.width = 16; cv.height = 16;
    const ctx = cv.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(bmp, 0, sx, 16, Math.min(16, bmp.height), 0, 0, 16, 16);
    if (tint) {
      const img = ctx.getImageData(0, 0, 16, 16);
      for (let i = 0; i < img.data.length; i += 4) {
        img.data[i] = Math.round(img.data[i] * tint[0]);
        img.data[i + 1] = Math.round(img.data[i + 1] * tint[1]);
        img.data[i + 2] = Math.round(img.data[i + 2] * tint[2]);
      }
      ctx.putImageData(img, 0, 0);
    }
    return cv;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------- apply
function applyToAtlas(): number {
  if (!packTiles.size) return 0;
  return getAtlas().applyTileOverrides(packTiles);
}

function applyToItems(): void {
  invalidateIcons();
  store.bump();
}

// ---------------------------------------------------------------- public API
export interface PackResult { name: string; tiles: number; items: number }

/** Parse a resource-pack zip (.zip / .mcpack), map its textures onto FABLE's and apply them live. */
export async function loadResourcePack(file: File): Promise<PackResult> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const entries = unzipSync(bytes);
  const find = (candidates: string[]): Uint8Array | null => {
    for (const c of candidates) {
      const k = `assets/minecraft/textures/block/${c}.png`;
      if (entries[k]) return entries[k];
    }
    return null;
  };
  const findItem = (candidates: string[]): Uint8Array | null => {
    for (const c of candidates) {
      const k = `assets/minecraft/textures/item/${c}.png`;
      if (entries[k]) return entries[k];
    }
    return null;
  };
  packTiles.clear();
  packItems.clear();
  for (const tile of TILE_NAMES) {
    const candidates = TILE_MAP[tile];
    if (!candidates) continue;
    const data = find(candidates);
    if (!data) continue;
    const cv = await png16(data, TILE_TINTS[tile]);
    if (cv) {
      const idx = TILE_NAMES.indexOf(tile);
      packTiles.set(idx, cv);
    }
  }
  for (const [id, candidates] of Object.entries(ITEM_MAP)) {
    const data = findItem(candidates);
    if (!data) continue;
    const cv = await png16(data);
    if (cv) packItems.set(id, cv);
  }
  if (!packTiles.size && !packItems.size) throw new Error('No compatible textures found — is this a Minecraft resource pack?');
  applyToAtlas();
  applyToItems();
  await idbPut(bytes);
  settings.set('resourcePack', file.name);
  return { name: file.name, tiles: packTiles.size, items: packItems.size };
}

/** Remove the pack and restore FABLE's built-in art. */
export async function clearResourcePack(): Promise<void> {
  packTiles.clear();
  packItems.clear();
  getAtlas().resetTiles();
  applyToItems();
  await idbClear();
  settings.set('resourcePack', '');
}

/** Boot-time restore: re-parse the persisted pack zip and re-apply it. */
export async function restoreResourcePack(): Promise<void> {
  if (!settings.value.resourcePack) return;
  const bytes = await idbGet();
  if (!bytes) { settings.set('resourcePack', ''); return; }
  try {
    const name = settings.value.resourcePack;
    await loadResourcePack(new File([bytes], name, { type: 'application/zip' }));
  } catch {
    settings.set('resourcePack', '');
  }
}

/** Test-only / introspection: counts of currently mapped textures. */
export function packCounts(): { tiles: number; items: number } {
  return { tiles: packTiles.size, items: packItems.size };
}

// keep BIOMES/leafTint referenced for potential per-biome tinting refinements (tree-sourced tints)
void BIOMES; void leafTint;
