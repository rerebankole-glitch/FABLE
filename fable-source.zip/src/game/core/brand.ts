/** Game identity. Everything user-facing (title, window title, server name, saves) reads from here. */
export const GAME_TITLE = 'FABLE';
export const GAME_VERSION = '6.0';
export const GAME_TAGLINE = 'A voxel adventure for the browser';
