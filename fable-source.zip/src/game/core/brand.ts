/** Game identity. Everything user-facing (title, window title, server name, saves) reads from here. */
export const GAME_TITLE = 'FABLE';
export const GAME_VERSION = '5.4';
export const GAME_TAGLINE = 'A voxel adventure for the browser';
