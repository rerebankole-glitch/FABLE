/**
 * First-person viewmodel rig: where a held item sits on screen, and how the player's arm grips it.
 *
 * Java's `ItemRenderer` chain poses the held item with a 45 degree yaw (its `rotate(45, 0, 1, 0)`),
 * which is fine for the small, centred vanilla sprite but turns a big "hold in hands" sprite into a
 * narrow sliver: the plate's own width is rotated into depth, so perspective squashes it to roughly
 * a third of its real width. So flat items and held blocks are posed DIRECTLY IN CAMERA SPACE here
 * (the yaw is skipped in `Game.buildItemChain`) and the composition is described in screen terms —
 * fractions of the frame and screen heights — which are then solved back into the chain units the
 * game consumes.
 *
 * The solve is resolution-, aspect- and FOV-independent: `Game.updateHand` multiplies both the
 * viewmodel's position and its size by the same `fovK`, which is exactly a re-projection from the
 * world FOV onto the fixed 70 degree hand pass Java renders the hand with, so the numbers below can
 * be read straight off a reference screenshot and mean the same thing on every display.
 */

/** Half-height of the fixed 70 degree hand projection at one unit of depth (tan 35 degrees). */
export const HAND_TAN = Math.tan((35 * Math.PI) / 180);
/** Aspect of the frame the composition below was measured against. */
export const HAND_ASPECT = 16 / 9;
/** Java's first-person item translation (`ItemRenderer.transformFirstPersonItem`). */
export const ITEM_BASE = { x: 0.56, y: -0.52, z: -0.71999997 };
/** ...and the uniform model scale that same method applies. */
export const ITEM_SCALE = 0.4;

// ---------------------------------------------------------------------------
// The composition. Every number here is a screen measurement, so it can be nudged by eye.
// ---------------------------------------------------------------------------

/** How tall the item sprite is, in screen heights (the reference's big diagonal tool). */
export const HELD_SPRITE_H = 0.82;
/** In-plane tilt of the sprite, degrees CCW: the handle runs down-right into the fist. */
export const HELD_TILT_DEG = 12;
/** The fist anchor inside the icon: `u` from the left, `v` from the bottom, both 0..1. */
export const HELD_GRIP = { u: 0.7, v: 0.19 };
/** Where that anchor lands on screen (fractions, `y` measured from the top). */
export const HELD_SCREEN = { x: 0.76, y: 0.82 };
/** Camera-space distance of the sprite plane. */
export const HELD_DEPTH = 1.0;
/** Thickness of the voxel extrusion, in icon pixels. */
export const HELD_THICK = 3.4;
/** Forearm width in screen heights (the arm model is 4 pixels across). */
export const HELD_ARM_W = 0.24;
/** Angle of the forearm below horizontal as it leaves the fist towards the bottom-right corner. */
export const HELD_ARM_DEG = 37;
/** How far in front of the sprite plane the arm sits, in plate units, so the fist wraps the handle. */
export const HELD_ARM_Z = 0.09;
/** Swing rotations are re-pivoted onto the fist for flat items; this scales their vanilla amounts. */
export const HELD_SWING = 0.45;

/** Held blocks: a three-quarter view parked in the same corner as the tools. */
export const HELD_BLOCK_H = 0.34;                       // cube size, screen heights
export const HELD_BLOCK_SCREEN = { x: 0.72, y: 0.64 };  // centre of the cube
export const HELD_BLOCK_DEPTH = 1.15;
export const HELD_BLOCK_YAW_DEG = 45;                   // three-quarter view
export const HELD_BLOCK_PITCH_DEG = -22;                // tipped so the top face shows
/** Forearm width next to a held block, as a fraction of the cube. */
export const HELD_BLOCK_ARM_W = 0.33;
/** Where the fist closes on a held cube, in cube-local units (the cube spans -0.5..0.5). */
export const HELD_BLOCK_GRIP = { x: 0.55, y: -0.55, z: 0.55 };

export const HELD_TILT = (HELD_TILT_DEG * Math.PI) / 180;
export const HELD_BLOCK_YAW = (HELD_BLOCK_YAW_DEG * Math.PI) / 180;
export const HELD_BLOCK_PITCH = (HELD_BLOCK_PITCH_DEG * Math.PI) / 180;

export interface Placement {
  /** Chain-space translation of the model (right of the chain's 0.4 scale, so pre-scale units). */
  x: number;
  y: number;
  z: number;
  /** Chain-space uniform scale for a model that is one unit across. */
  size: number;
}

/**
 * Chain-space translation + scale that parks a one-unit model of `sizeH` screen heights with its
 * centre at `screen` (fractions of the frame, `y` from the top) at `depth` units from the eye.
 */
export function placeOnScreen(screen: { x: number; y: number }, sizeH: number, depth: number): Placement {
  const span = 2 * depth * HAND_TAN; // world units per screen height at this depth
  return {
    x: ((screen.x * HAND_ASPECT - HAND_ASPECT / 2) * span - ITEM_BASE.x) / ITEM_SCALE,
    y: ((0.5 - screen.y) * span - ITEM_BASE.y) / ITEM_SCALE,
    z: (-depth - ITEM_BASE.z) / ITEM_SCALE,
    size: (sizeH * span) / ITEM_SCALE,
  };
}

/** Where the grip anchor sits inside the sprite, in plate-local units (the plate spans -0.5..0.5). */
export const HELD_GRIP_LOCAL = { x: HELD_GRIP.u - 0.5, y: HELD_GRIP.v - 0.5 };

/** Screen-space offset (in screen heights, y downwards) of the grip anchor from the plate centre. */
const GRIP_OFFSET = (() => {
  const c = Math.cos(HELD_TILT), s = Math.sin(HELD_TILT);
  const { x, y } = HELD_GRIP_LOCAL;
  return { x: HELD_SPRITE_H * (x * c - y * s), y: -HELD_SPRITE_H * (x * s + y * c) };
})();

/** Sprite plate placement: solved so the grip anchor lands exactly on `HELD_SCREEN`. */
export const HELD_PLATE: Placement = placeOnScreen(
  {
    x: (HELD_SCREEN.x * HAND_ASPECT - GRIP_OFFSET.x) / HAND_ASPECT,
    y: HELD_SCREEN.y - GRIP_OFFSET.y,
  },
  HELD_SPRITE_H,
  HELD_DEPTH,
);

/** Held block placement. */
export const HELD_BLOCK: Placement = placeOnScreen(HELD_BLOCK_SCREEN, HELD_BLOCK_H, HELD_BLOCK_DEPTH);

/** Plate units per arm-model pixel: the arm is 4 pixels wide and `HELD_ARM_W` screen heights across. */
export const HELD_ARM_S = HELD_ARM_W / (4 * HELD_SPRITE_H);
/** Cube-local units per arm-model pixel when a block is held (the cube is one unit across). */
export const HELD_BLOCK_ARM_S = HELD_BLOCK_ARM_W / 4;
/**
 * Roll of the arm model. The arm runs along its local +y (shoulder to fist), so a roll of `phi`
 * points it `90 - phi` degrees off horizontal before the sprite's own tilt is added; the arm leaves
 * the fist at `HELD_ARM_DEG` below horizontal once that tilt is in.
 */
export const HELD_ARM_PHI = ((90 - HELD_ARM_DEG - HELD_TILT_DEG) * Math.PI) / 180;
/** Same, for held blocks (no sprite tilt to cancel). */
export const HELD_ARM_PHI_BLOCK = ((90 - HELD_ARM_DEG) * Math.PI) / 180;
