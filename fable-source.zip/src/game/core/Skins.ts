// Built-in player skins. A preset is a palette the voxel figure (and the first-person arm) is
// painted with, exactly like the "no upload" palette path - so presets work with the in-world
// figure, the inventory preview, the menu figure and the first-person arm with no extra art.
// Adding a skin = one more entry here (the picker, previews and persistence are generic).

export interface SkinPreset {
  id: string;
  name: string;
  skin: string; // body/face colour
  hair: string;
  shirt: string;
  pants: string;
  /** optional accent hint shown on the picker card (eyes/trim tone) */
  accent?: string;
  /** slim (3px) arm layout, like the classic "Alex" body */
  slim?: boolean;
}

export const SKIN_PRESETS: SkinPreset[] = [
  { id: 'steve', name: 'Classic', skin: '#c68e5c', hair: '#5a3a22', shirt: '#3f6f9f', pants: '#3b3b5a', accent: '#d8a878' },
  { id: 'alex', name: 'Sunny', skin: '#e0ac69', hair: '#8a5a30', shirt: '#2e8f5e', pants: '#5a4632', accent: '#0a7f5a', slim: true },
  { id: 'digger', name: 'Miner', skin: '#b07040', hair: '#4a3a28', shirt: '#9aa0a8', pants: '#3c4350', accent: '#c9a06a' },
  { id: 'knight', name: 'Knight', skin: '#d8a878', hair: '#6a4a2a', shirt: '#cfd6df', pants: '#2a2f3a', accent: '#e8c060' },
  { id: 'ember', name: 'Ember', skin: '#f0b060', hair: '#5a2a10', shirt: '#d8502f', pants: '#4a2010', accent: '#ffd080' },
  { id: 'arbor', name: 'Arbor', skin: '#8a6a42', hair: '#2f3a1f', shirt: '#3f7f3f', pants: '#4a3a28', accent: '#7fd06f' },
  { id: 'frost', name: 'Frost', skin: '#d8c8b0', hair: '#e8f0f8', shirt: '#4f8fbf', pants: '#274060', accent: '#cfe8ff' },
  { id: 'rose', name: 'Rose', skin: '#f0c8a0', hair: '#55202f', shirt: '#c0557f', pants: '#552040', accent: '#ffb0c8', slim: true },
];

export function presetById(id: string): SkinPreset {
  return SKIN_PRESETS.find((p) => p.id === id) ?? SKIN_PRESETS[0];
}
