import * as THREE from 'three';
import { isHandledArt, itemPixels, ICON_PX } from '../items/Icons';
import { ITEMS } from '../items/Items';
import { HELD_THICK } from './HandFit';

/**
 * Build the in-hand model of an item: a voxel extrusion of its own icon, where every opaque pixel
 * becomes one slab of `HELD_THICK` icon pixels deep, with front/back faces and only the exposed
 * side faces emitted (side faces are shaded darker so the thickness reads).
 *
 * Local frame: the plate spans -0.5..0.5 in x and y with the icon centred, icon up -> +y, and the
 * slab is centred on z = 0, which is what HandFit's plate placement assumes.
 *
 * `mirror` flips the art horizontally, which is how a tool has to read to be gripped: the icon's
 * handle then runs down-right into the fist and the head sits up-left, instead of pointing away
 * from the arm. Mirroring happens in the pixel lookup, not with a negative scale, so the winding
 * (and therefore face culling and the shading) stays correct.
 */
/** Tools and weapons are mirrored by default: their handle then runs down-right into the fist. */
function grippedArt(id: string): boolean {
  const def = ITEMS.get(id);
  return !!def && 'art' in def.icon && isHandledArt(def.icon.art);
}

export function extrudedIcon(id: string, mats: THREE.MeshBasicMaterial[], mirror = grippedArt(id)): THREE.Mesh {
  const img = itemPixels(id);
  const N = ICON_PX;
  const px = 1 / N; // plate size of one icon pixel (the plate is one unit across)
  const depth = px * HELD_THICK; // thick voxel cutout: the side faces read as real depth in hand
  const d = img.data;
  // icon pixel -> plate pixel (mirrored tools keep their handle on the fist's side)
  const mx = (x: number): number => (mirror ? N - 1 - x : x);
  const opaque = (x: number, y: number): boolean => {
    const sx = mx(x);
    return sx >= 0 && y >= 0 && sx < N && y < N && d[(y * N + sx) * 4 + 3] > 40;
  };
  const pos: number[] = [], col: number[] = [], idx: number[] = [];
  let v = 0;
  const quad = (a: number[], b: number[], c: number[], e: number[], r: number, g: number, bl: number) => {
    pos.push(...a, ...b, ...c, ...e);
    for (let i = 0; i < 4; i++) col.push(r, g, bl);
    idx.push(v, v + 1, v + 2, v, v + 2, v + 3);
    v += 4;
  };
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    if (!opaque(x, y)) continue;
    const i = (y * N + mx(x)) * 4;
    const r = d[i] / 255, g = d[i + 1] / 255, b = d[i + 2] / 255;
    const x0 = -0.5 + x * px, x1 = x0 + px, y0 = 0.5 - (y + 1) * px, y1 = y0 + px, z0 = -depth / 2, z1 = depth / 2;
    // front (+z, lit) and back (-z)
    quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], r, g, b);
    quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], r * 0.85, g * 0.85, b * 0.85);
    // exposed sides (darker so the extrusion reads as thickness)
    if (!opaque(x - 1, y)) quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], r * 0.7, g * 0.7, b * 0.7);
    if (!opaque(x + 1, y)) quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], r * 0.7, g * 0.7, b * 0.7);
    if (!opaque(x, y - 1)) quad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], r * 0.92, g * 0.92, b * 0.92); // top edge (icon y-1 is above)
    if (!opaque(x, y + 1)) quad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], r * 0.55, g * 0.55, b * 0.55); // bottom edge
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  geo.setIndex(idx);
  geo.computeBoundingSphere();
  const m = new THREE.MeshBasicMaterial({ vertexColors: true });
  mats.push(m);
  const mesh = new THREE.Mesh(geo, m);
  mesh.frustumCulled = false;
  return mesh;
}
