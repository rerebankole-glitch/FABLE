import { B, BLOCKS, type ToolKind } from '../blocks/Blocks';
import type { ItemStack } from '../core/types';

export type ItemType = 'block' | 'tool' | 'food' | 'material' | 'armor' | 'bow' | 'shield' | 'misc';

export interface ToolStats { kind: ToolKind; tier: number; speed: number; damage: number; durability: number }
export interface ArmorStats { slot: number; defense: number; durability: number }
export interface FoodStats { hunger: number; saturation: number; effect?: 'regen' | 'speed' | 'strength' }

export interface ItemDef {
  id: string;
  name: string;
  type: ItemType;
  block?: number;
  maxStack: number;
  tool?: ToolStats;
  armor?: ArmorStats;
  food?: FoodStats;
  fuel?: number;
  icon: { art: string; colors?: Record<string, string> } | { block: number };
  desc?: string;
}

export const ITEMS = new Map<string, ItemDef>();

function add(def: ItemDef): void {
  ITEMS.set(def.id, def);
}

// Block items
for (const b of BLOCKS) {
  if (!b.hasItem || b.id === B.AIR) continue;
  add({
    id: b.name, name: b.label, type: 'block', block: b.id, maxStack: 64, icon: { block: b.id },
    fuel: b.flammable ? (b.name.includes('log') ? 15 : b.name.includes('planks') ? 15 : b.name.includes('sapling') ? 5 : b.flammable ? 10 : undefined) : undefined,
  });
}
ITEMS.get('coal_ore')!.fuel = undefined;

const mat = (id: string, name: string, art: string, colors: Record<string, string>, extra: Partial<ItemDef> = {}) =>
  add({ id, name, type: 'material', maxStack: 64, icon: { art, colors }, ...extra });

mat('stick', 'Stick', 'stick', { A: '#8a6a3a', B: '#6a4a24' }, { fuel: 5 });
mat('coal', 'Coal', 'lump', { A: '#2a2a2a', B: '#141414', C: '#404040' }, { fuel: 80 });
mat('charcoal', 'Charcoal', 'lump', { A: '#3a3028', B: '#1c1814', C: '#504840' }, { fuel: 80 });
mat('raw_copper', 'Raw Copper', 'lump', { A: '#c87a45', B: '#9a5a30', C: '#e0a070' });
mat('copper_ingot', 'Copper Ingot', 'ingot', { A: '#d88a55', B: '#a0603a', C: '#f0b080' });
mat('raw_iron', 'Raw Iron', 'lump', { A: '#dcb090', B: '#a88070', C: '#f0d0b0' });
mat('iron_ingot', 'Iron Ingot', 'ingot', { A: '#d8d8d8', B: '#909090', C: '#ffffff' });
mat('raw_gold', 'Raw Gold', 'lump', { A: '#f2d243', B: '#b89a20', C: '#fff0a0' });
mat('gold_ingot', 'Gold Ingot', 'ingot', { A: '#f6d64a', B: '#c0a020', C: '#fff6b0' });
mat('ember_dust', 'Ember Dust', 'dust', { A: '#f04a20', B: '#a02a10', C: '#ffa060' });
mat('sky_crystal', 'Sky Crystal', 'gem', { A: '#5fe8e0', B: '#2aa8a0', C: '#d0fffc' });
mat('lumen_shard', 'Lumen Shard', 'dust', { A: '#f6e27a', B: '#c0a030', C: '#fff8c0' });
mat('flint', 'Flint', 'lump', { A: '#3a3a3a', B: '#202020', C: '#5a5a5a' });
mat('string', 'String', 'string', { A: '#e8e8e8', B: '#b0b0b0' });
mat('feather', 'Feather', 'feather', { A: '#f4f4f4', B: '#c0c0c0', C: '#8a8a8a' });
mat('leather', 'Leather', 'leather', { A: '#a8623a', B: '#7a4424' });
mat('clay_ball', 'Clay Ball', 'ball', { A: '#9ea4b0', B: '#6e7480' });
mat('brick', 'Brick', 'ingot', { A: '#9a4a3a', B: '#6a2a20', C: '#c07060' });
mat('snowball', 'Snowball', 'ball', { A: '#f4f8ff', B: '#c0d0e0' }, { maxStack: 16 });
mat('bone', 'Bone', 'bone', { A: '#e8e4d0', B: '#b0a890' });
mat('wheat', 'Wheat', 'wheat', { A: '#d8b040', B: '#a88020', C: '#e8d060' });
mat('wheat_seeds', 'Wheat Seeds', 'seeds', { A: '#6fa03a', B: '#3a6a20' });
mat('egg', 'Egg', 'ball', { A: '#f0e8d0', B: '#c0b090' }, { maxStack: 16 });
mat('arrow', 'Arrow', 'arrow', { A: '#8a6a3a', B: '#d0d0d0', C: '#f0f0f0' });
mat('fire_striker', 'Fire Striker', 'striker', { A: '#909090', B: '#3a3a3a', C: '#ff8a20' }, { maxStack: 1, type: 'misc' });
mat('oak_door', 'Oak Door', 'door', { A: '#9c7a4a', B: '#6a4f2c', C: '#bfe8ff' }, { block: B.DOOR_LOWER_Z, type: 'block' });
mat('spider_silk', 'Crawler Silk', 'string', { A: '#c8c0e0', B: '#8880a0' });
mat('void_essence', 'Void Essence', 'gem', { A: '#7a3ad0', B: '#3a1a70', C: '#d0a0ff' });
mat('shadow_wing', 'Shadow Wing', 'feather', { A: '#3a3050', B: '#201a30', C: '#6a5a90' });

const food = (id: string, name: string, art: string, colors: Record<string, string>, hunger: number, saturation: number, effect?: FoodStats['effect']) =>
  add({ id, name, type: 'food', maxStack: 64, icon: { art, colors }, food: { hunger, saturation, effect } });
food('apple', 'Apple', 'apple', { A: '#e03030', B: '#a01818', C: '#5a8a2a', D: '#fff' }, 4, 2.4);
food('honey_apple', 'Honey Apple', 'apple', { A: '#f2c030', B: '#c08010', C: '#5a8a2a', D: '#fff' }, 4, 9.6, 'regen');
food('bread', 'Bread', 'bread', { A: '#d8a050', B: '#a07030', C: '#f0c880' }, 5, 6);
food('carrot', 'Carrot', 'carrot', { A: '#f08030', B: '#c05a10', C: '#4a9a30' }, 3, 3.6);
food('potato', 'Potato', 'potato', { A: '#d8b060', B: '#a88040' }, 1, 0.6);
food('baked_potato', 'Baked Potato', 'potato', { A: '#c89040', B: '#8a6020' }, 5, 6);
food('melon_slice', 'Melon Slice', 'melon', { A: '#e04040', B: '#6fae4a', C: '#202020' }, 2, 1.2);
food('raw_beef', 'Raw Bovin Steak', 'meat', { A: '#d04848', B: '#902828', C: '#f0a0a0' }, 3, 1.8);
food('cooked_beef', 'Cooked Steak', 'meat', { A: '#8a5030', B: '#5a3018', C: '#b07850' }, 8, 12.8);
food('raw_mutton', 'Raw Mutton', 'meat', { A: '#d86060', B: '#a03838', C: '#f0b0b0' }, 2, 1.2);
food('cooked_mutton', 'Cooked Mutton', 'meat', { A: '#9a6038', B: '#6a3a1c', C: '#c08a60' }, 6, 9.6);
food('raw_porkchop', 'Raw Porkchop', 'meat', { A: '#f0a0a8', B: '#c07078', C: '#ffd0d8' }, 3, 1.8);
food('cooked_porkchop', 'Cooked Porkchop', 'meat', { A: '#c89060', B: '#8a6030', C: '#e8b080' }, 8, 12.8);
food('raw_chicken', 'Raw Clucker', 'meat', { A: '#f0d0c0', B: '#c0a090', C: '#fff0e8' }, 2, 1.2);
food('cooked_chicken', 'Cooked Clucker', 'meat', { A: '#d09050', B: '#a06a30', C: '#f0c080' }, 6, 7.2);
food('mushroom_stew', 'Mushroom Stew', 'bowl', { A: '#8a6a4a', B: '#c0a080', C: '#6a4a30' }, 6, 7.2);
food('berry', 'Sweet Berries', 'seeds', { A: '#d03050', B: '#801030' }, 2, 0.4);

interface Tier { name: string; label: string; tier: number; speed: number; dmg: number; dur: number; colors: Record<string, string> }
const TIERS: Tier[] = [
  { name: 'wood', label: 'Wooden', tier: 1, speed: 2, dmg: 0, dur: 59, colors: { M: '#9c7a4a', m: '#6a4f2c' } },
  { name: 'stone', label: 'Stone', tier: 2, speed: 4, dmg: 1, dur: 131, colors: { M: '#8a8a8a', m: '#5a5a5a' } },
  { name: 'copper', label: 'Copper', tier: 2, speed: 5, dmg: 1, dur: 190, colors: { M: '#d88a55', m: '#a0603a' } },
  { name: 'iron', label: 'Iron', tier: 3, speed: 6, dmg: 2, dur: 250, colors: { M: '#d8d8d8', m: '#8a8a8a' } },
  { name: 'gold', label: 'Golden', tier: 2, speed: 12, dmg: 0, dur: 32, colors: { M: '#f6d64a', m: '#b89a20' } },
  { name: 'crystal', label: 'Crystal', tier: 4, speed: 8, dmg: 3, dur: 1561, colors: { M: '#5fe8e0', m: '#2aa8a0' } },
];
const TOOL_BASE: Record<string, number> = { sword: 4, axe: 3, pickaxe: 2, shovel: 1.5, hoe: 1 };
for (const t of TIERS) {
  for (const kind of ['pickaxe', 'axe', 'shovel', 'hoe', 'sword'] as ToolKind[]) {
    add({
      id: `${t.name}_${kind}`, name: `${t.label} ${kind[0].toUpperCase()}${kind.slice(1)}`, type: 'tool', maxStack: 1,
      icon: { art: kind, colors: { ...t.colors, H: '#8a6a3a', h: '#5a4020' } },
      tool: { kind, tier: t.tier, speed: t.speed, damage: TOOL_BASE[kind] + t.dmg, durability: t.dur },
      fuel: t.name === 'wood' ? 10 : undefined,
    });
  }
}
add({ id: 'bow', name: 'Bow', type: 'bow', maxStack: 1, icon: { art: 'bow', colors: { A: '#8a6a3a', B: '#e8e8e8' } }, tool: { kind: 'none', tier: 0, speed: 1, damage: 1, durability: 384 } });
// Shield: goes in the off-hand slot. While held there, hold sneak to raise it and block most melee / arrow damage.
add({ id: 'shield', name: 'Shield', type: 'shield', maxStack: 1, icon: { art: 'shield', colors: { A: '#8a6a3a', B: '#5a4020', C: '#b8b8b8', D: '#3f6f9f' } }, tool: { kind: 'none', tier: 0, speed: 1, damage: 1, durability: 336 }, desc: 'Hold Sneak to block while it is in your off-hand.' });

interface ArmorTier { name: string; label: string; def: number[]; dur: number; colors: Record<string, string> }
const ARMOR_TIERS: ArmorTier[] = [
  { name: 'leather', label: 'Leather', def: [1, 3, 2, 1], dur: 80, colors: { A: '#a8623a', B: '#7a4424' } },
  { name: 'iron', label: 'Iron', def: [2, 6, 5, 2], dur: 240, colors: { A: '#d8d8d8', B: '#8a8a8a' } },
  { name: 'gold', label: 'Golden', def: [2, 5, 3, 1], dur: 110, colors: { A: '#f6d64a', B: '#b89a20' } },
  { name: 'crystal', label: 'Crystal', def: [3, 8, 6, 3], dur: 520, colors: { A: '#5fe8e0', B: '#2aa8a0' } },
];
const ARMOR_SLOTS = ['helmet', 'chestplate', 'leggings', 'boots'];
for (const a of ARMOR_TIERS) {
  ARMOR_SLOTS.forEach((slot, i) => {
    add({
      id: `${a.name}_${slot}`, name: `${a.label} ${slot[0].toUpperCase()}${slot.slice(1)}`, type: 'armor', maxStack: 1,
      icon: { art: slot, colors: a.colors }, armor: { slot: i, defense: a.def[i], durability: Math.round(a.dur * [0.7, 1, 0.95, 0.8][i]) },
    });
  });
}

export function itemDef(id: string): ItemDef | undefined {
  return ITEMS.get(id);
}
export function maxStack(id: string): number {
  return ITEMS.get(id)?.maxStack ?? 64;
}
export function makeStack(id: string, count = 1): ItemStack {
  const def = ITEMS.get(id);
  const s: ItemStack = { id, count };
  if (def?.tool) s.durability = def.tool.durability;
  else if (def?.armor) s.durability = def.armor.durability;
  return s;
}
export function maxDurability(id: string): number {
  const def = ITEMS.get(id);
  return def?.tool?.durability ?? def?.armor?.durability ?? 0;
}
export function canStack(a: ItemStack, b: ItemStack): boolean {
  return a.id === b.id && a.durability === undefined && b.durability === undefined && !a.ench && !b.ench;
}

export const TAGS: Record<string, string[]> = {
  planks: ['oak_planks', 'birch_planks', 'spruce_planks', 'dark_planks'],
  log: ['oak_log', 'birch_log', 'spruce_log', 'dark_log', 'stripped_log'],
  stone_tool_material: ['cobblestone', 'deep_stone'],
  coal: ['coal', 'charcoal'],
  sapling: ['oak_sapling', 'birch_sapling', 'spruce_sapling'],
};
export function matchesTag(tag: string, id: string): boolean {
  return TAGS[tag]?.includes(id) ?? false;
}

export const ALL_ITEM_IDS = (): string[] => Array.from(ITEMS.keys());
