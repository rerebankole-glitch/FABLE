import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.tsx';
import { installSprites } from './ui/sprites';
import { restoreResourcePack } from './game/core/ResourcePacks';
import { runValidation } from './game/core/Validate';

installSprites();
void restoreResourcePack(); // re-apply a persisted resource pack, if any
// Registry sanity check. In dev it runs on boot so a bad block/item/recipe shows up immediately;
// in production it stays available on demand as `fableValidate()` in the console.
if (import.meta.env.DEV) runValidation();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
