import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.tsx';
import { installSprites } from './ui/sprites';
import { restoreResourcePack } from './game/core/ResourcePacks';

installSprites();
void restoreResourcePack(); // re-apply a persisted resource pack, if any

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
