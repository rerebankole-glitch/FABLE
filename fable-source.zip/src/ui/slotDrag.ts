import type { Game } from '../game/core/Game';
import type { Container } from '../game/inventory/Inventory';
import { canStack, maxStack } from '../game/items/Items';

/**
 * Minecraft-style drag support for inventory slots.
 *
 * Clicks (press + release on the same slot, no real movement) keep the classic semantics untouched:
 * they are handled entirely by the Slot's press handlers (left = take/place, right = take half/place
 * one). This module only kicks in once the pointer moves beyond a few pixels while the button is held:
 *
 *  - Left drag: on release over another slot the carried stack is dropped there (merge or swap, exactly
 *    like a Java drop on that slot). Releasing anywhere outside the panels drops the carried stack,
 *    mirroring the game's "click outside to drop" rule so dragging an item out of the window works.
 *  - Right drag: each slot entered while holding the right button receives one item from the carried
 *    stack (Java "spread one per slot"). The slot pressed first is excluded - its press already acted.
 *  - Releasing over a gap inside a panel keeps the stack on the cursor untouched.
 */
interface Session {
  game: Game;
  btn: 0 | 2;
  x: number;
  y: number;
  moved: boolean;
  origin: { c: Container; i: number } | null;
  hover: { c: Container; i: number } | null;
  spread: { c: Container; set: Set<number> };
}

const DRAG_PX = 6; // pointer travel that turns a click into a drag

let session: Session | null = null;

export function isDragging(): boolean {
  return !!session && session.moved;
}

/** Called when a slot is pressed (before the click action runs) so drags start from a known origin. */
export function slotDragDown(game: Game, c: Container, i: number, btn: 0 | 2, x: number, y: number): void {
  session = { game, btn, x, y, moved: false, origin: { c, i }, hover: null, spread: { c, set: new Set() } };
}

/** Tracks pointer travel between slots (window-level listener) so tiny jitters stay clicks. */
export function slotDragMove(x: number, y: number): void {
  if (!session || session.moved) return;
  if (Math.abs(x - session.x) + Math.abs(y - session.y) > DRAG_PX) session.moved = true;
}

/** Called when the pointer enters / moves over a slot while a button may be held. */
export function slotDragHover(game: Game, c: Container, i: number): void {
  if (!session) return;
  if (!session.moved && !(session.btn === 2)) { session.hover = { c, i }; return; }
  session.hover = { c, i };
  const isOrigin = session.origin !== null && session.origin.c === c && session.origin.i === i;
  if (isOrigin) return; // the press on this slot already acted
  const cur = game.player.inventory.cursor;
  if (session.btn !== 2) return; // left drags act on release
  if (!cur || c.outputOnly) return;
  const set = session.spread.c === c ? session.spread.set : new Set<number>();
  session.spread = { c, set };
  if (set.has(i)) return; // one item per slot per drag, like Java
  const slot = c.get(i);
  const ok = !slot
    ? (!c.accepts || c.accepts(i, cur))
    : canStack(slot, cur) && slot.count < maxStack(cur.id);
  if (!ok) return;
  set.add(i);
  game.slotClick(c, i, 2, false); // places exactly one (or merges one onto a partial stack)
}

/** Called when the pointer leaves a slot. */
export function slotDragLeave(c: Container, i: number): void {
  if (session && session.hover && session.hover.c === c && session.hover.i === i) session.hover = null;
}

/** Release over a slot: commits the drag (merge / swap for left, nothing extra for right). */
export function slotDragUp(game: Game, c: Container, i: number): void {
  if (!session) return;
  const s = session;
  session = null;
  if (s.btn !== 0) return; // right drag already spread one-per-slot while hovering
  if (!s.moved || !game.player.inventory.cursor) return; // plain click or empty drag
  game.slotClick(c, i, 0, false); // Java-style drop: merge, or swap when the slot holds something else
}

/** Release outside the panels: drop the carried stack when the pointer was dragged out. */
export function slotDragUpWindow(e: { target: EventTarget | null }): void {
  if (!session) return;
  const s = session;
  if (s.hover) {
    // the release happened over a slot; commit it here if the slot handler did not already
    slotDragUp(s.game, s.hover.c, s.hover.i);
    return;
  }
  session = null;
  if (s.btn !== 0 || !s.moved) return;
  const t = e.target as Element | null;
  if (t && t.closest && t.closest('.inv-panel, .inv-side, .inv-creative, .inv-panel-panel')) return; // inside a panel gap: keep the stack
  if (!s.game.player.inventory.cursor) return;
  s.game.dropCursor();
}

/** Ends any drag session (used when the inventory closes). */
export function slotDragEnd(): void {
  session = null;
}
