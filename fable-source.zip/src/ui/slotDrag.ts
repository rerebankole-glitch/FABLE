import type { Game } from '../game/core/Game';
import type { Container } from '../game/inventory/Inventory';
import { canStack, maxStack } from '../game/items/Items';

/**
 * Minecraft-Java-style click & drag for inventory slots. Every action fires EXACTLY ONCE:
 *
 *  - Left press on a slot runs the click action immediately (take / place / swap / quick-move),
 *    like Java. Releasing over the same slot — even with a few pixels of hand jitter — never
 *    "undoes" it (an earlier bug re-ran the click on release and made every jittery click a no-op).
 *  - Pressing on a slot, moving past a few pixels and releasing over ANOTHER slot drops the
 *    carried stack there (merge or swap), exactly like dragging in Java.
 *  - Releasing outside the panels after a real drag drops the carried stack into the world.
 *  - Right press alone (no drag) takes half / places one ON RELEASE, so a right-click and a
 *    right-drag are distinguishable (the browser's contextmenu press must not trigger the split).
 *  - Right-drag (Java "divide"): the source stack lends itself to the cursor, every slot entered
 *    receives one item, and the remainder goes back to the source slot on release.
 */
interface Session {
  game: Game;
  btn: 0 | 2;
  x: number;
  y: number;
  shift: boolean;
  moved: boolean;
  /** true when the cursor was empty when the drag started (the source stack is "borrowed"). */
  borrowed: boolean;
  origin: { c: Container; i: number } | null;
  hover: { c: Container; i: number } | null;
  spread: { c: Container; set: Set<number> };
}

const DRAG_PX = 6; // pointer travel that turns a click into a drag

let session: Session | null = null;

/**
 * Would dropping the carried cursor stack into this slot actually do something?
 * Mirrors clickSlot's rules exactly: empty slot accepts (unless the container rejects the item,
 * e.g. armor type / furnace fuel), a partial same-type stack merges, a different item swaps only
 * when the container accepts it. Used for the always-on drop-target highlight.
 */
export function cursorCanDrop(game: Game, c: Container, i: number): boolean {
  const cur = game.player.inventory.cursor;
  if (!cur || c.outputOnly) return false;
  const slot = c.get(i);
  if (!slot) return !c.accepts || c.accepts(i, cur);
  if (canStack(slot, cur)) return slot.count < maxStack(cur.id);
  return !c.accepts || c.accepts(i, cur); // occupied by something else: a click would swap
}

export function isDragging(): boolean {
  return !!session && session.moved;
}

/** Called on press, before the left click action runs, so drags start from a known origin. */
export function slotDragDown(game: Game, c: Container, i: number, btn: 0 | 2, x: number, y: number, shift: boolean): void {
  session = {
    game, btn, x, y, shift, moved: false,
    borrowed: game.player.inventory.cursor === null,
    origin: { c, i }, hover: null, spread: { c, set: new Set() },
  };
}

/** Tracks pointer travel (window-level listener) so tiny jitters stay clicks. */
export function slotDragMove(x: number, y: number): void {
  if (!session || session.moved) return;
  if (Math.abs(x - session.x) + Math.abs(y - session.y) <= DRAG_PX) return;
  session.moved = true;
  if (session.btn !== 2 || !session.borrowed) return;
  const { game, origin } = session;
  if (!origin || origin.c.outputOnly) return;
  if (game.player.inventory.cursor) return;
  const s = origin.c.get(origin.i);
  if (!s || s.count <= 0) return;
  // The drag now exceeds the click threshold: this is a divide drag, not a click. Borrow half the
  // stack (the whole single item) onto the cursor so entering slots can receive one each.
  game.slotClick(origin.c, origin.i, 2, false);
}

/** Called when the pointer enters / moves over a slot while a button may be held. */
export function slotDragHover(game: Game, c: Container, i: number): void {
  if (!session) return;
  session.hover = { c, i };
  if (session.btn !== 2) return; // left drags act on release
  const isOrigin = session.origin !== null && session.origin.c === c && session.origin.i === i;
  if (isOrigin) return;
  const cur = game.player.inventory.cursor;
  if (!cur || c.outputOnly) return;
  const set = session.spread.c === c ? session.spread.set : new Set<number>();
  session.spread = { c, set };
  if (set.has(i)) return; // one item per slot per drag, like Java
  const slot = c.get(i);
  const ok = !slot
    ? (!c.accepts || c.accepts(i, cur))
    : canStack(slot, cur) && slot.count < maxStack(cur.id);
  if (!ok) return;
  set.add(i);
  game.slotClick(c, i, 2, false); // places exactly one (or merges one onto a partial stack)
}

/** Called when the pointer leaves a slot. */
export function slotDragLeave(c: Container, i: number): void {
  if (session && session.hover && session.hover.c === c && session.hover.i === i) session.hover = null;
}

/** Release over a slot: acts the click if it was one, or commits the drag if it was one. */
export function slotDragUp(game: Game, c: Container, i: number, btn: 0 | 2, shift: boolean): void {
  if (!session) return;
  const s = session;
  session = null;
  if (!s.moved) {
    // A click: the left press already acted; the right click acts now (once, on release).
    if (s.btn === 2) s.game.slotClick(s.origin!.c, s.origin!.i, 2, shift);
    return;
  }
  if (s.btn === 2) {
    // Divide drag: give the unspread remainder back to the source slot.
    if (s.borrowed && s.game.player.inventory.cursor && s.origin && !s.origin.c.outputOnly) {
      s.game.slotClick(s.origin.c, s.origin.i, 0, false);
    }
    return;
  }
  // Left drag: releasing over the origin is a click with jitter (press already acted -> keep it).
  if (s.origin !== null && s.origin.c === c && s.origin.i === i) return;
  if (!s.game.player.inventory.cursor) return;
  s.game.slotClick(c, i, 0, false); // drop: merge, or swap when the slot holds something else
}

/** Release anywhere else (window-level): commit the drag or drop when dragged outside. */
export function slotDragUpWindow(e: { target: EventTarget | null }): void {
  if (!session) return;
  const s = session;
  if (s.hover) {
    // the release happened over a slot; its own handler should already have run, but commit here
    // if the target slot did not receive the mouseup (e.g. release over the hovered slot's child)
    slotDragUp(s.game, s.hover.c, s.hover.i, s.btn, s.shift);
    return;
  }
  session = null;
  if (!s.moved) {
    // Click whose release landed off the slot (tiny jitter): the left press already acted; a right
    // click still needs to act.
    if (s.btn === 2) s.game.slotClick(s.origin!.c, s.origin!.i, 2, s.shift);
    return;
  }
  if (s.btn === 2) {
    if (s.borrowed && s.game.player.inventory.cursor && s.origin && !s.origin.c.outputOnly) {
      s.game.slotClick(s.origin.c, s.origin.i, 0, false);
    }
    return;
  }
  const t = e.target as Element | null;
  if (t && t.closest && t.closest('.inv-panel, .inv-side, .inv-creative, .inv-panel-panel')) return; // inside a panel gap: keep the stack
  if (!s.game.player.inventory.cursor) return;
  s.game.dropCursor();
}


// ------------------------------------------------------------------ touch (pointer) support
// Slots register their DOM element here; touch/pointer hit-testing resolves a screen point to a slot
// through elementFromPoint so dragging works with a finger (no mouseenter events on touch).

interface SlotRef { game: Game; c: Container; i: number }
const slotRegistry = new Map<Element, SlotRef>();

export function registerSlot(el: Element, game: Game, c: Container, i: number): void {
  slotRegistry.set(el, { game, c, i });
}
export function unregisterSlot(el: Element): void {
  slotRegistry.delete(el);
}

function slotAt(x: number, y: number): { ref: SlotRef; el: Element } | null {
  const els = (document.elementsFromPoint ? document.elementsFromPoint(x, y) : []) as Element[];
  if (els.length === 0 && document.elementFromPoint) {
    const e = document.elementFromPoint(x, y);
    if (e) els.push(e);
  }
  for (const e of els) {
    let n: Element | null = e;
    while (n && n !== document.body) {
      const r = slotRegistry.get(n);
      if (r) return { ref: r, el: n };
      n = n.parentElement;
    }
  }
  return null;
}

let touch: { ref: SlotRef; x0: number; y0: number; moved: boolean; shift: boolean; acted: boolean } | null = null;

/** A finger/pen press: remember the slot under the finger (taps act on release, drags on drag-start). */
export function touchDown(x: number, y: number, shift: boolean): Element | null {
  const hit = slotAt(x, y);
  if (!hit) return null;
  touch = { ref: hit.ref, x0: x, y0: y, moved: false, shift, acted: false };
  return hit.el;
}

export function touchMove(x: number, y: number): void {
  if (!touch) return;
  if (!touch.moved && Math.abs(x - touch.x0) + Math.abs(y - touch.y0) > DRAG_PX) {
    touch.moved = true;
    // The gesture is now a drag, not a tap: perform the pick-up (Java acts on press for clicks,
    // so a drag must pick up the moment it becomes a drag, before the finger reaches another slot).
    if (!touch.acted) {
      touch.acted = true;
      touch.ref.game.slotClick(touch.ref.c, touch.ref.i, 0, touch.shift);
    }
  }
}

/** Release: a tap acts once like a left click; a drag drops on the slot under release (or outside). */
export function touchUp(x: number, y: number): void {
  if (!touch) return;
  const t = touch;
  touch = null;
  const target = slotAt(x, y);
  const same = target !== null && target.ref.c === t.ref.c && target.ref.i === t.ref.i;
  if (!t.moved) {
    if (!t.acted) t.ref.game.slotClick(t.ref.c, t.ref.i, 0, t.shift); // tap = one left click
    return;
  }
  if (!t.acted) {
    // dragged from an empty/effectless slot: the release slot is the click target
    if (target && !same) t.ref.game.slotClick(target.ref.c, target.ref.i, 0, false);
    return;
  }
  if (target && !same) {
    t.ref.game.slotClick(target.ref.c, target.ref.i, 0, false); // drop the carried stack there
  } else if (!target && t.ref.game.player.inventory.cursor) {
    t.ref.game.dropCursor(); // dragged out of the window
  }
  // releasing back on the origin keeps the Java click semantics (press acted at drag-start)
}

/** Ends any drag session (used when the inventory closes). */
export function slotDragEnd(): void {
  session = null;
}
