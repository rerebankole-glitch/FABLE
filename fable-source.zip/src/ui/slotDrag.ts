import type { Game } from '../game/core/Game';
import type { Container } from '../game/inventory/Inventory';
import { canStack, maxStack } from '../game/items/Items';

/**
 * Minecraft-Java-style click & drag for inventory slots. Every action fires EXACTLY ONCE:
 *
 *  - Left press on a slot runs the click action immediately (take / place / swap / quick-move),
 *    like Java. Releasing over the same slot — even with a few pixels of hand jitter — never
 *    "undoes" it (an earlier bug re-ran the click on release and made every jittery click a no-op).
 *  - Pressing on a slot, moving past a few pixels and releasing over ANOTHER slot drops the
 *    carried stack there (merge or swap), exactly like dragging in Java.
 *  - Releasing outside the panels after a real drag drops the carried stack into the world.
 *  - Right press alone (no drag) takes half / places one ON RELEASE, so a right-click and a
 *    right-drag are distinguishable (the browser's contextmenu press must not trigger the split).
 *  - Right-drag (Java "divide"): the source stack lends itself to the cursor, every slot entered
 *    receives one item, and the remainder goes back to the source slot on release.
 */
interface Session {
  game: Game;
  btn: 0 | 2;
  x: number;
  y: number;
  shift: boolean;
  moved: boolean;
  /** true when the cursor was empty when the drag started (the source stack is "borrowed"). */
  borrowed: boolean;
  origin: { c: Container; i: number } | null;
  hover: { c: Container; i: number } | null;
  spread: { c: Container; set: Set<number> };
}

const DRAG_PX = 6; // pointer travel that turns a click into a drag

let session: Session | null = null;

export function isDragging(): boolean {
  return !!session && session.moved;
}

/** Called on press, before the left click action runs, so drags start from a known origin. */
export function slotDragDown(game: Game, c: Container, i: number, btn: 0 | 2, x: number, y: number, shift: boolean): void {
  session = {
    game, btn, x, y, shift, moved: false,
    borrowed: game.player.inventory.cursor === null,
    origin: { c, i }, hover: null, spread: { c, set: new Set() },
  };
}

/** Tracks pointer travel (window-level listener) so tiny jitters stay clicks. */
export function slotDragMove(x: number, y: number): void {
  if (!session || session.moved) return;
  if (Math.abs(x - session.x) + Math.abs(y - session.y) <= DRAG_PX) return;
  session.moved = true;
  if (session.btn !== 2 || !session.borrowed) return;
  const { game, origin } = session;
  if (!origin || origin.c.outputOnly) return;
  if (game.player.inventory.cursor) return;
  const s = origin.c.get(origin.i);
  if (!s || s.count <= 0) return;
  // The drag now exceeds the click threshold: this is a divide drag, not a click. Borrow half the
  // stack (the whole single item) onto the cursor so entering slots can receive one each.
  game.slotClick(origin.c, origin.i, 2, false);
}

/** Called when the pointer enters / moves over a slot while a button may be held. */
export function slotDragHover(game: Game, c: Container, i: number): void {
  if (!session) return;
  session.hover = { c, i };
  if (session.btn !== 2) return; // left drags act on release
  const isOrigin = session.origin !== null && session.origin.c === c && session.origin.i === i;
  if (isOrigin) return;
  const cur = game.player.inventory.cursor;
  if (!cur || c.outputOnly) return;
  const set = session.spread.c === c ? session.spread.set : new Set<number>();
  session.spread = { c, set };
  if (set.has(i)) return; // one item per slot per drag, like Java
  const slot = c.get(i);
  const ok = !slot
    ? (!c.accepts || c.accepts(i, cur))
    : canStack(slot, cur) && slot.count < maxStack(cur.id);
  if (!ok) return;
  set.add(i);
  game.slotClick(c, i, 2, false); // places exactly one (or merges one onto a partial stack)
}

/** Called when the pointer leaves a slot. */
export function slotDragLeave(c: Container, i: number): void {
  if (session && session.hover && session.hover.c === c && session.hover.i === i) session.hover = null;
}

/** Release over a slot: acts the click if it was one, or commits the drag if it was one. */
export function slotDragUp(game: Game, c: Container, i: number, btn: 0 | 2, shift: boolean): void {
  if (!session) return;
  const s = session;
  session = null;
  if (!s.moved) {
    // A click: the left press already acted; the right click acts now (once, on release).
    if (s.btn === 2) s.game.slotClick(s.origin!.c, s.origin!.i, 2, shift);
    return;
  }
  if (s.btn === 2) {
    // Divide drag: give the unspread remainder back to the source slot.
    if (s.borrowed && s.game.player.inventory.cursor && s.origin && !s.origin.c.outputOnly) {
      s.game.slotClick(s.origin.c, s.origin.i, 0, false);
    }
    return;
  }
  // Left drag: releasing over the origin is a click with jitter (press already acted -> keep it).
  if (s.origin !== null && s.origin.c === c && s.origin.i === i) return;
  if (!s.game.player.inventory.cursor) return;
  s.game.slotClick(c, i, 0, false); // drop: merge, or swap when the slot holds something else
}

/** Release anywhere else (window-level): commit the drag or drop when dragged outside. */
export function slotDragUpWindow(e: { target: EventTarget | null }): void {
  if (!session) return;
  const s = session;
  if (s.hover) {
    // the release happened over a slot; its own handler should already have run, but commit here
    // if the target slot did not receive the mouseup (e.g. release over the hovered slot's child)
    slotDragUp(s.game, s.hover.c, s.hover.i, s.btn, s.shift);
    return;
  }
  session = null;
  if (!s.moved) {
    // Click whose release landed off the slot (tiny jitter): the left press already acted; a right
    // click still needs to act.
    if (s.btn === 2) s.game.slotClick(s.origin!.c, s.origin!.i, 2, s.shift);
    return;
  }
  if (s.btn === 2) {
    if (s.borrowed && s.game.player.inventory.cursor && s.origin && !s.origin.c.outputOnly) {
      s.game.slotClick(s.origin.c, s.origin.i, 0, false);
    }
    return;
  }
  const t = e.target as Element | null;
  if (t && t.closest && t.closest('.inv-panel, .inv-side, .inv-creative, .inv-panel-panel')) return; // inside a panel gap: keep the stack
  if (!s.game.player.inventory.cursor) return;
  s.game.dropCursor();
}

/** Ends any drag session (used when the inventory closes). */
export function slotDragEnd(): void {
  session = null;
}
