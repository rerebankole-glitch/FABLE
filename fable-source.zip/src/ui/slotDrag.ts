import type { Game } from '../game/core/Game';
import type { Container } from '../game/inventory/Inventory';
import { canStack, maxStack } from '../game/items/Items';
import { clickSlot } from '../game/inventory/Inventory';

/**
 * Minecraft-Java-style click & drag for inventory slots. Every action fires EXACTLY ONCE:
 *
 *  - A plain click acts on mouse-up (exactly once - the browser's synthetic click after mouseup
 *    must not double it).
 *  - Pressing on a slot, moving past a few pixels and releasing over ANOTHER slot drops the
 *    carried stack there (merge or swap), exactly like dragging in Java. The drag picks the item
 *    up the moment it crosses the drag threshold.
 *  - The hovered slot is derived from the CURRENT pointer position on every window mousemove
 *    (geometric hit-test against the slot registry), never from mouseenter/mouseleave alone:
 *    real browsers can miss enter/leave when a re-render replaces the node under a stationary
 *    cursor, which made the hover highlight missing or stuck. Position-driven hover cannot lag,
 *    flicker or stick, at any movement speed.
 *  - Releasing where there is no slot returns the carried stack to its original slot instead of
 *    losing it (leaving the pointer/window mid-drag does the same).
 *  - Right press alone (no drag) takes half / places one ON RELEASE, so a right-click and a
 *    right-drag are distinguishable.
 *  - Right-drag (Java "divide"): the source stack lends itself to the cursor, every slot entered
 *    receives one item, and the remainder goes back to the source slot on release.
 */
interface Session {
  game: Game;
  btn: 0 | 2;
  x: number;
  y: number;
  shift: boolean;
  moved: boolean;
  /** true when the cursor was empty when the drag started (the source stack is "borrowed"). */
  borrowed: boolean;
  /** true once this gesture's action has run (pickup on drag-start, click on release) - guards
   * against the browser firing both mouseup and a synthetic click, which used to act twice. */
  acted: boolean;
  origin: { c: Container; i: number } | null;
  hover: { c: Container; i: number } | null;
  spread: { c: Container; set: Set<number> };
}

const DRAG_PX = 6; // pointer travel that turns a click into a drag

let session: Session | null = null;

/**
 * Would dropping the carried cursor stack into this slot actually do something?
 * Mirrors clickSlot's rules exactly: empty slot accepts (unless the container rejects the item,
 * e.g. armor type / furnace fuel), a partial same-type stack merges, a different item swaps only
 * when the container accepts it. Used for the always-on drop-target highlight.
 */
export function cursorCanDrop(game: Game, c: Container, i: number): boolean {
  const cur = game.player.inventory.cursor;
  if (!cur || c.outputOnly) return false;
  const slot = c.get(i);
  if (!slot) return !c.accepts || c.accepts(i, cur);
  if (canStack(slot, cur)) return slot.count < maxStack(cur.id);
  return !c.accepts || c.accepts(i, cur); // occupied by something else: a click would swap
}

export function isDragging(): boolean {
  return !!session && session.moved;
}

/** Called on press, before the left click action runs, so drags start from a known origin. */
export function slotDragDown(game: Game, c: Container, i: number, btn: 0 | 2, x: number, y: number, shift: boolean): void {
  session = {
    game, btn, x, y, shift, moved: false, acted: false,
    borrowed: game.player.inventory.cursor === null,
    origin: { c, i }, hover: null, spread: { c, set: new Set() },
  };
}

/** Tracks pointer travel (window-level listener) so tiny jitters stay clicks. */
export function slotDragMove(x: number, y: number): void {
  if (!session || session.moved) return;
  if (Math.abs(x - session.x) + Math.abs(y - session.y) <= DRAG_PX) return;
  session.moved = true;
  if (!session.borrowed || session.acted) return;
  const { game, origin } = session;
  if (!origin || origin.c.outputOnly) return;
  if (session.btn === 0) {
    // The gesture crossed the click threshold with an empty cursor: this is a left drag, not a
    // click. Pick the source stack up now (like Java's click-on-press) so releasing over another
    // slot can drop it there. An empty source slot simply picks up nothing.
    session.acted = true;
    game.slotClick(origin.c, origin.i, 0, false);
  } else if (session.btn === 2) {
    if (game.player.inventory.cursor) return;
    const s = origin.c.get(origin.i);
    if (!s || s.count <= 0) return;
    // Divide drag: borrow half the stack (the whole single item) onto the cursor so entering
    // slots can receive one each.
    session.acted = true;
    game.slotClick(origin.c, origin.i, 2, false);
  }
}

/** Called when the pointer enters / moves over a slot while a button may be held. */
export function slotDragHover(game: Game, c: Container, i: number): void {
  if (!session) return;
  session.hover = { c, i };
  if (session.btn !== 2) return; // left drags act on release
  const isOrigin = session.origin !== null && session.origin.c === c && session.origin.i === i;
  if (isOrigin) return;
  const cur = game.player.inventory.cursor;
  if (!cur || c.outputOnly) return;
  const set = session.spread.c === c ? session.spread.set : new Set<number>();
  session.spread = { c, set };
  if (set.has(i)) return; // one item per slot per drag, like Java
  const slot = c.get(i);
  const ok = !slot
    ? (!c.accepts || c.accepts(i, cur))
    : canStack(slot, cur) && slot.count < maxStack(cur.id);
  if (!ok) return;
  set.add(i);
  game.slotClick(c, i, 2, false); // places exactly one (or merges one onto a partial stack)
}

/** Called when the pointer leaves a slot. */
export function slotDragLeave(c: Container, i: number): void {
  if (session && session.hover && session.hover.c === c && session.hover.i === i) session.hover = null;
}

/** Release over a slot: acts the click if it was one, or commits the drag if it was one. */
export function slotDragUp(game: Game, c: Container, i: number, btn: 0 | 2, shift: boolean): void {
  if (!session) return;
  const s = session;
  session = null;
  if (!s.moved) {
    // A plain click: act exactly once here on release. (The browser will also fire a synthetic
    // click afterwards, but drag-enabled slots have no onClick action, so nothing doubles.)
    if (!s.acted) {
      s.acted = true;
      s.game.slotClick(s.origin!.c, s.origin!.i, s.btn, s.shift);
    }
    return;
  }
  if (s.btn === 2) {
    // Divide drag: give the unspread remainder back to the source slot.
    if (s.borrowed && s.game.player.inventory.cursor && s.origin && !s.origin.c.outputOnly) {
      s.game.slotClick(s.origin.c, s.origin.i, 0, false);
    }
    return;
  }
  // Left drag: drop the carried stack on the release slot (merge, or swap when the slot holds
  // something else). Nothing to drop when the drag started from an empty slot.
  if (!s.game.player.inventory.cursor) return;
  s.game.slotClick(c, i, 0, false); // drop: merge, or swap when the slot holds something else
}

/** Release anywhere else (window-level): commit the release geometrically. */
export function slotDragUpWindow(e: { target: EventTarget | null }): void {
  if (!session) return;
  const s = session;
  // Geometric commit: the release point's slot is whatever is under the pointer RIGHT NOW (the
  // slot's own mouseup handler normally runs first and consumes the session; this catches the
  // cases where it did not, e.g. release over a child or a re-render race).
  const hov = hoveredSlot();
  if (hov) {
    slotDragUp(s.game, hov.c, hov.i, s.btn, s.shift);
    return;
  }
  session = null;
  if (!s.moved) {
    // Click whose release landed off the slot (tiny jitter): act exactly once here. The browser
    // fires no synthetic click (press and release targets differ), so nothing doubles.
    if (!s.acted) {
      s.acted = true;
      s.game.slotClick(s.origin!.c, s.origin!.i, s.btn, s.shift);
    }
    return;
  }
  if (s.btn === 2) {
    // Divide drag: give the unspread remainder back to the source slot.
    if (s.borrowed && s.game.player.inventory.cursor && s.origin && !s.origin.c.outputOnly) {
      s.game.slotClick(s.origin.c, s.origin.i, 0, false);
    }
    return;
  }
  // Left drag released where there is no slot: return the carried stack to its original slot
  // instead of dropping/losing it.
  returnCursorToOrigin(s.game, s.origin);
}

/** Put the carried stack back where the gesture started (or into the bag) rather than losing it. */
function returnCursorToOrigin(game: Game, origin: { c: Container; i: number } | null): void {
  const inv = game.player.inventory;
  const cur = inv.cursor;
  if (!cur) return;
  if (origin && !origin.c.outputOnly) {
    const slot = origin.c.get(origin.i);
    const fitsEmpty = !slot && (!origin.c.accepts || origin.c.accepts(origin.i, cur));
    const fitsMerge = !!slot && canStack(slot, cur) && slot.count < maxStack(cur.id);
    if (fitsEmpty || fitsMerge) {
      clickSlot(inv, origin.c, origin.i, 0, false); // places or merges back
      return;
    }
  }
  if (inv.add(cur) === 0) { inv.cursor = null; return; } // bag has room: keep the stack safe
  // nowhere to put it: it stays on the cursor rather than being lost
}

/** The pointer left the window / the app blurred mid-gesture: never lose a carried stack. */
export function abortDragSafe(): void {
  if (!session) return;
  const s = session;
  session = null;
  if (!s.moved) return; // a bare press: just cancel
  if (s.btn === 2) {
    if (s.borrowed && s.game.player.inventory.cursor && s.origin && !s.origin.c.outputOnly) {
      s.game.slotClick(s.origin.c, s.origin.i, 0, false);
    }
    return;
  }
  returnCursorToOrigin(s.game, s.origin);
}


// ------------------------------------------------------------------ hover (mouse)
// The hovered slot is derived from the CURRENT pointer position on every window mousemove by
// hit-testing the slot registry (elementsFromPoint, exactly like the touch path) - never from
// mouseenter/mouseleave alone, which browsers can miss or mis-order (a re-render replacing the
// node under a stationary cursor drops the enter; a fast sweep can skip elements). Position-driven
// hover means: pointer position -> exact slot -> highlight, updated on EVERY pointer move, with no
// flicker, no sticking and no dependence on movement speed. rAF re-checks after re-renders keep
// the highlight consistent even when the DOM under a resting cursor is replaced.

interface SlotRef { game: Game; c: Container; i: number; hover?: (hovering: boolean) => void }
const slotRegistry = new Map<Element, SlotRef>();

let hoverEl: Element | null = null;
let pointerX = 0, pointerY = 0, hasPointer = false;

export function registerSlot(el: Element, game: Game, c: Container, i: number, onHover?: (hovering: boolean) => void): void {
  slotRegistry.set(el, { game, c, i, hover: onHover });
  // Adopt instantly when this slot mounts under the resting pointer (no move needed).
  if (hasPointer && !hoverEl && slotAt(pointerX, pointerY)?.el === el) setHovered(el);
}

export function unregisterSlot(el: Element): void {
  if (hoverEl === el) {
    slotRegistry.get(el)?.hover?.(false);
    hoverEl = null;
  }
  slotRegistry.delete(el);
}

/** Feed the current pointer position (window mousemove). Updates the hovered slot immediately. */
export function pointerMoved(x: number, y: number): void {
  pointerX = x; pointerY = y; hasPointer = true;
  setHovered(slotAt(x, y)?.el ?? null);
}

/** The pointer left the window: no slot can be hovered. */
export function pointerLeftWindow(): void {
  hasPointer = false;
  setHovered(null);
}

/** Re-run the hit test at the last known pointer position (call after re-renders / layout changes). */
export function recheckHover(): void {
  if (hasPointer) setHovered(slotAt(pointerX, pointerY)?.el ?? null);
}

/** The slot currently under the pointer (registry entry), if any. */
export function hoveredSlot(): SlotRef | null {
  return hoverEl ? slotRegistry.get(hoverEl) ?? null : null;
}

function setHovered(el: Element | null): void {
  if (el === hoverEl) return;
  if (hoverEl) slotRegistry.get(hoverEl)?.hover?.(false);
  hoverEl = el;
  if (hoverEl) slotRegistry.get(hoverEl)?.hover?.(true);
}

function slotAt(x: number, y: number): { ref: SlotRef; el: Element } | null {
  const els = (document.elementsFromPoint ? document.elementsFromPoint(x, y) : []) as Element[];
  if (els.length === 0 && document.elementFromPoint) {
    const e = document.elementFromPoint(x, y);
    if (e) els.push(e);
  }
  for (const e of els) {
    let n: Element | null = e;
    while (n && n !== document.body) {
      const r = slotRegistry.get(n);
      if (r) return { ref: r, el: n };
      n = n.parentElement;
    }
  }
  // No native hit-test result (jsdom, exotic engines): fall back to bounding boxes.
  for (const [el] of slotRegistry) {
    const r = el.getBoundingClientRect?.();
    if (r && r.width > 0 && x >= r.left && x < r.right && y >= r.top && y < r.bottom) return { ref: slotRegistry.get(el)!, el };
  }
  return null;
}

let touch: { ref: SlotRef; x0: number; y0: number; moved: boolean; shift: boolean; acted: boolean } | null = null;

/** A finger/pen press: remember the slot under the finger (taps act on release, drags on drag-start). */
export function touchDown(x: number, y: number, shift: boolean): Element | null {
  const hit = slotAt(x, y);
  if (!hit) return null;
  touch = { ref: hit.ref, x0: x, y0: y, moved: false, shift, acted: false };
  return hit.el;
}

export function touchMove(x: number, y: number): void {
  if (!touch) return;
  if (!touch.moved && Math.abs(x - touch.x0) + Math.abs(y - touch.y0) > DRAG_PX) {
    touch.moved = true;
    // The gesture is now a drag, not a tap: perform the pick-up (Java acts on press for clicks,
    // so a drag must pick up the moment it becomes a drag, before the finger reaches another slot).
    if (!touch.acted) {
      touch.acted = true;
      touch.ref.game.slotClick(touch.ref.c, touch.ref.i, 0, touch.shift);
    }
  }
}

/** Release: a tap acts once like a left click; a drag drops on the slot under release (or outside). */
export function touchUp(x: number, y: number): void {
  if (!touch) return;
  const t = touch;
  touch = null;
  const target = slotAt(x, y);
  const same = target !== null && target.ref.c === t.ref.c && target.ref.i === t.ref.i;
  if (!t.moved) {
    if (!t.acted) t.ref.game.slotClick(t.ref.c, t.ref.i, 0, t.shift); // tap = one left click
    return;
  }
  if (!t.acted) {
    // dragged from an empty/effectless slot: the release slot is the click target
    if (target && !same) t.ref.game.slotClick(target.ref.c, target.ref.i, 0, false);
    return;
  }
  if (target && !same) {
    t.ref.game.slotClick(target.ref.c, target.ref.i, 0, false); // drop the carried stack there
  } else if (!target && t.ref.game.player.inventory.cursor) {
    t.ref.game.dropCursor(); // dragged out of the window
  }
  // releasing back on the origin keeps the Java click semantics (press acted at drag-start)
}

/** Ends any drag session (used when the inventory closes). */
export function slotDragEnd(): void {
  session = null;
}
