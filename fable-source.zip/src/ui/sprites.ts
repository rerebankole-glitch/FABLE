// Pixel-art GUI sprites, generated at startup and exposed as CSS custom properties (data-URI PNGs).
// Everything is drawn from tiny palette-indexed bitmaps so the single-file build stays asset-free.

type Palette = Record<string, string>;

function bitmap(rows: string[], palette: Palette, scale = 1): string {
  const h = rows.length, w = rows[0].length;
  const c = document.createElement('canvas');
  c.width = w * scale; c.height = h * scale;
  const ctx = c.getContext('2d')!;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const col = palette[rows[y][x]];
    if (!col) continue;
    ctx.fillStyle = col;
    ctx.fillRect(x * scale, y * scale, scale, scale);
  }
  return `url("${c.toDataURL('image/png')}")`;
}

// 9x9 heart (container / full / half) — classic GUI icon layout
const HEART_BG = [
  '.XX...XX.',
  'XddX.XddX',
  'XdddXdddX',
  'XdddddddX',
  '.XdddddX.',
  '..XdddX..',
  '...XdX...',
  '....X....',
  '.........',
];
const HEART_FULL = [
  '.XX...XX.',
  'XhrX.XrrX',
  'XhrrXrrrX',
  'XrrrrrrrX',
  '.XrrrrrX.',
  '..XrrrX..',
  '...XrX...',
  '....X....',
  '.........',
];
const HEART_HALF = [
  '.XX......',
  'XhrX.....',
  'XhrrX....',
  'Xrrrr....',
  '.Xrrr....',
  '..Xrr....',
  '...Xr....',
  '....X....',
  '.........',
];
// 9x9 drumstick (hunger)
const DRUM_BG = [
  '....XXXX.',
  '...XddddX',
  '...XddddX',
  '..XXdddX.',
  '.XddXXX..',
  'XdddX....',
  'XddX.....',
  'XXX......',
  '.........',
];
const DRUM_FULL = [
  '....XXXX.',
  '...XmmmmX',
  '...XmmlmX',
  '..XXmmmX.',
  '.XbbXXX..',
  'XbbbX....',
  'XbbX.....',
  'XXX......',
  '.........',
];
const DRUM_HALF = [
  '....XXXX.',
  '...XddddX',
  '...XddddX',
  '..XXdddX.',
  '.XbbXXX..',
  'XbbbX....',
  'XbbX.....',
  'XXX......',
  '.........',
];
// 9x9 chestplate (armor)
const ARMOR_BG = [
  'XXX...XXX',
  'XddX.XddX',
  'XdddXdddX',
  'XdddddddX',
  '.XdddddX.',
  '.XdddddX.',
  '.XdddddX.',
  '.XXXXXXX.',
  '.........',
];
const ARMOR_FULL = [
  'XXX...XXX',
  'XssX.XssX',
  'XsssXsssX',
  'XsssssssX',
  '.XsssssX.',
  '.XsshssX.',
  '.XsssssX.',
  '.XXXXXXX.',
  '.........',
];
const ARMOR_HALF = [
  'XXX...XXX',
  'XssX.XddX',
  'XsssXdddX',
  'XssssdddX',
  '.XsssddX.',
  '.XsshddX.',
  '.XsssddX.',
  '.XXXXXXX.',
  '.........',
];
// 9x9 air bubble
const BUBBLE = [
  '..XXXXX..',
  '.XwwwwbX.',
  'XwwbbbbbX',
  'XwbbbbbbX',
  'XbbbbbbbX',
  'XbbbbbbbX',
  'XbbbbbbwX',
  '.XbbbbwX.',
  '..XXXXX..',
];
const BUBBLE_POP = [
  '.........',
  '..X...X..',
  '.........',
  '....X....',
  '.X.....X.',
  '....X....',
  '.........',
  '..X...X..',
  '.........',
];
// 22x15 crafting arrow
const ARROW = [
  '..............XX......',
  '..............XaX.....',
  '..............XaaX....',
  '..............XaaaX...',
  'XXXXXXXXXXXXXXXaaaaX..',
  'XaaaaaaaaaaaaaaaaaaaX.',
  'XaaaaaaaaaaaaaaaaaaaaX',
  'XaaaaaaaaaaaaaaaaaaaX.',
  'XXXXXXXXXXXXXXXaaaaX..',
  '..............XaaaX...',
  '..............XaaX....',
  '..............XaX.....',
  '..............XX......',
  '......................',
  '......................',
];
// 14x14 furnace flame
const FIRE = [
  '......X.......',
  '.....XfX......',
  '.....XfX..X...',
  '....XffX.XfX..',
  '....XffXXffX..',
  '...XfffXfffX..',
  '..XfffffffffX.',
  '..XffyyyfffX..',
  '.XffyyyyyffX..',
  '.XfyyywyyyfX..',
  '.XfyywwwyyfX..',
  '..XfyywwyyfX..',
  '..XffyyyyffX..',
  '...XXXXXXXX...',
];
// 16x16 dirt tile for menu backgrounds (4 shades, deterministic noise)
function dirtTile(): string {
  const shades = ['#5b3f27', '#6a4a2e', '#4c3420', '#755433', '#3e2a19'];
  const rows: string[] = [];
  let s = 1337;
  const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let y = 0; y < 16; y++) {
    let r = '';
    for (let x = 0; x < 16; x++) { const v = rnd(); r += v < 0.42 ? 'a' : v < 0.68 ? 'b' : v < 0.86 ? 'c' : v < 0.95 ? 'd' : 'e'; }
    rows.push(r);
  }
  return bitmap(rows, { a: shades[0], b: shades[1], c: shades[2], d: shades[3], e: shades[4] }, 4);
}
// 16x16 grass-block side used as the default world icon
function worldIconTile(): string {
  const rows: string[] = [];
  let s = 4242;
  const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let y = 0; y < 16; y++) {
    let r = '';
    for (let x = 0; x < 16; x++) {
      const v = rnd();
      if (y < 3 || (y === 3 && v < 0.6) || (y === 4 && v < 0.25)) r += v < 0.5 ? 'g' : 'G';
      else r += v < 0.42 ? 'a' : v < 0.68 ? 'b' : v < 0.86 ? 'c' : 'd';
    }
    rows.push(r);
  }
  return bitmap(rows, { g: '#7cbd4a', G: '#5f9a35', a: '#5b3f27', b: '#6a4a2e', c: '#4c3420', d: '#755433' }, 4);
}

// 16x16 empty-slot silhouettes (armour pieces, shield, off-hand) drawn as a slightly darker grey on the slot
const SIL_HELMET = [
  '................',
  '................',
  '.....XXXXXX.....',
  '....XXXXXXXX....',
  '...XXXXXXXXXX...',
  '...XXXXXXXXXX...',
  '...XXXXXXXXXX...',
  '...XXXXXXXXXX...',
  '...XXX....XXX...',
  '...XXX....XXX...',
  '...XXX....XXX...',
  '...XXXX..XXXX...',
  '................',
  '................',
  '................',
  '................',
];
const SIL_CHEST = [
  '................',
  '..XXXX....XXXX..',
  '..XXXXX..XXXXX..',
  '..XXXXXXXXXXXX..',
  '..XX.XXXXXX.XX..',
  '..XX.XXXXXX.XX..',
  '.....XXXXXX.....',
  '.....XXXXXX.....',
  '.....XXXXXX.....',
  '.....XXXXXX.....',
  '.....XXXXXX.....',
  '.....XXXXXX.....',
  '.....XXXXXX.....',
  '................',
  '................',
  '................',
];
const SIL_LEGS = [
  '................',
  '...XXXXXXXXXX...',
  '...XXXXXXXXXX...',
  '...XXXXXXXXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '...XXXX..XXXX...',
  '................',
  '................',
];
const SIL_BOOTS = [
  '................',
  '................',
  '................',
  '................',
  '...XXX....XXX...',
  '...XXX....XXX...',
  '...XXX....XXX...',
  '...XXX....XXX...',
  '...XXX....XXX...',
  '..XXXX....XXXX..',
  '.XXXXX....XXXXX.',
  '.XXXXX....XXXXX.',
  '.XXXXX....XXXXX.',
  '................',
  '................',
  '................',
];
const SIL_SHIELD = [
  '................',
  '...XXXXXXXXXX...',
  '...X........X...',
  '...X........X...',
  '...X........X...',
  '...X........X...',
  '...X........X...',
  '...X........X...',
  '...X........X...',
  '....X......X....',
  '.....X....X.....',
  '......X..X......',
  '.......XX.......',
  '................',
  '................',
  '................',
];

// 16x16 recipe book (green cover, pale pages, dark spine)
const BOOK = [
  '................',
  '..oooooooooooo..',
  '.oGGGGGoGGGGGGo.',
  '.oGggggoGGGGGGo.',
  '.oGgppgoGGggGGo.',
  '.oGgppgoGGggGGo.',
  '.oGggggoGGGGGGo.',
  '.oGGGGGoGGGGGGo.',
  '.oGGGGGoGGGGGGo.',
  '.oGGGGGoGGGGGGo.',
  '.oGGGGGoGGGGGGo.',
  '.oGGGGGoGGGGGGo.',
  '.oooooooooooooo.',
  '..pppppppppppp..',
  '...oooooooooo...',
  '................',
];

let installed = false;
/** Generate all sprites once and install them as CSS variables on :root. */
export function installSprites(): void {
  if (installed || typeof document === 'undefined') return;
  installed = true;
  const root = document.documentElement.style;
  const X = '#000000';
  const heartPal = { X, d: '#4a0000', h: '#ff8a8a', r: '#ff1313' };
  const drumPal = { X, d: '#3c2b12', m: '#c88a4a', l: '#e8b070', b: '#e8dcc0' };
  const armorPal = { X, d: '#4d4d4d', s: '#c8c8c8', h: '#ffffff' };
  const bubblePal = { X: '#1f3f6f', w: '#ffffff', b: '#4f8ff0' };
  const set = (k: string, v: string) => root.setProperty(k, v);
  set('--spr-heart-bg', bitmap(HEART_BG, heartPal, 2));
  set('--spr-heart-full', bitmap(HEART_FULL, heartPal, 2));
  set('--spr-heart-half', bitmap(HEART_HALF, heartPal, 2));
  set('--spr-drum-bg', bitmap(DRUM_BG, drumPal, 2));
  set('--spr-drum-full', bitmap(DRUM_FULL, drumPal, 2));
  set('--spr-drum-half', bitmap(DRUM_HALF, drumPal, 2));
  set('--spr-armor-bg', bitmap(ARMOR_BG, armorPal, 2));
  set('--spr-armor-full', bitmap(ARMOR_FULL, armorPal, 2));
  set('--spr-armor-half', bitmap(ARMOR_HALF, armorPal, 2));
  set('--spr-bubble', bitmap(BUBBLE, bubblePal, 2));
  set('--spr-bubble-pop', bitmap(BUBBLE_POP, { X: '#9fd0ff' }, 2));
  set('--spr-arrow', bitmap(ARROW, { X: '#000000', a: '#8b8b8b' }, 1));
  set('--spr-arrow-big-off', bitmap(ARROW, { X: '#3f3f3f', a: '#8b8b8b' }, 2));
  set('--spr-arrow-big-on', bitmap(ARROW, { X: '#3f3f3f', a: '#ffffff' }, 2));
  set('--spr-fire-off', bitmap(FIRE, { X: '#3f3f3f', f: '#6f6f6f', y: '#8b8b8b', w: '#a0a0a0' }, 2));
  set('--spr-fire-on', bitmap(FIRE, { X: '#3f3f3f', f: '#ff6a00', y: '#ffb300', w: '#ffee80' }, 2));
  set('--spr-book', bitmap(BOOK, { o: '#2a2a1a', G: '#4f8a3a', g: '#8ac06a', p: '#e8dcb8' }, 2));
  const silPal = { X: '#5f5f5f' };
  set('--sil-helmet', bitmap(SIL_HELMET, silPal, 2));
  set('--sil-chest', bitmap(SIL_CHEST, silPal, 2));
  set('--sil-legs', bitmap(SIL_LEGS, silPal, 2));
  set('--sil-boots', bitmap(SIL_BOOTS, silPal, 2));
  set('--sil-shield', bitmap(SIL_SHIELD, silPal, 2));
  set('--dirt-tile', dirtTile());
  set('--world-icon-tile', worldIconTile());
}
