import React, { useEffect, useRef, useState } from 'react';
import { store, useStore } from './store';
import { itemIcon } from '../game/items/Icons';
import { itemDef, maxDurability } from '../game/items/Items';
import type { ItemStack } from '../game/core/types';
import { Btn } from './components';
import { settings, t } from '../game/core/Settings';
import { Game } from '../game/core/Game';
import { ENCHANTMENTS } from '../game/structures/Loot';
import { slotDragDown, slotDragHover, slotDragLeave, slotDragUp } from './slotDrag';

const ROMAN = ['I', 'II', 'III', 'IV', 'V'];

export function itemName(id: string): string {
  return itemDef(id)?.name ?? id.replace(/_/g, ' ');
}

export function Slot({ stack, selected, onClick, onContext, size = 44, dim, highlight, className, onHover, ghost, drag }: {
  stack: ItemStack | null; selected?: boolean; onClick?: (e: React.MouseEvent) => void; onContext?: (e: React.MouseEvent) => void;
  size?: number; dim?: boolean; highlight?: boolean; className?: string; onHover?: (s: ItemStack | null, e?: React.MouseEvent) => void; ghost?: boolean;
  /** Enables Minecraft-style press-drag-release for this slot (carried stacks drop on release). */
  drag?: { game: import('../game/core/Game').Game; c: import('../game/inventory/Inventory').Container; i: number };
}) {
  const url = stack ? itemIcon(stack.id) : null;
  const max = stack ? maxDurability(stack.id) : 0;
  const dur = stack && max > 0 && stack.durability !== undefined && stack.durability < max ? stack.durability / max : null;
  const ench = !!(stack?.ench && Object.keys(stack.ench).length > 0);
  return (
    <div
      className={'slot' + (selected ? ' slot-selected' : '') + (dim ? ' slot-dim' : '') + (highlight ? ' slot-highlight' : '') + (className ? ' ' + className : '')}
      style={{ width: size, height: size }}
      onMouseDown={(e) => {
        if (e.button === 0) {
          e.preventDefault();
          if (drag) slotDragDown(drag.game, drag.c, drag.i, 0, e.clientX, e.clientY, e.shiftKey);
          onClick?.(e);
        } else if (e.button === 2 && drag) {
          slotDragDown(drag.game, drag.c, drag.i, 2, e.clientX, e.clientY, e.shiftKey);
        }
      }}
      onContextMenu={(e) => {
        e.preventDefault();
        // Drag-enabled slots act the right click on mouseup (so a right-drag does not split first);
        // plain slots keep the press-based context action.
        if (!drag) onContext?.(e);
      }}
      onMouseUp={(e) => {
        if (drag && (e.button === 0 || e.button === 2)) slotDragUp(drag.game, drag.c, drag.i, e.button as 0 | 2, e.shiftKey);
      }}
      onMouseEnter={(e) => { onHover?.(stack, e); if (drag) slotDragHover(drag.game, drag.c, drag.i); }}
      onMouseMove={(e) => { onHover?.(stack, e); if (drag) slotDragHover(drag.game, drag.c, drag.i); }}
      onMouseLeave={() => { onHover?.(null); if (drag) slotDragLeave(drag.c, drag.i); }}
    >
      {url && <img src={url} draggable={false} alt="" className={'slot-icon' + (ench ? ' slot-ench' : '') + (ghost ? ' slot-ghost' : '')} style={{ width: size * 0.72, height: size * 0.72 }} />}
      {stack && stack.count > 1 && <span className="slot-count">{stack.count}</span>}
      {dur !== null && (
        <div className="slot-dur"><div className="slot-dur-fill" style={{ width: `${Math.max(0, dur) * 100}%`, background: dur > 0.5 ? '#4c4' : dur > 0.25 ? '#cc4' : '#c44' }} /></div>
      )}
    </div>
  );
}

export interface TooltipLine { text: string; kind?: 'ench' | 'stat' | 'desc' | 'muted' }

const TIER_NAMES = ['', 'Wood', 'Stone', 'Iron', 'Crystal'];

/** Builds the structured tooltip for an item stack: title + typed lines (used by the inventory and the hotbar). */
export function tooltipLines(stack: ItemStack): { title: string; lines: TooltipLine[] } {
  const def = itemDef(stack.id);
  const lines: TooltipLine[] = [];
  if (stack.ench) for (const k in stack.ench) lines.push({ text: `${ENCHANTMENTS[k]?.name ?? k.replace(/_/g, ' ')} ${ROMAN[stack.ench[k] - 1] ?? stack.ench[k]}`, kind: 'ench' });
  if (def?.tool) {
    const digs = def.tool.kind !== 'sword' && def.tool.kind !== 'none';
    if (def.tool.damage > 1) lines.push({ text: `Damage: ${def.tool.damage}`, kind: 'stat' });
    if (digs) lines.push({ text: `Mining speed: ${def.tool.speed}x`, kind: 'stat' });
    if (digs && def.tool.tier > 0) lines.push({ text: `Tier: ${TIER_NAMES[def.tool.tier] ?? def.tool.tier}`, kind: 'stat' });
  }
  if (def?.armor) lines.push({ text: `Armor: +${def.armor.defense}`, kind: 'stat' });
  if (def?.food) lines.push({ text: `Hunger: +${def.food.hunger}`, kind: 'stat' });
  const max = maxDurability(stack.id);
  if (max > 0) lines.push({ text: `Durability: ${stack.durability ?? max} / ${max}`, kind: 'stat' });
  if (def?.block !== undefined && def.block > 0) lines.push({ text: 'Block', kind: 'muted' });
  if (def?.desc) lines.push({ text: def.desc, kind: 'desc' });
  if (stack.count > 1) lines.push({ text: `x${stack.count}`, kind: 'muted' });
  return { title: def?.name ?? stack.id, lines };
}

export function Tooltip({ stack, x, y }: { stack: ItemStack | null; x: number; y: number }) {
  if (!stack) return null;
  const { title, lines } = tooltipLines(stack);
  const left = Math.min(x + 14, window.innerWidth - 230);
  return (
    <div className="tooltip" style={{ left, top: Math.min(y + 14, window.innerHeight - 60 - lines.length * 16) }}>
      <div className={'tooltip-title' + (stack.ench ? ' tooltip-ench' : '')}>{title}</div>
      {lines.map((l, i) => <div key={i} className={'tooltip-line' + (l.kind ? ' tooltip-' + l.kind : '')}>{l.text}</div>)}
    </div>
  );
}

/** Nameplate + health bar for the mob under the crosshair. */
function TargetPlate({ target }: { target: { name: string; hp: number; hostile: boolean } | null }) {
  if (!target) return null;
  return (
    <div className={'target-plate' + (target.hostile ? ' hostile' : '')}>
      <div className="target-name">{target.name}</div>
      <div className="target-track"><div className="target-fill" style={{ width: `${Math.round(target.hp * 100)}%` }} /></div>
    </div>
  );
}

function SaveIndicator({ saving, savedAt, now }: { saving: boolean; savedAt: number; now: number }) {
  if (saving) return <div className="save-indicator">Saving...</div>;
  if (savedAt && now - savedAt < 2500) return <div className="save-indicator saved">World saved</div>;
  return null;
}

function Hearts({ health, max, hurt }: { health: number; max: number; hurt: number }) {
  const n = Math.ceil(max / 2);
  return (
    <div className={'hud-row hearts' + (hurt > 0 ? ' shake' : '')}>
      {Array.from({ length: n }, (_, i) => {
        const v = health - i * 2;
        const cls = v >= 2 ? 'full' : v >= 1 ? 'half' : 'empty';
        return <span key={i} className={'heart ' + cls + (health <= 4 ? ' low' : '')} />;
      })}
    </div>
  );
}

function Hunger({ hunger }: { hunger: number }) {
  return (
    <div className="hud-row hunger">
      {Array.from({ length: 10 }, (_, i) => {
        const v = hunger - (9 - i) * 2;
        const cls = v >= 2 ? 'full' : v >= 1 ? 'half' : 'empty';
        return <span key={i} className={'drum ' + cls} />;
      })}
    </div>
  );
}

function Armor({ armor }: { armor: number }) {
  if (armor <= 0) return null;
  return (
    <div className="hud-row armor">
      {Array.from({ length: 10 }, (_, i) => {
        const v = armor - i * 2;
        const cls = v >= 2 ? 'full' : v >= 1 ? 'half' : 'empty';
        return <span key={i} className={'armor-icon ' + cls} />;
      })}
    </div>
  );
}

function Air({ air }: { air: number }) {
  if (air >= 300) return null;
  const bubbles = Math.ceil((air / 300) * 10);
  return (
    <div className="hud-row air">
      {Array.from({ length: 10 }, (_, i) => <span key={i} className={'bubble ' + (i < 10 - bubbles ? 'pop' : 'full')} />)}
    </div>
  );
}

/** Hotbar reads the live inventory from the game (re-rendered on every inventory bump). */
function Hotbar({ game, selected }: { game: Game; selected: number }) {
  useStore((s) => s.inv);
  const main = game.player.inventory.main;
  return (
    <div className="hotbar">
      {Array.from({ length: 9 }, (_, i) => <Slot key={i} stack={main.get(i)} selected={i === selected} size={40} onClick={() => game.selectSlot(i)} />)}
    </div>
  );
}

function useClock(interval: number): number {
  const [, force] = useState(0);
  useEffect(() => { const id = setInterval(() => force((n) => n + 1), interval); return () => clearInterval(id); }, [interval]);
  return performance.now();
}

export function HUD({ game }: { game: Game }) {
  const hud = useStore((s) => s.hud);
  const debug = useStore((s) => s.debug);
  const overlay = useStore((s) => s.overlay);
  const chatOpen = useStore((s) => s.chatOpen);
  const chat = useStore((s) => s.chat);
  const messages = useStore((s) => s.messages);
  const paused = useStore((s) => s.paused);
  const mobile = useStore((s) => s.mobile);
  const inv = useStore((s) => s.inv);
  const popups = useStore((s) => s.popups);
  const [chatText, setChatText] = useState('');
  const chatRef = useRef<HTMLInputElement>(null);
  const now = useClock(500);
  const survival = hud.mode === 'survival';
  const [heldName, setHeldName] = useState<{ text: string; at: number }>({ text: '', at: 0 });

  useEffect(() => { if (chatOpen) setTimeout(() => chatRef.current?.focus(), 10); }, [chatOpen]);
  const heldId = game.player.inventory.main.get(hud.selected)?.id ?? '';
  useEffect(() => { setHeldName({ text: heldId ? itemName(heldId) : '', at: performance.now() }); }, [heldId, hud.selected, inv]);

  const lastMsgId = messages.length ? messages[messages.length - 1].id : -1;
  // action messages (yellow, centred) are also kept in the chat log for history, but while one is on screen do not show it twice
  const recentChat = (chatOpen ? chat.slice(-12) : chat.filter((m) => now - m.time < 10000).slice(-6)).filter((m) => chatOpen || m.id !== lastMsgId || now - m.time >= 3000);
  const msg = messages.length ? messages[messages.length - 1] : null;
  const showMsg = msg && now - msg.time < 3000;
  const showHeld = !showMsg && settings.value.heldItemTooltips && heldName.text && now - heldName.at < 2500;

  return (
    <div className="hud">
      {hud.underwater && <div className="overlay-water" />}
      {hud.effects.includes('burning') && <div className="overlay-fire" />}
      {hud.hurt > 0 && settings.value.damageTint && <div className="overlay-hurt" style={{ opacity: Math.min(0.6, hud.hurt) }} />}
      {hud.portal > 0 && <div className="overlay-portal" style={{ opacity: hud.portal * 0.85 }} />}
      {hud.sleeping > 0 && <div className="overlay-sleep" style={{ opacity: hud.sleeping }} />}
      {!overlay && !chatOpen && !paused && !mobile && <div className={'crosshair crosshair-' + settings.value.crosshairStyle} style={{ ['--ch-size' as any]: settings.value.crosshairSize, ['--ch-color' as any]: settings.value.crosshairColor }} />}
      {hud.bossName && (
        <div className="boss-bar">
          <div className="boss-name">{hud.bossName}</div>
          <div className="boss-track"><div className="boss-fill" style={{ width: `${hud.bossHp * 100}%` }} /></div>
        </div>
      )}
      {debug && <div className="debug">{debug.split('\n').map((l, i) => <div key={i}>{l}</div>)}</div>}
      {!debug && hud.coords && <div className="coords">{hud.coords}</div>}
      <SaveIndicator saving={hud.saving} savedAt={hud.savedAt} now={now} />
      {!overlay && !paused && <TargetPlate target={hud.target} />}
      {popups.map((p, i) => <div key={i} className={'dmg-popup' + (p.text.startsWith('*') ? ' crit' : '')} style={{ left: p.x, top: p.y, opacity: p.a }}>{p.text.replace('*', '')}</div>)}
      {hud.effects.length > 0 && (
        <div className="effects">
          {hud.effects.map((e) => <div key={e} className={'effect effect-' + e}>{e}</div>)}
        </div>
      )}
      <div className={'chat-box' + (chatOpen ? ' chat-open' : '')}>
        {recentChat.map((m) => <div key={m.id} className="chat-line" style={{ opacity: chatOpen ? 1 : Math.min(1, (10000 - (now - m.time)) / 1500) }}>{m.text}</div>)}
      </div>
      {chatOpen && (
        <form className="chat-input-wrap" onSubmit={(e) => { e.preventDefault(); const text = chatText; setChatText(''); game.chat(text); }}>
          <input ref={chatRef} className="chat-input" value={chatText} onChange={(e) => setChatText(e.target.value)} autoComplete="off" spellCheck={false}
            onKeyDown={(e) => { e.stopPropagation(); if (e.key === 'Escape') { setChatText(''); game.chat(''); } }} onKeyUp={(e) => e.stopPropagation()} placeholder="Type a message or /command" />
        </form>
      )}
      <div className="hud-bottom" style={{ opacity: settings.value.hudOpacity }}>
        {showMsg && <div className="action-text">{msg!.text}</div>}
        {showHeld && <div className="held-name">{heldName.text}</div>}
        {survival && (
          <div className="status-bars">
            <div className="status-left">
              <Armor armor={hud.armor} />
              <Hearts health={hud.health} max={hud.maxHealth} hurt={hud.hurt} />
            </div>
            <div className="status-right">
              <Air air={hud.air} />
              <Hunger hunger={hud.hunger} />
            </div>
          </div>
        )}
        {survival && (
          <div className="xp-bar">
            <div className="xp-fill" style={{ width: `${Math.min(1, hud.xp) * 100}%` }} />
            {hud.level > 0 && <div className="xp-level">{hud.level}</div>}
          </div>
        )}
        <Hotbar game={game} selected={hud.selected} />
      </div>
    </div>
  );
}

export function PauseMenu({ game, onQuit }: { game: Game; onQuit: () => void }) {
  const [confirmQuit, setConfirmQuit] = useState(false);
  const [saved, setSaved] = useState(false);
  const online = game.transport.connected;
  const quitLabel = online ? t('disconnect') : t('exit_menu');
  return (
    <div className="menu-screen menu-dim pause-menu">
      <div className="menu-center">
        <h2 className="menu-title">{t('game_menu')}</h2>
        <div className="menu-list">
          <Btn onClick={() => game.resume()}>{t('resume')}</Btn>
          <div className="menu-row">
            <Btn onClick={() => store.goto('settings')}>{t('options')}</Btn>
            {!online
              ? <Btn onClick={() => { game.saveWorld().then(() => { setSaved(true); setTimeout(() => setSaved(false), 1500); }); }}>{saved ? t('saved') : t('save')}</Btn>
              : <Btn disabled>{`${game.remotePlayers.size + 1} online`}</Btn>}
          </div>
          {!confirmQuit && <Btn onClick={() => setConfirmQuit(true)}>{quitLabel}</Btn>}
          {confirmQuit && <div className="menu-row"><Btn danger onClick={onQuit}>{quitLabel}</Btn><Btn onClick={() => setConfirmQuit(false)}>{t('cancel')}</Btn></div>}
        </div>
        <div className="menu-footer">
          <span>{online ? `Connected to ${game.options.name}` : `Seed: ${game.options.seed}`}</span>
          <span>Day {game.day + 1}</span>
        </div>
      </div>
    </div>
  );
}

export function DeathScreen({ game, onQuit }: { game: Game; onQuit: () => void }) {
  const deathMessage = useStore((s) => s.deathMessage);
  const hud = useStore((s) => s.hud);
  return (
    <div className="menu-screen death-screen">
      <div className="menu-center">
        <h1 className="menu-title death-title">{t('you_died')}</h1>
        <p className="menu-text">{deathMessage}</p>
        <p className="menu-text">Score: {hud.level * 10}</p>
        <div className="menu-list">
          <Btn onClick={() => game.respawn()}>{t('respawn')}</Btn>
          <Btn onClick={onQuit}>{t('main_menu')}</Btn>
        </div>
      </div>
    </div>
  );
}

const TIPS = [
  'Torches keep hostile creatures from spawning nearby.',
  'Hold Ctrl (or double-tap W) to sprint; Shift sneaks.',
  'Keepers in villages trade for emeralds and food.',
  'Cave crawlers climb: light your tunnels.',
  'Crops grow faster next to water.',
  'Press F3 for coordinates, biome and performance.',
  'Falling sand and gravel can be dug out from below.',
  'Beds set your spawn point and skip the night.',
  'Stone Guardians drop sky crystals: the key to the Void portal.',
  'A crafting table unlocks the full 3x3 recipe grid.',
];

export function LoadingScreen() {
  const loading = useStore((s) => s.loading);
  const worldName = useStore((s) => s.worldName);
  const now = useClock(400);
  const [tip] = useState(() => TIPS[Math.floor(Math.random() * TIPS.length)]);
  return (
    <div className="menu-screen dirt-bg loading-screen">
      <div className="menu-center">
        <h2 className="menu-title">{worldName || t('loading')}</h2>
        <p className="menu-text">{(loading.stage || t('loading')).replace(/\.{3}$/, '')}{'.'.repeat(1 + (Math.floor(now / 400) % 3))}</p>
        <div className="progress"><div className="progress-fill" style={{ width: `${Math.round(Math.min(1, loading.progress) * 100)}%` }} /></div>
        <p className="menu-text small muted">{loading.detail || `${Math.round(Math.min(1, loading.progress) * 100)}%`}</p>
        <p className="loading-tip">{tip}</p>
      </div>
    </div>
  );
}
