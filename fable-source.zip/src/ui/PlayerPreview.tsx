import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { useStore } from './store';
import { itemDef } from '../game/items/Items';
import { settings } from '../game/core/Settings';
import { buildSkinFigure, getSkinCanvas, prepareSkinCanvas, type SkinFigureParts } from '../game/core/SkinTexture';
import type { Game } from '../game/core/Game';

/**
 * Small live render of the player's voxel figure for the inventory screen. When a skin texture has
 * been uploaded the vanilla player model is drawn with the real skin pixels (head + hat, jacket and
 * sleeves, trousers and their overlays, slim-arm layouts included); otherwise the palette-colour
 * figure is shown. The figure idles (breathing, slight sway), turns to follow the mouse and shows
 * the armour currently worn. It owns a tiny WebGL renderer of its own so it can live inside the
 * React overlay without touching the game scene.
 */
interface PreviewRig { renderer: THREE.WebGLRenderer; scene: THREE.Scene; camera: THREE.PerspectiveCamera; parts: FigureParts }
interface FigureParts extends SkinFigureParts { armor: THREE.Mesh[][] }

// One shared WebGL context for every preview (inventory figure + options skin figure): browsers cap
// the number of live contexts and evict the oldest one when the cap is hit, which could be the
// game's own canvas. The rig is rebuilt whenever the skin-relevant settings change; `null` means
// "build on the next call". (An earlier `undefined` sentinel meant a key change disposed the rig
// into `null` where it could never be rebuilt — leaving the preview permanently blank after an
// upload until the page reloaded.)
let rig: (PreviewRig & { skinKey: string }) | null = null;
let rigBusy: Promise<void> | null = null;
function skinKey(): string {
  const sk = settings.value.skin ?? { skin: '#d8a878', hair: '#5a3a22', shirt: '#3f6f9f', pants: '#3b3b5a' };
  return [settings.value.skinUrl, settings.value.skinSlim ? 'slim' : 'wide', sk.skin, sk.hair, sk.shirt, sk.pants].join('|');
}
// Reads go through this accessor so type narrowing never confuses "null because not built yet"
// with the "null after a skin change" case the code below relies on.
function currentRig(): (PreviewRig & { skinKey: string }) | null { return rig; }
async function getRig(width: number, height: number): Promise<PreviewRig | null> {
  const key = skinKey();
  const cur = currentRig();
  if (cur && cur.skinKey !== key) { cur.renderer.dispose(); rig = null; }
  if (rig) return sizeRig(rig, width, height);
  if (rigBusy) { try { await rigBusy; } catch { /* a failed build leaves rig null; retry below */ } }
  if (rig) return sizeRig(rig, width, height); // a concurrent caller finished the build first
  const want = skinKey();
  if (want !== key) return getRig(width, height); // skin changed while another build was running
  const build = (async () => {
    try {
      // the uploaded skin may still be decoding (settings load before the texture does)
      if (settings.value.skinUrl && !getSkinCanvas(settings.value.skinUrl)) {
        await prepareSkinCanvas(settings.value.skinUrl);
        if (skinKey() !== want) return; // skin changed while decoding; the settings re-run this effect
      }
      const canvas = document.createElement('canvas');
      canvas.className = 'player-figure';
      const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: true, powerPreference: 'low-power' });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(26, 1, 0.1, 20);
      // Frame the whole figure (feet at y=0, hat top ≈ y=2.03) centred with even margins so the
      // preview shows the full skin — head and feet never touch the panel edges while spinning.
      camera.position.set(0, 1.05, 7.0);
      camera.lookAt(0, 1.05, 0);
      scene.add(new THREE.AmbientLight(0xffffff, 0.75));
      const keyL = new THREE.DirectionalLight(0xffffff, 1.4); keyL.position.set(1.5, 3, 2.5); scene.add(keyL);
      const fill = new THREE.DirectionalLight(0x8fb4ff, 0.6); fill.position.set(-2, 1, -2); scene.add(fill);
      const parts = buildFigure();
      scene.add(parts.root);
      rig = { renderer, scene, camera, parts, skinKey: want };
    } catch {
      rig = null;
    }
  })();
  rigBusy = build;
  try { await build; } finally { if (rigBusy === build) rigBusy = null; }
  // If the skin changed while building, `rig` stays null and the effect that observed the change
  // rebuilds it on its next run.
  const made = currentRig();
  return made ? sizeRig(made, width, height) : null;
}

function sizeRig(r: PreviewRig, width: number, height: number): PreviewRig {
  r.renderer.setSize(width, height, false);
  r.camera.aspect = width / height;
  r.camera.updateProjectionMatrix();
  return r;
}

export function PlayerPreview({ game, width = 96, height = 170 }: { game: Game; width?: number; height?: number }) {
  const host = useRef<HTMLDivElement>(null);
  const invVersion = useStore((s) => s.inv);
  const mouse = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let disposed = false;
    let raf = 0;
    void (async () => {
      const r = await getRig(width, height);
      if (disposed || !el || !r) return;
      el.appendChild(r.renderer.domElement);
      syncArmor(r, game);
      let t = 0; let last = performance.now();
      const loop = (now: number) => {
        raf = requestAnimationFrame(loop);
        const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
        const p = r.parts; const k = Math.min(1, dt * 6);
        // idle: breathing + subtle arm sway; head and body turn toward the pointer
        p.root.rotation.y += ((mouse.current.x * 0.6) - p.root.rotation.y) * k;
        p.head.rotation.x += ((-mouse.current.y * 0.35) - p.head.rotation.x) * k;
        p.head.rotation.y += ((mouse.current.x * 0.35) - p.head.rotation.y) * k;
        p.body.position.y = 18 / 16 + Math.sin(t * 1.6) * 0.008;
        p.arms[0].rotation.x = Math.sin(t * 1.6) * 0.04; p.arms[1].rotation.x = -Math.sin(t * 1.6) * 0.04;
        p.arms[0].rotation.z = 0.05 + Math.sin(t * 1.1) * 0.02; p.arms[1].rotation.z = -0.05 - Math.sin(t * 1.1) * 0.02;
        r.renderer.render(r.scene, r.camera);
      };
      raf = requestAnimationFrame(loop);
    })();
    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      const r = rig;
      if (r && r.renderer.domElement.parentNode === el) el.removeChild(r.renderer.domElement);
    };
  }, [width, height, game]);

  // armour overlays follow the inventory
  useEffect(() => {
    const r = rig;
    if (r) syncArmor(r, game);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game, invVersion]);

  return (
    <div ref={host} className="player-figure-host" style={{ width, height }}
      onMouseMove={(e) => { const b = e.currentTarget.getBoundingClientRect(); mouse.current = { x: ((e.clientX - b.left) / b.width - 0.5) * 2, y: ((e.clientY - b.top) / b.height - 0.5) * 2 }; }}
      onMouseLeave={() => { mouse.current = { x: 0, y: 0 }; }} />
  );
}

function syncArmor(r: PreviewRig, game: Game): void {
  const armor = game.player.inventory.armor;
  for (let i = 0; i < 4; i++) {
    const s = armor.get(i);
    const def = s ? itemDef(s.id) : undefined;
    const col = def?.icon && 'colors' in def.icon && def.icon.colors ? def.icon.colors.A : null;
    for (const m of r.parts.armor[i]) {
      m.visible = !!col;
      if (col) (m.material as THREE.MeshLambertMaterial).color.set(col);
    }
  }
}

/**
 * Build the player figure: the real skin model when a texture is uploaded, otherwise the palette
 * figure (skin/hair/shirt/pants colour pickers). Armour overlays are attached afterwards so both
 * paths share the same silhouettes.
 */
function buildFigure(): FigureParts {
  const url = settings.value.skinUrl;
  const sk = settings.value.skin ?? { skin: '#d8a878', hair: '#5a3a22', shirt: '#3f6f9f', pants: '#3b3b5a' };
  const slim = !!settings.value.skinSlim;
  const parts: FigureParts = url && getSkinCanvas(url)
    ? { ...buildSkinFigure(getSkinCanvas(url)!, slim), armor: [] }
    : buildPaletteFigure(slim);
  attachArmor(parts, slim);
  return parts;
}

/** Steve-free original figure when no texture is uploaded: rounded-off skin tones, tunic and trousers. */
function buildPaletteFigure(slim: boolean): FigureParts {
  const root = new THREE.Group();
  const sk = settings.value.skin ?? { skin: '#d8a878', hair: '#5a3a22', shirt: '#3f6f9f', pants: '#3b3b5a' };
  const hx = (h: string): number => (h.startsWith('#') ? parseInt(h.slice(1), 16) : Number(h));
  const shade = (c: number, f: number): number => {
    const r = Math.min(255, Math.max(0, Math.round(((c >> 16) & 255) * f))), g = Math.min(255, Math.max(0, Math.round(((c >> 8) & 255) * f))), b = Math.min(255, Math.max(0, Math.round((c & 255) * f)));
    return (r << 16) | (g << 8) | b;
  };
  const SKIN = hx(sk.skin), TUNIC = hx(sk.shirt), TROUSER = hx(sk.pants), HAIR = hx(sk.hair);
  const mat = (c: number) => new THREE.MeshLambertMaterial({ color: c });
  const box = (w: number, h: number, d: number, c: number, x: number, y: number, z: number, pivotTop = false) => {
    const g = new THREE.BoxGeometry(w / 16, h / 16, d / 16);
    if (pivotTop) g.translate(0, -h / 32, 0);
    const m = new THREE.Mesh(g, mat(c)); m.position.set(x / 16, y / 16, z / 16); return m;
  };
  const aw = slim ? 3 : 4;
  const legs = [box(3.9, 12, 4, TROUSER, -2, 12, 0, true), box(3.9, 12, 4, TROUSER, 2, 12, 0, true)];
  const body = box(8, 12, 4, TUNIC, 0, 18, 0);
  const arms = [box(aw, 12, 4, TUNIC, -(4 + aw / 2), 24, 0, true), box(aw, 12, 4, TUNIC, (4 + aw / 2), 24, 0, true)];
  // hands: the arm geometry is pivoted at its top, so the hand sits at the bottom 3 px
  for (const a of arms) { const hand = box(aw + 0.02, 3, 4.02, SKIN, 0, 0, 0); hand.position.y = -(12 - 1.5) / 16; a.add(hand); }
  const head = new THREE.Group(); head.position.set(0, 24 / 16, 0);
  head.add(box(8, 8, 8, SKIN, 0, 4, 0));
  head.add(box(8.4, 3, 8.4, HAIR, 0, 6.6, 0)); // hair cap
  head.add(box(8.4, 1.5, 0.4, HAIR, 0, 5.4, 4.2)); // fringe
  head.add(box(2, 1, 0.3, 0x202020, -2, 3.5, 4.1), box(2, 1, 0.3, 0x202020, 2, 3.5, 4.1)); // eyes
  head.add(box(1, 1, 0.3, 0xffffff, -2.5, 3.5, 4.15), box(1, 1, 0.3, 0xffffff, 1.5, 3.5, 4.15)); // eye highlights
  head.add(box(2, 0.8, 0.3, 0xb07850, 0, 1.6, 4.1)); // mouth
  root.add(...legs, body, ...arms, head);
  return { root, head, body, arms, legs, armor: [], materials: [] };
}

/** Attach the armour overlay boxes (hidden unless worn): helmet, chestplate, leggings, boots. */
function attachArmor(parts: FigureParts, slim: boolean): void {
  const root = parts.root, head = parts.head, arms = parts.arms, legs = parts.legs;
  const mat = () => new THREE.MeshLambertMaterial({ color: 0xffffff });
  const ov = (w: number, h: number, d: number, x: number, y: number, z: number, parent: THREE.Object3D, pivotTop = false) => {
    const g = new THREE.BoxGeometry(w / 16, h / 16, d / 16);
    if (pivotTop) g.translate(0, -h / 32, 0);
    const m = new THREE.Mesh(g, mat()); m.position.set(x / 16, y / 16, z / 16); m.visible = false; parent.add(m); return m;
  };
  // open-faced helmet: cap, back plate and cheek plates so the face stays visible
  const helmet = [ov(9, 3.6, 9, 0, 6.8, 0, head), ov(9, 6, 1, 0, 2.6, -4.1, head), ov(1, 6, 9, -4.1, 2.6, 0, head), ov(1, 6, 9, 4.1, 2.6, 0, head)];
  const ax = slim ? 3.5 : 5;
  const chest = [ov(9, 12.6, 5, 0, 18, 0, root), ov(ax, 12.4, 5, 0, 0, 0, arms[0], true), ov(ax, 12.4, 5, 0, 0, 0, arms[1], true)];
  const legsA = [ov(4.8, 12.2, 4.8, 0, 0, 0, legs[0], true), ov(4.8, 12.2, 4.8, 0, 0, 0, legs[1], true), ov(8.6, 4, 4.6, 0, 13, 0, root)];
  const boots = [ov(5, 5, 5, 0, 0, 0, legs[0]), ov(5, 5, 5, 0, 0, 0, legs[1])];
  for (const m of boots) m.position.y = -9.5 / 16; // bottom of the (top-pivoted) leg
  parts.armor = [helmet, chest, legsA, boots];
}

/**
 * Free-standing 3D figure for the skin section of the Options screen: the player model with the
 * current skin texture (or palette colours) turning slowly, exactly as it will appear in the game.
 * It shares the module-wide preview rig with the inventory figure, so opening the inventory never
 * creates a second WebGL context. Re-mounts (and rebuilds) automatically when the skin changes.
 */
export function FigureView({ width = 132, height = 200, className = 'skin-figure', spin = true }: { width?: number; height?: number; className?: string; spin?: boolean }) {
  const host = useRef<HTMLDivElement>(null);
  // re-run the effect whenever the skin-relevant settings change (texture, slim, palette colours)
  const key = skinKey();
  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let disposed = false;
    let raf = 0;
    void (async () => {
      const r = await getRig(width, height);
      if (disposed || !el || !r) return;
      el.appendChild(r.renderer.domElement);
      let t = 0; let last = performance.now();
      const loop = (now: number) => {
        raf = requestAnimationFrame(loop);
        const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
        const p = r.parts; const k = Math.min(1, dt * 6);
        // turn slowly so every side of the skin is visible; idle breathing + arm sway
        p.root.rotation.y = spin ? t * 0.7 : p.root.rotation.y;
        p.body.position.y = 18 / 16 + Math.sin(t * 1.6) * 0.008;
        p.arms[0].rotation.x = Math.sin(t * 1.6) * 0.04; p.arms[1].rotation.x = -Math.sin(t * 1.6) * 0.04;
        p.arms[0].rotation.z = 0.05 + Math.sin(t * 1.1) * 0.02; p.arms[1].rotation.z = -0.05 - Math.sin(t * 1.1) * 0.02;
        r.renderer.render(r.scene, r.camera);
      };
      raf = requestAnimationFrame(loop);
    })();
    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      const r = rig;
      if (r && r.renderer.domElement.parentNode === el) el.removeChild(r.renderer.domElement);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width, height, key, spin]);
  return <div ref={host} className={className} aria-label="3D player skin preview" />;
}
