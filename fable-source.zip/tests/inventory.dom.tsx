// Real-DOM inventory suite: mounts the actual Slot component (the one every inventory grid uses),
// dispatches real mouse events (mousedown / mousemove / mouseover / mouseup) through React, and
// verifies pick-up / drag / crafting-grid placement / click flows end to end, including full-screen
// re-renders between press and release (what store.bump does in the real game).
// Run:  node tools/build-dom-test.mjs && node run-dom.mjs
import React, { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { Slot } from '../src/ui/HUD';
import { slotDragMove, slotDragUpWindow } from '../src/ui/slotDrag';
import { PlayerInventory, ArrayContainer, clickSlot } from '../src/game/inventory/Inventory';
import type { Container } from '../src/game/inventory/Inventory';
import { makeStack } from '../src/game/items/Items';
import type { ItemStack } from '../src/game/core/types';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, extra = '') => {
  console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : ''));
  if (cond) pass++; else fail++;
};

interface FakeGame {
  player: { inventory: PlayerInventory };
  craftGrid: ArrayContainer;
  craftOutput: Container;
  slotClick(c: Container, i: number, b: 0 | 2, shift: boolean): void;
}

function mkGame(): FakeGame {
  const inv = new PlayerInventory();
  const craftGrid = new ArrayContainer(9);
  let outSlot: ItemStack | null = null;
  const craftOutput: Container = {
    size: 1, outputOnly: true,
    get: () => outSlot,
    set: () => { /* output set only through onTake */ },
    onTake: () => { outSlot = null; for (let i = 0; i < 9; i++) craftGrid.set(i, null); },
  };
  return {
    player: { inventory: inv }, craftGrid, craftOutput,
    slotClick(c: Container, i: number, b: 0 | 2, shift: boolean) {
      clickSlot(inv, c, i, b, false);
    },
  };
}

export function run(doc: Document): void {
  const game = mkGame();
  const inv = game.player.inventory;
  const main = inv.main;

  let tick: () => void = () => {};
  let bump: () => void = () => {};

  function App() {
    const [, setN] = React.useState(0);
    tick = () => setN((n) => n + 1);
    bump = () => { setN((n) => n + 1); };
    const grid = (c: Container, count: number, from = 0, tag: string) =>
      Array.from({ length: count }, (_, k) => {
        const i = from + k;
        return (
          <div key={tag + (from + k)}>
            <Slot stack={c.get(i)} drag={{ game: game as never, c, i }}
              onClick={(e) => game.slotClick(c, i, 0, e.shiftKey)}
              onContext={(e) => game.slotClick(c, i, 2, e.shiftKey)} />
          </div>
        );
      });
    return (
      <div>
        <div className="inv-main">{grid(main, 9, 0, 'm')}</div>
        <div className="craft-area">{grid(game.craftGrid, 4, 0, 'c')}</div>
        <div className="craft-out">{grid(game.craftOutput, 1, 0, 'o')}</div>
      </div>
    );
  }

  let root: Root;
  act(() => {
    root = createRoot(doc.getElementById('root')!);
    root.render(<App />);
  });

  // The real inventory screen wires these window listeners in a mount effect; mirror them.
  const win = doc.defaultView as unknown as EventTarget;
  const onMove = (e: Event) => slotDragMove((e as MouseEvent).clientX, (e as MouseEvent).clientY);
  const onUp = (e: Event) => slotDragUpWindow({ target: e.target as EventTarget | null });
  win.addEventListener('mousemove', onMove);
  win.addEventListener('mouseup', onUp);

  const slotEls = (container: Container): Element[] => {
    const base = Array.from(doc.querySelectorAll('.slot'));
    if (container === main) return base.slice(0, 9);
    if (container === game.craftGrid) return base.slice(9, 13);
    return base.slice(13, 14);
  };
  const fire = (type: string, target: EventTarget | null, opts: Record<string, unknown> = {}) => {
    const Ctor = (target && (target as Element).ownerDocument?.defaultView?.MouseEvent) ?? MouseEvent;
    const e = new Ctor(type, { bubbles: true, cancelable: true, button: 0, clientX: 0, clientY: 0, ...opts });
    act(() => {
      if (type === 'mousemove') win.dispatchEvent(e);
      else if (target) (target as Element).dispatchEvent(e);
      else doc.dispatchEvent(e);
    });
  };
  const press = (el: Element, x: number, y: number) => fire('mousedown', el, { button: 0, clientX: x, clientY: y });
  const release = (el: Element, x: number, y: number) => fire('mouseup', el, { button: 0, clientX: x, clientY: y });
  const move = (x: number, y: number) => fire('mousemove', null, { clientX: x, clientY: y });
  const enter = (from: Element, to: Element) => {
    act(() => {
      fire('mouseout', from, { relatedTarget: to });
      fire('mouseover', to, { relatedTarget: from });
    });
  };

  // ---- S1: plain clicks - press slot 0 (pick up), press slot 4 (place)
  main.set(0, makeStack('cobblestone', 10));
  let m = slotEls(main);
  act(() => { press(m[0], 10, 10); release(m[0], 14, 12); });      // small jitter on origin
  ok('S1 pickup with click (jitter on origin keeps it)', inv.cursor?.count === 10 && main.get(0) === null);
  act(() => { press(m[4], 60, 10); release(m[4], 63, 12); });
  ok('S1 place into slot 4 by click', main.get(4)?.count === 10 && inv.cursor === null);

  // ---- S2: real drag from main slot 1 into a crafting cell, with a full re-render (store.bump
  // equivalent) between the pickup press and the release
  main.set(1, makeStack('oak_log', 4));
  m = slotEls(main);
  const craftEls = slotEls(game.craftGrid);
  act(() => { press(m[1], 10, 40); });        // pick up (press acts)
  act(() => bump());                          // the real game store.bump()s here -> full re-render
  move(400, 300);                             // > 6px: becomes a drag
  act(() => bump());                          // re-render mid-drag, like cursor-stack mounts
  act(() => { enter(m[1], craftEls[1]); release(craftEls[1], 400, 300); });
  ok('S2 dragged oak_log into crafting cell 1 across re-renders', game.craftGrid.get(1)?.id === 'oak_log' && game.craftGrid.get(1)!.count === 4 && inv.cursor === null && main.get(1) === null);

  // ---- S3: drag the ingredient back out of the craft grid into the bag (slot 7)
  const bagEls = slotEls(main);
  act(() => { press(craftEls[1], 400, 300); });
  act(() => bump());
  move(700, 500);
  act(() => { enter(craftEls[1], bagEls[7]); release(bagEls[7], 700, 500); });
  ok('S3 dragged ingredient back to bag slot 7', main.get(7)?.id === 'oak_log' && game.craftGrid.get(1) === null && inv.cursor === null);

  // ---- S4: press on empty slot then release elsewhere never fabricates a stack
  act(() => { press(bagEls[0], 10, 500); });
  move(200, 200);
  act(() => { enter(bagEls[0], craftEls[0]); release(craftEls[0], 200, 200); });
  ok('S4 drag from an empty slot does nothing', inv.cursor === null && game.craftGrid.get(0) === null);

  // ---- S5: pickup by press, then release over a DIFFERENT slot without passing the 6px threshold is a click -> press acted only
  main.set(2, makeStack('dirt', 2));
  act(() => { press(m[2], 30, 30); });
  act(() => { enter(m[2], m[3]); release(m[3], 32, 32); });        // < 6px of travel: still a click, stack stays on cursor
  ok('S5 unsteady release (<6px) never places or undoes', inv.cursor?.id === 'dirt' && main.get(3) === null);
  act(() => { press(m[3], 50, 30); release(m[3], 52, 31); });      // clean up: place it
  ok('S5 placed on the next steady click', main.get(3)?.id === 'dirt' && inv.cursor === null);

  // ---- S6: craft output pickup (outputOnly) by click, then place into main
  game.craftGrid.set(0, makeStack('oak_log', 1));
  game.craftGrid.set(1, makeStack('oak_log', 1));
  (game.craftOutput as { get: () => ItemStack | null }).get = () => makeStack('oak_planks', 4);
  const outEl = slotEls(game.craftOutput)[0];
  act(() => { press(outEl, 900, 300); release(outEl, 903, 302); });
  ok('S6 crafted output picked up on cursor', inv.cursor?.id === 'oak_planks' && inv.cursor.count === 4);
  act(() => { press(m[6], 80, 30); release(m[6], 83, 32); });
  ok('S6 output placed into main slot 6', main.get(6)?.id === 'oak_planks' && inv.cursor === null);

  // ---- S7: always-on drop-target highlight while carrying
  main.set(0, makeStack('cobblestone', 10));
  m = slotEls(main);
  act(() => { press(m[0], 10, 10); release(m[0], 14, 12); });   // cursor holds cobble x10
  act(() => { enter(m[0], m[2]); });                             // hover an empty valid slot
  ok('S7 hovered slot highlighted while carrying', m[2].classList.contains('slot-drop-ok'));
  act(() => { press(m[2], 40, 10); release(m[2], 43, 12); });   // click-to-drop into slot 2
  act(() => bump());                                             // store.bump re-render
  ok('S7 click drops it and the highlight clears', main.get(2)?.id === 'cobblestone' && inv.cursor === null && !m[2].classList.contains('slot-drop-ok'));
  act(() => { enter(m[2], m[3]); });
  ok('S7 no highlight with an empty cursor', !m[3].classList.contains('slot-drop-ok'));

  // ---- S8: the output slot is never shown as a drop target, ordinary slots always are
  main.set(1, makeStack('oak_log', 3));
  act(() => { press(m[1], 20, 10); release(m[1], 23, 12); });   // cursor holds oak x3
  act(() => { enter(m[1], outEl); });
  ok('S8 output slot never highlights as a drop target', !outEl.classList.contains('slot-drop-ok'));
  act(() => { enter(outEl, m[5]); });
  ok('S8 an ordinary slot highlights again', m[5].classList.contains('slot-drop-ok'));
  act(() => { press(m[5], 60, 10); release(m[5], 63, 12); });   // drop it
  act(() => bump());

  console.log(`\n${pass} passed, ${fail} failed`);
  if (fail > 0) process.exit(1);
}
