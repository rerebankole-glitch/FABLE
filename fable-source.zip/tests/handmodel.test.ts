// Held-item geometry checks: the item model must be built at the art's native resolution (one
// voxel per painted pixel, not a 2x2 clump), and the grip pose must actually land the item in the
// fist and fill the lower-right of the screen.
import * as THREE from 'three';

let pass = 0, fail = 0;
const ok = (c: boolean, m: string): void => { if (c) pass++; else { fail++; console.error('FAIL: ' + m); } };

const D = Math.PI / 180;
const AX = new THREE.Vector3(1, 0, 0), AY = new THREE.Vector3(0, 1, 0), AZ = new THREE.Vector3(0, 0, 1);

/** Java 1.8 first-person arm chain (mirrors Game.buildHandChain at rest). */
function handChain(sw = 1, side = 1, eq = 0): THREE.Matrix4 {
  const sq = Math.sqrt(sw);
  const f = -0.3 * Math.sin(sq * Math.PI), f1 = 0.4 * Math.sin(sq * Math.PI * 2), f2 = -0.4 * Math.sin(sw * Math.PI);
  const f3 = Math.sin(sw * sw * Math.PI), f4 = Math.sin(sq * Math.PI);
  const mv = new THREE.Matrix4(), T = new THREE.Matrix4();
  mv.multiply(T.makeTranslation(f, f1, f2));
  mv.multiply(new THREE.Matrix4().makeTranslation(0.64000005, -0.6, -0.71999997));
  mv.multiply(T.makeTranslation(0, eq * -0.6, 0));
  mv.multiply(new THREE.Matrix4().makeRotationY(Math.PI / 4));
  mv.multiply(T.makeRotationAxis(AY, f4 * 70 * D));
  mv.multiply(new THREE.Matrix4().makeRotationAxis(AZ, f3 * -20 * D));
  mv.multiply(new THREE.Matrix4().makeTranslation(-1, 3.6, 3.5));
  mv.multiply(new THREE.Matrix4().makeRotationAxis(AZ, 120 * D)
    .multiply(new THREE.Matrix4().makeRotationAxis(AX, 200 * D))
    .multiply(new THREE.Matrix4().makeRotationAxis(AY, -135 * D))
    .multiply(new THREE.Matrix4().makeTranslation(5.6, 0, 0)));
  if (side < 0) { const S = new THREE.Matrix4().makeScale(-1, 1, 1); mv.premultiply(S); mv.multiply(S); }
  return mv;
}

// constants mirrored from Game.ts
const HELD_ARM_OFFSET = { x: -0.02, y: -0.17, z: -0.06 };
const HELD_FIST_PX = { x: -6, y: 12, z: 0 };
const HELD_ITEM_OFFSET = { x: -0.13, y: 0.16, z: 0.02 };
const HELD_ITEM_YAW = -35 * D, HELD_ITEM_ROLL = 25 * D;
const HELD_ITEM_SCALE = 0.78;
const HELD_GRIP = { x: 0.28, y: 0.28 };

const cam = new THREE.PerspectiveCamera(70, 16 / 9, 0.05, 600);
cam.updateMatrixWorld();
const proj = (v: THREE.Vector3): [number, number] => {
  const p = v.clone().project(cam);
  return [(p.x * 0.5 + 0.5) * 100, (0.5 - p.y * 0.5) * 100];
};

for (const side of [1, -1]) {
  const amv = handChain(1, side, 0);
  const off = new THREE.Vector3(side * HELD_ARM_OFFSET.x, HELD_ARM_OFFSET.y, HELD_ARM_OFFSET.z);
  const fist = new THREE.Vector3(side * HELD_FIST_PX.x, HELD_FIST_PX.y, HELD_FIST_PX.z)
    .multiplyScalar(0.0625).applyMatrix4(amv).add(off);
  const fs = proj(fist);
  const label = side > 0 ? 'right' : 'left';
  ok(fist.z < -0.2, `${label}: fist is behind/at the camera (z=${fist.z.toFixed(2)})`);
  ok(fs[1] > 50, `${label}: fist should sit in the lower half of the screen, got y=${fs[1].toFixed(0)}%`);
  ok(side > 0 ? fs[0] > 50 : fs[0] < 50, `${label}: fist on the wrong side (x=${fs[0].toFixed(0)}%)`);

  // item anchored at that fist
  const m = new THREE.Matrix4().makeTranslation(
    fist.x + HELD_ITEM_OFFSET.x * side, fist.y + HELD_ITEM_OFFSET.y, fist.z + HELD_ITEM_OFFSET.z);
  m.multiply(new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(0, side * HELD_ITEM_YAW, side * HELD_ITEM_ROLL, 'YXZ')));
  m.multiply(new THREE.Matrix4().makeScale(HELD_ITEM_SCALE, HELD_ITEM_SCALE, HELD_ITEM_SCALE));
  m.multiply(new THREE.Matrix4().makeTranslation(-HELD_GRIP.x, -HELD_GRIP.y, 0));
  const pts = ([[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0]] as const).map((c) => proj(new THREE.Vector3(c[0], c[1], c[2]).applyMatrix4(m)));
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
  const w = Math.max(...xs) - Math.min(...xs), h = Math.max(...ys) - Math.min(...ys);
  console.log(`  ${label}: fist ${fs[0].toFixed(0)},${fs[1].toFixed(0)}%  item x ${Math.min(...xs).toFixed(0)}-${Math.max(...xs).toFixed(0)}%  y ${Math.min(...ys).toFixed(0)}-${Math.max(...ys).toFixed(0)}%`);
  // "make them bigger": the item must be a substantial on-screen object, not a distant sprite
  ok(w > 30, `${label}: held item too small on screen (${w.toFixed(0)}% wide)`);
  ok(h > 40, `${label}: held item too short on screen (${h.toFixed(0)}% tall)`);
  ok(w < 75 && h < 90, `${label}: held item absurdly large (${w.toFixed(0)}x${h.toFixed(0)}%)`);
  // the grip point must be near the fist: that is what "in your hand" means
  const grip = proj(new THREE.Vector3(HELD_GRIP.x, HELD_GRIP.y, 0).applyMatrix4(m));
  const dist = Math.hypot(grip[0] - fs[0], grip[1] - fs[1]);
  ok(dist < 22, `${label}: item grip is ${dist.toFixed(0)}% away from the fist — not actually held`);
  // the item must stay in front of the camera at every point of the swing
  for (let sp = 0; sp <= 1.0001; sp += 0.1) {
    const a2 = handChain(sp, side, 0);
    const f2 = new THREE.Vector3(side * HELD_FIST_PX.x, HELD_FIST_PX.y, HELD_FIST_PX.z).multiplyScalar(0.0625).applyMatrix4(a2).add(off);
    ok(f2.z < -0.05, `${label}: fist clipped through the camera at swing ${sp.toFixed(1)} (z=${f2.z.toFixed(2)})`);
  }
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
